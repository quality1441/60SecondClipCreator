# Start 60 Second Clip Creator on this PC (127.0.0.1:43147).
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$Root = Split-Path -Parent $PSScriptRoot
$looksLikeApp = (Test-Path (Join-Path $Root "server.js")) -or (Test-Path (Join-Path $Root "package.json"))
if (-not $looksLikeApp) {
    $Root = $PSScriptRoot
}
Set-Location $Root

$port = 43147
function Test-HelperUp {
    try {
        $r = Invoke-WebRequest -Uri "http://127.0.0.1:$port/api/health" -UseBasicParsing -TimeoutSec 2
        return $r.StatusCode -eq 200
    } catch {
        return $false
    }
}

$studio = $env:SIXTYCC_PUBLIC_ORIGIN
if (-not $studio) { $studio = "https://60scc.vercel.app" }

if (Test-HelperUp) {
    Write-Host "Creator is already running on this computer."
    Start-Process $studio
    exit 0
}

$host.UI.RawUI.WindowTitle = "60 Second Clip Creator"
Write-Host "Starting 60 Second Clip Creator on this computer."
Write-Host "Leave this window open while you work. Close it or use Stop when you are done."
Write-Host ""

$standalone = Join-Path $Root "server.js"
if (Test-Path $standalone) {
    $env:PORT = "$port"
    $env:HOSTNAME = "127.0.0.1"
    Start-Process $studio
    node $standalone
    exit $LASTEXITCODE
}

if (-not (Test-Path (Join-Path $Root ".next\BUILD_ID"))) {
    Write-Host "Building once. This can take a few minutes."
    npm run build
}

$env:PORT = "$port"
$env:HOSTNAME = "127.0.0.1"
Start-Process $studio
npx --yes next start --port $port --hostname 127.0.0.1
