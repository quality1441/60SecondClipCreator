# Install 60 Second Clip Creator on this Windows PC.
# Optional local AI (Ollama) for titles and descriptions.
param(
    [ValidateSet("ask", "skip", "ollama", "models")]
    [string]$Ai = "ask"
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$Root = Split-Path -Parent $PSScriptRoot
$looksLikeApp = (Test-Path (Join-Path $Root "server.js")) -or (Test-Path (Join-Path $Root "package.json"))
if (-not $looksLikeApp) {
    $Root = $PSScriptRoot
}
Set-Location $Root

function Refresh-Path {
    $machine = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
    $user = [System.Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machine;$user"
}

function Test-Bin([string]$Name) {
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

function Install-WingetPackage([string]$Id, [string]$Label) {
    if (-not (Test-Bin "winget")) {
        throw "$Label is not on PATH, and winget is not available. Install $Label, then rerun this installer."
    }
    Write-Host "Installing $Label..."
    winget install --id $Id -e --accept-package-agreements --accept-source-agreements
    Refresh-Path
}

Write-Host "60 Second Clip Creator setup"
Write-Host ""

if ($Ai -eq "ask") {
    Write-Host "Local AI can write titles and descriptions on this PC. It uses extra disk and memory."
    Write-Host "  1  Skip AI for now"
    Write-Host "  2  Install Ollama only. Pick models later in Settings."
    Write-Host "  3  Install Ollama and the usual title models (Qwen 3.5 9B and Llama 3.1 8B)."
    $choice = Read-Host "Choose 1, 2, or 3"
    switch ($choice) {
        "2" { $Ai = "ollama" }
        "3" { $Ai = "models" }
        default { $Ai = "skip" }
    }
}

if (-not (Test-Bin "node")) {
    Install-WingetPackage "OpenJS.NodeJS.LTS" "Node.js"
}
$nodeVersion = (node --version).Trim()
$major = 0
if ($nodeVersion -match "v(\d+)") { $major = [int]$Matches[1] }
if ($major -lt 22) {
    Install-WingetPackage "OpenJS.NodeJS.LTS" "Node.js"
    Refresh-Path
}

if (-not (Test-Bin "ffmpeg")) {
    Install-WingetPackage "Gyan.FFmpeg" "ffmpeg"
}
if (-not (Test-Bin "ffmpeg")) {
    throw "ffmpeg is still missing. Close this window, open a new PowerShell, and rerun the installer."
}

$hasYtdlp = Test-Bin "yt-dlp"
if (-not $hasYtdlp) {
    try {
        Install-WingetPackage "yt-dlp.yt-dlp" "yt-dlp"
    } catch {
        Write-Host "yt-dlp will be installed with the Python packages instead."
    }
}

$python = $null
foreach ($candidate in @("py", "python", "python3")) {
    if (Test-Bin $candidate) {
        $python = $candidate
        break
    }
}
if (-not $python) {
    Install-WingetPackage "Python.Python.3.12" "Python"
    Refresh-Path
    foreach ($candidate in @("py", "python", "python3")) {
        if (Test-Bin $candidate) {
            $python = $candidate
            break
        }
    }
}
if (-not $python) {
    throw "Python 3.12+ is required. Install Python, then rerun the installer."
}

$venvPython = Join-Path $Root ".venv\Scripts\python.exe"
if (-not (Test-Path $venvPython)) {
    Write-Host "Creating the Python environment..."
    if ($python -eq "py") { py -3 -m venv .venv } else { & $python -m venv .venv }
}
if (-not (Test-Path $venvPython)) {
    throw "Could not create the Python environment."
}

Write-Host "Installing Python packages..."
& $venvPython -m pip install --upgrade pip
$reqFile = Join-Path $Root "requirements.txt"
if (Test-Path $reqFile) {
    & $venvPython -m pip install -r $reqFile
} else {
    & $venvPython -m pip install "yt-dlp>=2026.8.19" "faster-whisper>=1.2.0" "gTTS>=2.5.0" "curl-cffi>=0.7.0" "numpy>=1.26" "scenedetect>=0.6.6" "opencv-python-headless>=4.8"
}

if (-not (Test-Path (Join-Path $Root "server.js")) -and (Test-Path (Join-Path $Root "package.json"))) {
    Write-Host "Installing app packages..."
    npm install
}

if ($Ai -eq "ollama" -or $Ai -eq "models") {
    if (-not (Test-Bin "ollama")) {
        Install-WingetPackage "Ollama.Ollama" "Ollama"
        Refresh-Path
    }
    if (-not (Test-Bin "ollama")) {
        Write-Host "Ollama did not land on PATH. Open a new window after setup, or install it from https://ollama.com/"
    } elseif ($Ai -eq "models") {
        Write-Host "Downloading title models. This can take a while."
        ollama pull qwen3.5:9b
        ollama pull llama3.1:8b
    }
}

$dataDir = Join-Path $Root "data"
New-Item -ItemType Directory -Force -Path $dataDir, (Join-Path $dataDir "incoming"), (Join-Path $dataDir "jobs") | Out-Null

$programs = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\60 Second Clip Creator"
New-Item -ItemType Directory -Force -Path $programs | Out-Null
$desktop = [Environment]::GetFolderPath("Desktop")
$wshell = New-Object -ComObject WScript.Shell

$iconFile = Join-Path $Root "public\sixtycc.ico"
if (-not (Test-Path $iconFile)) { $iconFile = Join-Path $Root "sixtycc.ico" }

function New-HelperShortcut([string]$Path, [string]$ScriptName, [string]$Description) {
    $sc = $wshell.CreateShortcut($Path)
    $sc.TargetPath = "powershell.exe"
    $sc.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $Root "scripts\$ScriptName")`""
    $sc.WorkingDirectory = $Root
    $sc.Description = $Description
    if (Test-Path $iconFile) {
        $sc.IconLocation = "$iconFile,0"
    }
    $sc.Save()
}

New-HelperShortcut (Join-Path $programs "Start 60 Second Clip Creator.lnk") "start-helper.ps1" "Start Creator on this PC"
New-HelperShortcut (Join-Path $programs "Stop 60 Second Clip Creator.lnk") "stop-helper.ps1" "Stop Creator on this PC"
New-HelperShortcut (Join-Path $desktop "Start 60 Second Clip Creator.lnk") "start-helper.ps1" "Start Creator on this PC"
New-HelperShortcut (Join-Path $desktop "Stop 60 Second Clip Creator.lnk") "stop-helper.ps1" "Stop Creator on this PC"

Write-Host ""
Write-Host "Setup is done."
Write-Host "Use Start 60 Second Clip Creator on the desktop or in the Start menu."
Write-Host "Use Stop 60 Second Clip Creator when you are finished."
Write-Host "Then sign in at https://60scc.vercel.app"
