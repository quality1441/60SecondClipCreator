# Stop 60 Second Clip Creator on this PC.
$ErrorActionPreference = "SilentlyContinue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$port = 43147
$conns = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
if (-not $conns) {
    Write-Host "Creator is not running."
    exit 0
}
$pids = $conns.OwningProcess | Sort-Object -Unique
foreach ($procId in $pids) {
    if ($procId -and $procId -gt 0) {
        Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
    }
}
Start-Sleep -Milliseconds 400
Write-Host "Creator has stopped."
