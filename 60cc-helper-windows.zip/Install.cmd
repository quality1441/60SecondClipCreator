@echo off
cd /d "%~dp0"
title 60 Second Clip Creator setup
echo 60 Second Clip Creator setup
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install-helper.ps1"
if errorlevel 1 (
  echo.
  echo Setup did not finish.
  pause
)
