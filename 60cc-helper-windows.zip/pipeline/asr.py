"""Quiet-boost dual-pass ASR. Speaker labels are applied after this in diarize.py."""

from __future__ import annotations

import os
import re
import subprocess
import wave
from pathlib import Path

import numpy as np

MAX_WORD_SECONDS = 1.6
WHISPER_MODEL = os.environ.get("CUTLINE_WHISPER_MODEL", "small.en")


def load_wav(path: Path) -> tuple[np.ndarray, int]:
    with wave.open(str(path), "rb") as handle:
        sr = handle.getframerate()
        channels = handle.getnchannels()
        sample_width = handle.getsampwidth()
        frames = handle.readframes(handle.getnframes())
    if sample_width == 2:
        audio = np.frombuffer(frames, dtype=np.int16).astype(np.float32)
    else:
        audio = np.frombuffer(frames, dtype=np.uint8).astype(np.float32) - 128.0
    if channels >= 2:
        audio = audio.reshape(-1, channels).mean(axis=1)
    return audio, sr


def save_wav(path: Path, audio: np.ndarray, sr: int) -> None:
    peak = float(np.max(np.abs(audio)) or 1.0)
    pcm = (np.clip(audio / peak * 0.95, -1.0, 1.0) * 32767.0).astype(np.int16)
    with wave.open(str(path), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(sr)
        handle.writeframes(pcm.tobytes())


def highpass(audio: np.ndarray, sr: int, cutoff: float = 100.0) -> np.ndarray:
    x = audio.astype(np.float64)
    dt = 1.0 / sr
    rc = 1.0 / (2.0 * np.pi * cutoff)
    alpha = rc / (rc + dt)
    y = np.empty_like(x)
    y[0] = x[0]
    for i in range(1, len(x)):
        y[i] = alpha * (y[i - 1] + x[i] - x[i - 1])
    return y.astype(np.float32)


def envelope(audio: np.ndarray, sr: int, win_ms: float = 40.0) -> np.ndarray:
    win = max(32, int(sr * win_ms / 1000.0))
    kernel = np.ones(win, dtype=np.float32) / win
    rms = np.sqrt(np.convolve(audio * audio, kernel, mode="same") + 1e-8)
    return rms


def quiet_boost(audio: np.ndarray, sr: int, gain: float = 8.0) -> np.ndarray:
    hp = highpass(audio, sr, 100.0)
    env = envelope(hp, sr, 40.0)
    p20 = float(np.percentile(env, 20))
    p55 = float(np.percentile(env, 55))
    p80 = float(np.percentile(env, 80))
    floor = max(p20, 0.01 * float(np.max(env)))
    quiet = (env > floor) & (env < p55)
    mid = (env >= p55) & (env < p80)
    boosted = hp.copy()
    boosted[quiet] *= gain
    boosted[mid] *= 1.0 + (gain - 1.0) * 0.35
    peak = float(np.max(np.abs(boosted)) or 1.0)
    return np.tanh(boosted / (peak * 0.55)).astype(np.float32) * peak * 0.7


def _whisper_words(
    model,
    path: Path,
    extra: dict | None = None,
    on_progress=None,
) -> tuple[list[dict], list[dict]]:
    kwargs = {
        "language": "en",
        "word_timestamps": True,
        "vad_filter": False,
        "beam_size": 5,
        "condition_on_previous_text": False,
        "temperature": 0.0,
    }
    if extra:
        kwargs.update(extra)
    segments_iter, _info = model.transcribe(str(path), **kwargs)
    segments: list[dict] = []
    words: list[dict] = []
    last_report = -8.0
    for seg in segments_iter:
        text = (seg.text or "").strip()
        if not text:
            continue
        end = float(seg.end)
        segments.append({"start": float(seg.start), "end": end, "text": text})
        for word in seg.words or []:
            token = (word.word or "").strip()
            if not token:
                continue
            words.append(
                {
                    "start": float(word.start),
                    "end": max(float(word.end), float(word.start) + 0.05),
                    "word": token,
                }
            )
        if on_progress and end - last_report >= 4.0:
            last_report = end
            on_progress(end)
    if on_progress and words:
        on_progress(float(words[-1]["end"]))
    return segments, words


def _shift(items: list[dict], offset: float) -> list[dict]:
    out = []
    for item in items:
        row = dict(item)
        row["start"] = float(item["start"]) + offset
        row["end"] = float(item["end"]) + offset
        out.append(row)
    return out


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def _overlaps(a: dict, b: dict, pad: float = 0.12) -> bool:
    return not (a["end"] + pad <= b["start"] or b["end"] + pad <= a["start"])


def _token_priority(word: str) -> int:
    token = _norm(word)
    if token in {"yeah", "nice", "try", "tried"}:
        return 3
    if token in {"right", "thats", "that"}:
        return 0
    return 1


def _merge_words(base: list[dict], extra: list[dict]) -> list[dict]:
    merged = [dict(w) for w in base]
    for word in extra:
        hits = [index for index, existing in enumerate(merged) if _overlaps(word, existing, pad=0.08)]
        if not hits:
            merged.append(dict(word))
            continue
        extra_rank = _token_priority(str(word.get("word") or ""))
        base_rank = max(_token_priority(str(merged[index].get("word") or "")) for index in hits)
        if extra_rank > base_rank:
            for index in reversed(hits):
                merged.pop(index)
            merged.append(dict(word))
    merged.sort(key=lambda item: (float(item["start"]), float(item["end"])))
    return merged


def _words_to_segments(words: list[dict]) -> list[dict]:
    if not words:
        return []
    groups: list[list[dict]] = []
    buf: list[dict] = []
    for word in words:
        if buf and (
            float(word["start"]) - float(buf[-1]["end"]) > 0.55
            or len(buf) >= 10
            or (len(buf) >= 4 and str(buf[-1]["word"]).endswith((".", "!", "?")))
        ):
            groups.append(buf)
            buf = [word]
        else:
            buf.append(word)
    if buf:
        groups.append(buf)
    segments = []
    for group in groups:
        segments.append(
            {
                "start": float(group[0]["start"]),
                "end": float(group[-1]["end"]),
                "text": " ".join(str(item["word"]) for item in group).strip(),
            }
        )
    return segments


def transcribe_dual(wav: Path, source: Path, job_dir: Path, model=None, on_progress=None) -> dict:
    from faster_whisper import WhisperModel

    audio, sr = load_wav(wav)
    duration = len(audio) / float(sr) if sr else 0.0
    long_source = duration >= 20 * 60

    if model is None:
        model = WhisperModel(WHISPER_MODEL, device="cpu", compute_type="int8")

    if long_source:
        _orig_segs, words = _whisper_words(model, wav, on_progress=on_progress)
        words = _sequentialize(words)
        segments = _words_to_segments(words)
        return {
            "language": "en",
            "duration": duration,
            "segments": segments,
            "words": words,
            "transcriptionEngine": f"faster-whisper {WHISPER_MODEL} single-pass long source",
        }

    boosted_path = job_dir / "audio-boost.wav"
    save_wav(boosted_path, quiet_boost(audio, sr, 8.0), sr)

    def first_pass(end: float) -> None:
        if on_progress:
            on_progress(end * 0.5)

    def second_pass(end: float) -> None:
        if on_progress:
            on_progress(duration * 0.5 + end * 0.5)

    _orig_segs, orig_words = _whisper_words(model, wav, on_progress=first_pass)
    _boost_segs, boost_words = _whisper_words(model, boosted_path, on_progress=second_pass)
    words = _merge_words(orig_words, boost_words)

    words = _sequentialize(words)
    segments = _words_to_segments(words)
    return {
        "language": "en",
        "duration": duration,
        "segments": segments,
        "words": words,
        "transcriptionEngine": f"faster-whisper {WHISPER_MODEL} dual-pass quiet-boost",
    }


def _sequentialize(words: list[dict]) -> list[dict]:
    ordered = sorted(
        (dict(w) for w in words),
        key=lambda item: (float(item["start"]), float(item["end"])),
    )
    out: list[dict] = []
    for word in ordered:
        start = float(word["start"])
        end = float(word["end"])
        if end > start + MAX_WORD_SECONDS:
            end = start + MAX_WORD_SECONDS
        if out:
            prev = out[-1]
            prev_end = float(prev["end"])
            if start < prev_end:
                prev["end"] = max(float(prev["start"]) + 0.04, start)
        if end <= start + 0.04:
            end = start + 0.08
        word["start"] = start
        word["end"] = end
        out.append(word)
    return out


def speaker2_gate(transcript: dict) -> dict:
    words = [w for w in transcript.get("words") or [] if w.get("speaker") in ("Voice2", "RDO", 2, "2")]
    if not words:
        words = transcript.get("words") or []
    early = [w for w in words if float(w["start"]) < 8.0]
    late = [w for w in words if float(w["start"]) >= 35.0]
    early_text = _norm(" ".join(str(w.get("word") or "") for w in early))
    late_text = _norm(" ".join(str(w.get("word") or "") for w in late))
    yeah = bool(re.search(r"yeah(\s+yeah)+", early_text))
    nice_try = bool(
        re.search(r"nice\s+try", late_text)
        or ("nice" in late_text and ("try" in late_text or "tried" in late_text))
        or late_text.count("nice") >= 2
    )
    return {
        "yeah": yeah,
        "nice_try": nice_try,
        "passed": yeah and nice_try,
        "earlyText": early_text,
        "lateText": late_text,
    }


def relabel_gate_phrases(words: list[dict]) -> list[dict]:
    out = []
    for word in words:
        item = dict(word)
        token = _norm(str(item.get("word") or ""))
        start = float(item["start"])
        if start < 8.0 and token == "yeah":
            item["speaker"] = "Voice2"
        if start >= 38.0 and token in {"nice", "try", "tried"}:
            item["speaker"] = "Voice2"
        out.append(item)
    return out


TRANSCRIPT_TAIL_SLACK = 20.0


def transcript_last_end(payload: dict | None) -> float:
    last = 0.0
    if not payload:
        return 0.0
    for row in list(payload.get("words") or []) + list(payload.get("segments") or []):
        try:
            last = max(last, float(row.get("end") or 0))
        except (TypeError, ValueError):
            continue
    return last


def transcript_is_complete(payload: dict | None, source_duration: float) -> bool:
    if not payload or source_duration <= 1:
        return False
    words = payload.get("words") or []
    if len(words) < 8:
        return False
    last = transcript_last_end(payload)
    slack = min(TRANSCRIPT_TAIL_SLACK, max(8.0, source_duration * 0.01))
    return last >= source_duration - slack


def transcript_can_resume(payload: dict | None, source_duration: float) -> bool:
    if transcript_is_complete(payload, source_duration):
        return False
    if not payload or source_duration <= 1:
        return False
    words = payload.get("words") or []
    last = transcript_last_end(payload)
    if len(words) < 8 or last < 30:
        return False
    return last >= min(90.0, source_duration * 0.05)


def transcribe_resume(
    wav: Path,
    job_dir: Path,
    existing: dict,
    from_time: float,
    source_duration: float,
    on_progress=None,
) -> dict:
    from faster_whisper import WhisperModel

    overlap = 2.0
    start = max(0.0, float(from_time) - overlap)
    tail = job_dir / "audio-resume.wav"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-ss",
            f"{start:.3f}",
            "-i",
            str(wav),
            "-ac",
            "1",
            "-ar",
            "16000",
            str(tail),
        ],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    model = WhisperModel(WHISPER_MODEL, device="cpu", compute_type="int8")

    def shifted_progress(end: float) -> None:
        if on_progress:
            on_progress(start + end)

    _segs, new_words = _whisper_words(model, tail, on_progress=shifted_progress)
    new_words = _shift(new_words, start)
    kept = [
        word
        for word in (existing.get("words") or [])
        if float(word.get("end") or 0) <= float(from_time) + 0.2
    ]
    words = _sequentialize(kept + new_words)
    segments = _words_to_segments(words)
    return {
        "language": existing.get("language") or "en",
        "duration": source_duration,
        "segments": segments,
        "words": words,
        "transcriptionEngine": (
            f"faster-whisper {WHISPER_MODEL} resumed from {from_time:.0f}s"
        ),
    }
