"""Official social glyphs as SVG paths, converted to ASS drawings."""

from __future__ import annotations

import math
import re

ICON_VIEW = 24.0
ICON_PX = 34.0

# Simple Icons paths (viewBox 0 0 24 24).
ICON_PATHS: dict[str, str] = {
    "twitch": (
        "M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714Z"
    ),
    "youtube": (
        "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"
    ),
    "kick": "M1.333 0h8v5.333H12V2.667h2.667V0h8v8H20v2.667h-2.667v2.666H20V16h2.667v8h-8v-2.667H12v-2.666H9.333V24h-8Z",
    "instagram": (
        "M7.0301.084c-1.2768.0602-2.1487.264-2.911.5634-.7888.3075-1.4575.72-2.1228 1.3877-.6652.6677-1.075 1.3368-1.3802 2.127-.2954.7638-.4956 1.6365-.552 2.914-.0564 1.2775-.0689 1.6882-.0626 4.947.0062 3.2586.0206 3.6671.0825 4.9473.061 1.2765.264 2.1482.5635 2.9107.308.7889.72 1.4573 1.388 2.1228.6679.6655 1.3365 1.0743 2.1285 1.38.7632.295 1.6361.4961 2.9134.552 1.2773.056 1.6884.069 4.9462.0627 3.2578-.0062 3.668-.0207 4.9478-.0814 1.28-.0607 2.147-.2652 2.9098-.5633.7889-.3086 1.4578-.72 2.1228-1.3881.665-.6682 1.0745-1.3378 1.3795-2.1284.2957-.7632.4966-1.636.552-2.9124.056-1.2809.0692-1.6898.063-4.948-.0063-3.2583-.021-3.6668-.0817-4.9465-.0607-1.2797-.264-2.1487-.5633-2.9117-.3084-.7889-.72-1.4568-1.3876-2.1228C21.2982 1.33 20.628.9208 19.8378.6165 19.074.321 18.2017.1197 16.9244.0645 15.6471.0093 15.236-.005 11.977.0014 8.718.0076 8.31.0215 7.0301.0839m.1402 21.6932c-1.17-.0509-1.8053-.2453-2.2287-.408-.5606-.216-.96-.4771-1.3819-.895-.422-.4178-.6811-.8186-.9-1.378-.1644-.4234-.3624-1.058-.4171-2.228-.0595-1.2645-.072-1.6442-.079-4.848-.007-3.2037.0053-3.583.0607-4.848.05-1.169.2456-1.805.408-2.2282.216-.5613.4762-.96.895-1.3816.4188-.4217.8184-.6814 1.3783-.9003.423-.1651 1.0575-.3614 2.227-.4171 1.2655-.06 1.6447-.072 4.848-.079 3.2033-.007 3.5835.005 4.8495.0608 1.169.0508 1.8053.2445 2.228.408.5608.216.96.4754 1.3816.895.4217.4194.6816.8176.9005 1.3787.1653.4217.3617 1.056.4169 2.2263.0602 1.2655.0739 1.645.0796 4.848.0058 3.203-.0055 3.5834-.061 4.848-.051 1.17-.245 1.8055-.408 2.2294-.216.5604-.4763.96-.8954 1.3814-.419.4215-.8181.6811-1.3783.9-.4224.1649-1.0577.3617-2.2262.4174-1.2656.0595-1.6448.072-4.8493.079-3.2045.007-3.5825-.006-4.848-.0608M16.953 5.5864A1.44 1.44 0 1 0 18.39 4.144a1.44 1.44 0 0 0-1.437 1.4424M5.8385 12.012c.0067 3.4032 2.7706 6.1557 6.173 6.1493 3.4026-.0065 6.157-2.7701 6.1506-6.1733-.0065-3.4032-2.771-6.1565-6.174-6.1498-3.403.0067-6.156 2.771-6.1496 6.1738M8 12.0077a4 4 0 1 1 4.008 3.9921A3.9996 3.9996 0 0 1 8 12.0077"
    ),
    "tiktok": (
        "M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"
    ),
}

# Chip fill, then glyph layers (color, dx, dy). Empty glyph color uses contrast ink.
ICON_LAYERS: dict[str, tuple[str, list[tuple[str, float, float]]]] = {
    "twitch": ("#9146FF", [("#FFFFFF", 0.0, 0.0)]),
    "youtube": ("#FF0000", [("#FFFFFF", 0.0, 0.0)]),
    "kick": ("#53FC18", [("#0B0B0F", 0.0, 0.0)]),
    "instagram": ("#E1306C", [("#FFFFFF", 0.0, 0.0)]),
    "tiktok": (
        "#101014",
        [("#25F4EE", 1.9, -1.3), ("#FE2C55", -1.9, 1.3), ("#F0F0F4", 0.0, 0.0)],
    ),
}

_TOKEN = re.compile(r"[MmLlHhVvCcSsQqTtAaZz]|[-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?")
_CMDS = set("MmLlHhVvCcSsQqTtAaZz")
_ARGS = {
    "M": 2,
    "L": 2,
    "H": 1,
    "V": 1,
    "C": 6,
    "S": 4,
    "Q": 4,
    "T": 2,
    "A": 7,
    "Z": 0,
}


def _fmt(value: float) -> str:
    return f"{value:.2f}".rstrip("0").rstrip(".")


def svg_path_to_ass(d: str, size: float = ICON_PX) -> str:
    scale = size / ICON_VIEW
    tokens = _TOKEN.findall(d)
    i = 0
    cmd = ""
    cx = cy = 0.0
    start_x = start_y = 0.0
    last_cx = last_cy = 0.0
    last_kind = ""
    out: list[str] = []

    def take(n: int) -> list[float]:
        nonlocal i
        values: list[float] = []
        while len(values) < n and i < len(tokens):
            piece = tokens[i]
            i += 1
            if piece in _CMDS:
                i -= 1
                break
            values.append(float(piece))
        return values

    def pt(x: float, y: float) -> str:
        return f"{_fmt(x * scale)} {_fmt(y * scale)}"

    while i < len(tokens):
        raw = tokens[i]
        if raw in _CMDS:
            cmd = raw
            i += 1
        elif not cmd:
            i += 1
            continue
        upper = cmd.upper()
        rel = cmd.islower()
        need = _ARGS[upper]
        if need == 0:
            out.append("c")
            cx, cy = start_x, start_y
            last_kind = "Z"
            continue
        args = take(need)
        if len(args) < need:
            break
        if upper == "M":
            x, y = args
            if rel:
                x += cx
                y += cy
            cx, cy = x, y
            start_x, start_y = x, y
            if out and out[-1] != "c":
                out.append("c")
            out.append(f"m {pt(x, y)}")
            cmd = "l" if rel else "L"
            last_kind = "M"
            continue
        if upper == "L":
            x, y = args
            if rel:
                x += cx
                y += cy
            cx, cy = x, y
            out.append(f"l {pt(x, y)}")
            last_kind = "L"
            continue
        if upper == "H":
            x = args[0] + (cx if rel else 0.0)
            cx = x
            out.append(f"l {pt(cx, cy)}")
            last_kind = "L"
            continue
        if upper == "V":
            y = args[0] + (cy if rel else 0.0)
            cy = y
            out.append(f"l {pt(cx, cy)}")
            last_kind = "L"
            continue
        if upper == "C":
            x1, y1, x2, y2, x, y = args
            if rel:
                x1 += cx
                y1 += cy
                x2 += cx
                y2 += cy
                x += cx
                y += cy
            out.append(f"b {pt(x1, y1)} {pt(x2, y2)} {pt(x, y)}")
            last_cx, last_cy = x2, y2
            cx, cy = x, y
            last_kind = "C"
            continue
        if upper == "S":
            x2, y2, x, y = args
            if rel:
                x2 += cx
                y2 += cy
                x += cx
                y += cy
            if last_kind in {"C", "S"}:
                x1 = 2 * cx - last_cx
                y1 = 2 * cy - last_cy
            else:
                x1, y1 = cx, cy
            out.append(f"b {pt(x1, y1)} {pt(x2, y2)} {pt(x, y)}")
            last_cx, last_cy = x2, y2
            cx, cy = x, y
            last_kind = "S"
            continue
        if upper == "Q":
            x1, y1, x, y = args
            if rel:
                x1 += cx
                y1 += cy
                x += cx
                y += cy
            c1x = cx + 2 / 3 * (x1 - cx)
            c1y = cy + 2 / 3 * (y1 - cy)
            c2x = x + 2 / 3 * (x1 - x)
            c2y = y + 2 / 3 * (y1 - y)
            out.append(f"b {pt(c1x, c1y)} {pt(c2x, c2y)} {pt(x, y)}")
            last_cx, last_cy = x1, y1
            cx, cy = x, y
            last_kind = "Q"
            continue
        if upper == "T":
            x, y = args
            if rel:
                x += cx
                y += cy
            if last_kind in {"Q", "T"}:
                x1 = 2 * cx - last_cx
                y1 = 2 * cy - last_cy
            else:
                x1, y1 = cx, cy
            c1x = cx + 2 / 3 * (x1 - cx)
            c1y = cy + 2 / 3 * (y1 - cy)
            c2x = x + 2 / 3 * (x1 - x)
            c2y = y + 2 / 3 * (y1 - y)
            out.append(f"b {pt(c1x, c1y)} {pt(c2x, c2y)} {pt(x, y)}")
            last_cx, last_cy = x1, y1
            cx, cy = x, y
            last_kind = "T"
            continue
        if upper == "A":
            rx, ry, phi, fa, fs, x, y = args
            if rel:
                x += cx
                y += cy
            for cubic in _arc_to_cubics(cx, cy, rx, ry, phi, fa, fs, x, y):
                x1, y1, x2, y2, x3, y3 = cubic
                out.append(f"b {pt(x1, y1)} {pt(x2, y2)} {pt(x3, y3)}")
            cx, cy = x, y
            last_kind = "A"
            continue
    return " ".join(out)


def _arc_to_cubics(
    x1: float,
    y1: float,
    rx: float,
    ry: float,
    phi_deg: float,
    fa: float,
    fs: float,
    x2: float,
    y2: float,
) -> list[tuple[float, float, float, float, float, float]]:
    if rx == 0 or ry == 0 or (x1 == x2 and y1 == y2):
        return [(x1, y1, x2, y2, x2, y2)]
    rx, ry = abs(rx), abs(ry)
    phi = math.radians(phi_deg % 360.0)
    cos_p, sin_p = math.cos(phi), math.sin(phi)
    dx = (x1 - x2) / 2.0
    dy = (y1 - y2) / 2.0
    x1p = cos_p * dx + sin_p * dy
    y1p = -sin_p * dx + cos_p * dy
    lam = (x1p**2) / (rx**2) + (y1p**2) / (ry**2)
    if lam > 1:
        root = math.sqrt(lam)
        rx *= root
        ry *= root
    num = rx**2 * ry**2 - rx**2 * y1p**2 - ry**2 * x1p**2
    den = rx**2 * y1p**2 + ry**2 * x1p**2
    coef = math.sqrt(max(0.0, num / den))
    if bool(fa) == bool(fs):
        coef = -coef
    cxp = coef * (rx * y1p) / ry
    cyp = coef * -(ry * x1p) / rx
    cx = cos_p * cxp - sin_p * cyp + (x1 + x2) / 2.0
    cy = sin_p * cxp + cos_p * cyp + (y1 + y2) / 2.0

    def angle(ux: float, uy: float, vx: float, vy: float) -> float:
        dot = ux * vx + uy * vy
        det = ux * vy - uy * vx
        return math.copysign(math.acos(max(-1.0, min(1.0, dot / (math.hypot(ux, uy) * math.hypot(vx, vy))))), det)

    ux, uy = (x1p - cxp) / rx, (y1p - cyp) / ry
    vx, vy = (-x1p - cxp) / rx, (-y1p - cyp) / ry
    theta1 = angle(1.0, 0.0, ux, uy)
    delta = angle(ux, uy, vx, vy)
    if not fs and delta > 0:
        delta -= 2 * math.pi
    if fs and delta < 0:
        delta += 2 * math.pi
    segments = max(1, int(math.ceil(abs(delta) / (math.pi / 2))))
    delta /= segments
    alpha = (4 / 3) * math.tan(delta / 4)
    cubics: list[tuple[float, float, float, float, float, float]] = []
    for index in range(segments):
        t1 = theta1 + index * delta
        t2 = t1 + delta
        e1x, e1y = _arc_point(cx, cy, rx, ry, cos_p, sin_p, t1)
        e2x, e2y = _arc_point(cx, cy, rx, ry, cos_p, sin_p, t2)
        d1x, d1y = _arc_deriv(rx, ry, cos_p, sin_p, t1)
        d2x, d2y = _arc_deriv(rx, ry, cos_p, sin_p, t2)
        cubics.append((e1x + alpha * d1x, e1y + alpha * d1y, e2x - alpha * d2x, e2y - alpha * d2y, e2x, e2y))
    return cubics


def _arc_point(cx: float, cy: float, rx: float, ry: float, cos_p: float, sin_p: float, theta: float) -> tuple[float, float]:
    x = rx * math.cos(theta)
    y = ry * math.sin(theta)
    return cx + cos_p * x - sin_p * y, cy + sin_p * x + cos_p * y


def _arc_deriv(rx: float, ry: float, cos_p: float, sin_p: float, theta: float) -> tuple[float, float]:
    x = -rx * math.sin(theta)
    y = ry * math.cos(theta)
    return cos_p * x - sin_p * y, sin_p * x + cos_p * y


def icon_drawing(platform: str, size: float = ICON_PX) -> str:
    path = ICON_PATHS.get(platform)
    if not path:
        return ""
    return svg_path_to_ass(path, size)


def icon_layers(platform: str) -> tuple[str, list[tuple[str, float, float]]]:
    return ICON_LAYERS.get(platform, ("#FFFFFF", [("#101820", 0.0, 0.0)]))
