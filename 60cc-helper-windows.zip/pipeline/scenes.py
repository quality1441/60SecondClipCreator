"""Shot and scene-change times from the source video.

Uses a downscaled ffmpeg scene pass. A failed detect returns an empty list
so highlight picking still runs from speech and laughs.
"""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

_PTS_TIME = re.compile(r"pts_time:([0-9.]+)")


def _thin_cuts(cuts: list[float], min_gap: float = 1.2) -> list[float]:
    out: list[float] = []
    for time in cuts:
        if time < 0.4:
            continue
        if not out or time - out[-1] >= min_gap:
            out.append(round(float(time), 3))
    return out


def _cuts_from_ffmpeg(source: Path) -> list[float]:
    cmd = [
        "ffmpeg",
        "-hide_banner",
        "-nostdin",
        "-an",
        "-i",
        str(source),
        "-vf",
        r"fps=3,scale=320:-2,select=gt(scene\,0.28),showinfo",
        "-f",
        "null",
        "-",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=240, check=False)
    blob = f"{result.stderr or ''}\n{result.stdout or ''}"
    cuts = [float(match.group(1)) for match in _PTS_TIME.finditer(blob)]
    return cuts


def detect_scene_cuts(source: Path | None, job_dir: Path | None = None) -> list[float]:
    if source is None or not Path(source).is_file():
        return []
    source = Path(source)
    cache = (job_dir / "scenes.json") if job_dir is not None else None
    if cache is not None and cache.is_file():
        try:
            packed = json.loads(cache.read_text(encoding="utf-8"))
            cached = packed.get("cuts") if isinstance(packed, dict) else None
            src_mtime = packed.get("sourceMtime") if isinstance(packed, dict) else None
            if (
                isinstance(cached, list)
                and src_mtime is not None
                and abs(float(src_mtime) - source.stat().st_mtime) < 0.5
            ):
                return _thin_cuts([float(item) for item in cached])
        except (OSError, TypeError, ValueError, json.JSONDecodeError):
            pass
    try:
        cuts = _thin_cuts(_cuts_from_ffmpeg(source))
    except Exception as exc:
        print(f"Scene detect skipped: {exc}", flush=True)
        return []
    if cache is not None:
        try:
            cache.write_text(
                json.dumps(
                    {
                        "cuts": cuts,
                        "sourceMtime": source.stat().st_mtime,
                        "count": len(cuts),
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
        except OSError:
            pass
    return cuts


def cuts_in_window(start: float, end: float, cuts: list[float]) -> list[float]:
    return [time for time in cuts if start < time < end]


def first_cut_in_window(start: float, end: float, cuts: list[float]) -> float | None:
    inside = cuts_in_window(start, end, cuts)
    return inside[0] if inside else None
