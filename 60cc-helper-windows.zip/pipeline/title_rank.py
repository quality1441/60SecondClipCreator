#!/usr/bin/env python3
"""VidIQ-style 0-100 title ranking from clip context.

Modeled on vidIQ Optimize: keyword placement, proven formats, emotional
triggers, character count, grammar/clarity, plus Shorts-specific first-40
visibility. Scores are an optimization estimate, not a ranking guarantee.
Bands match vidIQ: 0-40 red, 41-80 yellow, 81-100 green.
"""

from __future__ import annotations

import json
import re
import sys

GENERIC_TAGS = {
    "explore",
    "explorepage",
    "fyp",
    "foryou",
    "foryoupage",
    "trending",
    "viral",
    "xyzbca",
}

WEAK_LEAD = {
    "already",
    "base",
    "beautiful",
    "boy",
    "driven",
    "good",
    "luck",
    "make",
    "never",
    "okay",
    "right",
    "somebody",
    "these",
    "wait",
    "wow",
    "yeah",
    "nice",
}

FORMAT_TAGS = {"highlight", "short", "shorts", "youtube", "youtubeshorts"}

EMOTION = {
    "best",
    "crazy",
    "ever",
    "finally",
    "insane",
    "never",
    "secret",
    "wait",
    "why",
    "how",
    "vs",
    "need",
    "love",
    "warning",
    "stop",
}

FILLER = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "but",
    "for",
    "from",
    "i",
    "in",
    "is",
    "it",
    "of",
    "oh",
    "ok",
    "okay",
    "on",
    "so",
    "that's",
    "thats",
    "the",
    "there's",
    "this",
    "to",
    "we",
    "what's",
    "whats",
    "wow",
    "yeah",
    "you",
}

EMOJI_RE = re.compile(
    "["
    "\U0001F300-\U0001FAFF"
    "\U00002700-\U000027BF"
    "\U00002600-\U000026FF"
    "]+",
    flags=re.UNICODE,
)


def tidy(value: str) -> str:
    text = (value or "").replace("\u2014", ",").replace("\u2013", "-")
    text = re.sub(r"\s+", " ", text).strip(" \t\n\r\"'")
    return text


def tokens(text: str) -> list[str]:
    return re.findall(r"[A-Za-z0-9']+", text.lower())


def hashtags_in(text: str) -> list[str]:
    return [item.lower() for item in re.findall(r"#([A-Za-z0-9_]+)", text or "")]


def body_text(title: str) -> str:
    return tidy(re.sub(r"#\S+", "", title or ""))


def band_for(score: int) -> str:
    if score >= 81:
        return "green"
    if score >= 41:
        return "yellow"
    return "red"


def _clip_phrases(words: list[str]) -> list[str]:
    weak_tail = {"look", "like", "got", "get", "know", "dont", "him", "her", "them"}
    scored: dict[str, int] = {}
    for size in (3, 2):
        for index in range(len(words) - size + 1):
            gram = words[index : index + size]
            if any(len(item) < 3 or "'" in item or item in FILLER or item in FORMAT_TAGS or item in GENERIC_TAGS for item in gram):
                continue
            if gram[-1] in weak_tail or gram[-1] in WEAK_LEAD:
                continue
            if all(item in WEAK_LEAD for item in gram):
                continue
            phrase = " ".join(gram)
            scored[phrase] = scored.get(phrase, 0) + (2 if size == 2 else 1)
    return [phrase for phrase, _score in sorted(scored.items(), key=lambda item: (-item[1], item[0]))]


def _hook_line(text: str) -> str:
    chunks = re.split(r"(?<=[.!?])\s+", tidy(text))
    for chunk in chunks:
        words = tokens(chunk)
        content = [item for item in words if item not in FILLER and item not in WEAK_LEAD and len(item) >= 4]
        if len(content) >= 2 and 18 <= len(chunk) <= 90:
            return tidy(chunk).rstrip(",;")
    return ""


def extract_context(
    text: str,
    source_title: str | None = None,
    tags: list[str] | None = None,
    description: str = "",
) -> dict:
    clip_words = tokens(text or "")
    blob_words = tokens(f"{text or ''} {source_title or ''} {description or ''}")
    phrases = _clip_phrases(clip_words)
    counts: dict[str, int] = {}
    for word in clip_words:
        if word in FILLER or word in WEAK_LEAD or len(word) < 4 or "'" in word:
            continue
        counts[word] = counts.get(word, 0) + 1
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    desc_words = tokens(description or "")
    desc_phrases = _clip_phrases(desc_words)
    phrases = [*desc_phrases, *phrases]
    for word in desc_words:
        if word in FILLER or word in WEAK_LEAD or len(word) < 4 or "'" in word:
            continue
        counts[word] = counts.get(word, 0) + 2
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    keywords = [*desc_phrases[:4], *phrases[:4], *[word for word, _count in ranked[:8]]]
    seen_kw: list[str] = []
    for item in keywords:
        if item not in seen_kw:
            seen_kw.append(item)
    keywords = seen_kw[:10]
    supplied = []
    for tag in tags or []:
        clean = tidy(str(tag)).lower().lstrip("#")
        if not clean or clean in FORMAT_TAGS or clean in GENERIC_TAGS:
            continue
        supplied.append(clean)
    niche = []
    for item in supplied + phrases + keywords:
        token = item if " " in item else re.sub(r"[^a-z0-9]", "", item)
        if len(token) < 3 or token in FORMAT_TAGS or token in GENERIC_TAGS or token in WEAK_LEAD:
            continue
        if token not in niche:
            niche.append(token)
        if len(niche) >= 4:
            break
    category = next((item for item in niche if item in {"gaming", "game", "games"}), "")
    if not category and any(word in blob_words for word in ("game", "gaming", "played", "raid")):
        category = "gaming"
    moment = phrases[0] if phrases else ""
    topic = moment or next((item for item in keywords if item not in WEAK_LEAD), "")
    source = tidy(source_title or "")
    if source and source.lower() in {"source", "full video", "untitled", "untitled short"}:
        source = ""
    quality = ""
    for candidate in ("community", "crew", "raid", "run", "squad", "team"):
        if candidate in desc_words or candidate in clip_words:
            quality = candidate
            break
    pitch = tidy(description or "")
    return {
        "keywords": keywords,
        "words": set(blob_words),
        "niche": niche[:3],
        "category": category,
        "topic": topic,
        "moment": moment,
        "hook": _hook_line(pitch) or _hook_line(text or ""),
        "quality": quality,
        "sourceTitle": source,
        "pitch": pitch,
    }


def formula_titles(context: dict) -> list[str]:
    moment = tidy(str(context.get("moment") or context.get("topic") or ""))
    hook = tidy(str(context.get("hook") or ""))
    if moment.lower() in WEAK_LEAD:
        moment = ""
    out: list[str] = []
    if hook and 18 <= len(hook) <= 90:
        out.append(hook[:100])
    if moment:
        titled = moment[:1].upper() + moment[1:]
        out.append(titled)
        out.append(f"What happened in the {moment}")
        out.append(f"{titled} in seconds")
    return [item for item in out if item]


def _length_score(n: int) -> tuple[float, str]:
    if 20 <= n <= 40:
        return 18, "Hook fits the first 40 characters on mobile"
    if 41 <= n <= 60:
        return 20, "Length in the 40-60 character Shorts band"
    if 61 <= n <= 70:
        return 14, "A bit long, but still under 70 characters"
    if 71 <= n <= 100:
        return 8, "Over 70 characters, so mobile will truncate"
    if n < 20:
        return 4, "Too short to carry a keyword and a hook"
    return 2, "Past YouTube's 100 character title cap"


def rank_title(title: str, context: dict | None = None) -> dict:
    context = context or {}
    raw = tidy(title)
    body = body_text(raw)
    n = len(raw)
    words = tokens(body)
    tags = hashtags_in(raw)
    keywords = [item.lower() for item in (context.get("keywords") or [])]
    niche = [item.lower() for item in (context.get("niche") or [])]
    reasons: list[str] = []
    score = 8.0

    length_pts, length_why = _length_score(n)
    score += length_pts
    reasons.append(length_why)

    head = body[:40].lower()
    head_words = tokens(head)[:4]
    keyword_hits = [item for item in keywords[:8] if item in head or item in head_words]
    tag_hits = [item for item in niche if item in {tag.lower() for tag in tags} or item in tokens(raw)]
    if keyword_hits:
        score += 18
        reasons.append(f"Clip keyword up front: {keyword_hits[0]}")
    elif tag_hits:
        score += 12
        reasons.append(f"Clip topic in the title: {tag_hits[0]}")
    else:
        score += 4
        reasons.append("No clip keyword in the first 40 characters")

    pitch_words = {
        item
        for item in tokens(str(context.get("pitch") or ""))
        if item not in FILLER and item not in WEAK_LEAD and len(item) >= 4
    }
    overlap = pitch_words & set(words)
    if len(overlap) >= 2:
        score += 22
        reasons.insert(0, "Matches the editor description")
    elif len(overlap) == 1:
        score += 10
        reasons.insert(0, "Uses a word from the editor description")

    emotion_hits = [word for word in words if word in EMOTION]
    if emotion_hits:
        score += 12
        reasons.append(f"Emotional trigger: {emotion_hits[0]}")
    else:
        score += 3

    proven = False
    if re.search(r"\bbest\b.+\bever\b", body, flags=re.I) or (
        re.search(r"\bever\b", body, flags=re.I) and "best" in words
    ):
        score += 14
        reasons.append("Credibility format: best / ever")
        proven = True
    elif any(frame in body.lower() for frame in ("caught on", "watch this", "pov")):
        score += 13
        reasons.append("Witness / caught-on-camera frame")
        proven = True
    elif words and words[0] in {"how", "why", "wait"}:
        score += 11
        reasons.append("Curiosity format")
        proven = True
    elif words and words[0].isdigit():
        score += 10
        reasons.append("List / number format")
        proven = True
    elif body.endswith("?"):
        score += 8
        reasons.append("Question format")
        proven = True
    else:
        score += 4

    if body and not body.isupper() and not EMOJI_RE.search(raw):
        score += 8
        reasons.append("Clear sentence case, no emoji clutter")
    else:
        score += 1
        if body.isupper() and len(body) > 8:
            reasons.append("All caps reads as spam")
        if EMOJI_RE.search(raw):
            reasons.append("Emojis eat title space on Shorts")

    specific = False
    if any(item in tokens(raw) for item in niche[:3]):
        score += 8
        specific = True
        reasons.append("Specific to this clip, not a generic teaser")
    elif words[:2] == ["this", "game"] or (words and words[0] in {"this", "my", "our"}):
        score += 3
        reasons.append("Opens generic (this / my). A clip noun would rank higher")
    else:
        score += 5

    hash_pts = 6
    if not tags:
        hash_pts = 7
        reasons.append("No hashtags in the title, so the hook keeps the character budget")
    else:
        generic = [tag for tag in tags if tag in GENERIC_TAGS]
        useful = [tag for tag in tags if tag in niche or tag in keywords]
        if len(tags) > 3:
            hash_pts = 1
            reasons.append("More than 3 title hashtags looks like tag stuffing")
        elif generic and not useful:
            hash_pts = 2
            reasons.append("Generic tags (#trending, #fyp) do not help search")
        elif useful:
            hash_pts = 9
            reasons.append("Hashtags match this clip's topic")
            if generic:
                hash_pts -= 3
                reasons.append("Drop #trending / #fyp; keep the niche tags")
        else:
            hash_pts = 4
            reasons.append("Title hashtags are not in this clip's keywords")
        if any(raw.lower().find(f"#{tag}") < 40 for tag in tags):
            hash_pts = max(0, hash_pts - 2)
    score += hash_pts

    if not proven and n >= 20:
        score += 2

    if specific and emotion_hits and 20 <= n <= 70:
        score += 4

    value = int(max(1, min(100, round(score))))
    return {
        "title": raw,
        "score": value,
        "band": band_for(value),
        "reasons": reasons[:5],
    }


def clip_hashtags(context: dict) -> list[str]:
    tags: list[str] = []
    for item in context.get("niche") or []:
        if item and item not in tags:
            tags.append(item)
        if len(tags) >= 2:
            break
    category = context.get("category") or ""
    if category and category not in tags and len(tags) < 3:
        tags.append(category)
    return tags[:3]


def with_hashtags(body: str, context: dict) -> str:
    body = tidy(body)
    tags = clip_hashtags(context)
    if not body or not tags:
        return body
    packed = body + " " + " ".join(f"#{tag}" for tag in tags)
    return packed[:100].rstrip()


def rank_titles(titles: list[str], context: dict) -> list[dict]:
    ranked = [rank_title(item, context) for item in titles if tidy(item)]
    ranked.sort(key=lambda item: -item["score"])
    seen: set[str] = set()
    unique: list[dict] = []
    for item in ranked:
        key = item["title"].lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return unique


def main() -> int:
    payload = json.loads(sys.stdin.read() or "{}")
    context = extract_context(
        str(payload.get("text") or ""),
        source_title=payload.get("sourceTitle"),
        tags=payload.get("tags") or [],
        description=str(payload.get("description") or ""),
    )
    title = str(payload.get("title") or "")
    titles = payload.get("titles") or ([title] if title else [])
    if isinstance(titles, str):
        titles = [titles]
    ranked = rank_titles([str(item) for item in titles], context)
    if len(ranked) == 1:
        sys.stdout.write(json.dumps(ranked[0]))
    else:
        sys.stdout.write(json.dumps({"ranks": ranked, "context": {"topic": context.get("topic"), "niche": context.get("niche")}}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
