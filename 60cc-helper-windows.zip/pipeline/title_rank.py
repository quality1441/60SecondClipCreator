#!/usr/bin/env python3
"""VidIQ-style 0-100 title ranking from clip context.

Modeled on vidIQ Optimize: keyword placement, proven formats, emotional
triggers, character count, grammar/clarity, plus Shorts-specific first-40
visibility. Scores are an optimization estimate, not a ranking guarantee.
Bands match vidIQ: 0-40 red, 41-80 yellow, 81-100 green.
"""

from __future__ import annotations

import json
import re
import sys

GENERIC_TAGS = {
    "explore",
    "explorepage",
    "fyp",
    "foryou",
    "foryoupage",
    "trending",
    "viral",
    "xyzbca",
}

WEAK_LEAD = {
    "already",
    "base",
    "beautiful",
    "boy",
    "driven",
    "good",
    "luck",
    "make",
    "never",
    "okay",
    "right",
    "somebody",
    "these",
    "wait",
    "wow",
    "yeah",
    "nice",
}

FORMAT_TAGS = {"highlight", "short", "shorts", "youtube", "youtubeshorts"}

# Bare "this"/"these" openers measured 0.78x, the weakest lead in the study.
VAGUE_OPENER = {"this", "these", "that", "those", "my", "our"}

EMOTION = {
    "best",
    "crazy",
    "ever",
    "finally",
    "insane",
    "never",
    "secret",
    "wait",
    "why",
    "how",
    "vs",
    "need",
    "love",
    "warning",
    "stop",
}

FILLER = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "but",
    "for",
    "from",
    "i",
    "in",
    "is",
    "it",
    "of",
    "oh",
    "ok",
    "okay",
    "on",
    "so",
    "that's",
    "thats",
    "the",
    "there's",
    "this",
    "to",
    "we",
    "what's",
    "whats",
    "wow",
    "yeah",
    "you",
}

EMOJI_RE = re.compile(
    "["
    "\U0001F300-\U0001FAFF"
    "\U00002700-\U000027BF"
    "\U00002600-\U000026FF"
    "]+",
    flags=re.UNICODE,
)


def tidy(value: str) -> str:
    text = (value or "").replace("\u2014", ",").replace("\u2013", "-")
    text = re.sub(r"\s+", " ", text).strip(" \t\n\r\"'")
    return text


def tokens(text: str) -> list[str]:
    return re.findall(r"[A-Za-z0-9']+", text.lower())


def hashtags_in(text: str) -> list[str]:
    return [item.lower() for item in re.findall(r"#([A-Za-z0-9_]+)", text or "")]


def body_text(title: str) -> str:
    return tidy(re.sub(r"#\S+", "", title or ""))


def band_for(score: int) -> str:
    if score >= 81:
        return "green"
    if score >= 41:
        return "yellow"
    return "red"


def _clip_phrases(words: list[str]) -> list[str]:
    weak_tail = {"look", "like", "got", "get", "know", "dont", "him", "her", "them"}
    scored: dict[str, int] = {}
    for size in (3, 2):
        for index in range(len(words) - size + 1):
            gram = words[index : index + size]
            if any(len(item) < 3 or "'" in item or item in FILLER or item in FORMAT_TAGS or item in GENERIC_TAGS for item in gram):
                continue
            if gram[-1] in weak_tail or gram[-1] in WEAK_LEAD:
                continue
            if all(item in WEAK_LEAD for item in gram):
                continue
            phrase = " ".join(gram)
            scored[phrase] = scored.get(phrase, 0) + (2 if size == 2 else 1)
    return [phrase for phrase, _score in sorted(scored.items(), key=lambda item: (-item[1], item[0]))]


def _hook_line(text: str) -> str:
    chunks = re.split(r"(?<=[.!?])\s+", tidy(text))
    for chunk in chunks:
        words = tokens(chunk)
        content = [item for item in words if item not in FILLER and item not in WEAK_LEAD and len(item) >= 4]
        if len(content) >= 2 and 18 <= len(chunk) <= 90:
            return tidy(chunk).rstrip(",;")
    return ""


def extract_context(
    text: str,
    source_title: str | None = None,
    tags: list[str] | None = None,
    description: str = "",
) -> dict:
    clip_words = tokens(text or "")
    blob_words = tokens(f"{text or ''} {source_title or ''} {description or ''}")
    phrases = _clip_phrases(clip_words)
    counts: dict[str, int] = {}
    for word in clip_words:
        if word in FILLER or word in WEAK_LEAD or len(word) < 4 or "'" in word:
            continue
        counts[word] = counts.get(word, 0) + 1
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    desc_words = tokens(description or "")
    desc_phrases = _clip_phrases(desc_words)
    phrases = [*desc_phrases, *phrases]
    for word in desc_words:
        if word in FILLER or word in WEAK_LEAD or len(word) < 4 or "'" in word:
            continue
        counts[word] = counts.get(word, 0) + 2
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    keywords = [*desc_phrases[:4], *phrases[:4], *[word for word, _count in ranked[:8]]]
    seen_kw: list[str] = []
    for item in keywords:
        if item not in seen_kw:
            seen_kw.append(item)
    keywords = seen_kw[:10]
    supplied = []
    for tag in tags or []:
        clean = tidy(str(tag)).lower().lstrip("#")
        if not clean or clean in FORMAT_TAGS or clean in GENERIC_TAGS:
            continue
        supplied.append(clean)
    niche = []
    for item in supplied + phrases + keywords:
        token = item if " " in item else re.sub(r"[^a-z0-9]", "", item)
        if len(token) < 3 or token in FORMAT_TAGS or token in GENERIC_TAGS or token in WEAK_LEAD:
            continue
        if token not in niche:
            niche.append(token)
        if len(niche) >= 4:
            break
    category = next((item for item in niche if item in {"gaming", "game", "games"}), "")
    if not category and any(word in blob_words for word in ("game", "gaming", "played", "raid")):
        category = "gaming"
    moment = phrases[0] if phrases else ""
    topic = moment or next((item for item in keywords if item not in WEAK_LEAD), "")
    source = tidy(source_title or "")
    if source and source.lower() in {"source", "full video", "untitled", "untitled short"}:
        source = ""
    quality = ""
    for candidate in ("community", "crew", "raid", "run", "squad", "team"):
        if candidate in desc_words or candidate in clip_words:
            quality = candidate
            break
    pitch = tidy(description or "")
    return {
        "keywords": keywords,
        "words": set(blob_words),
        "niche": niche[:3],
        "category": category,
        "topic": topic,
        "moment": moment,
        "hook": _hook_line(pitch) or _hook_line(text or ""),
        "quality": quality,
        "sourceTitle": source,
        "pitch": pitch,
    }


def formula_titles(context: dict) -> list[str]:
    moment = tidy(str(context.get("moment") or context.get("topic") or ""))
    hook = tidy(str(context.get("hook") or ""))
    if moment.lower() in WEAK_LEAD:
        moment = ""
    out: list[str] = []
    if hook and 18 <= len(hook) <= 90:
        out.append(hook[:100])
    if moment:
        titled = moment[:1].upper() + moment[1:]
        out.append(titled)
        out.append(f"What happened in the {moment}")
        out.append(f"{titled} in seconds")
    return [item for item in out if item]


def _length_score(n: int) -> tuple[float, str]:
    # Shorts bands, from measured Shorts titles: top performers average ~49
    # characters and low performers run about 30% longer than that. Nothing in
    # the research says a short title is bad, so only the long end is punished.
    if 44 <= n <= 52:
        return 20, "In the 44-52 character band where top Shorts sit"
    if 30 <= n <= 55:
        return 16, "Inside the 30-55 character Shorts range"
    if 22 <= n <= 29:
        return 11, "Short, which costs nothing in a vertical feed"
    if 56 <= n <= 64:
        return 9, "Longer than most top Shorts, so it costs feed space"
    if n > 64:
        return 4, "Well past the ~49 characters top Shorts average"
    return 4, "Too short to carry the moment and the stakes"


def rank_title(title: str, context: dict | None = None) -> dict:
    context = context or {}
    raw = tidy(title)
    body = body_text(raw)
    n = len(raw)
    words = tokens(body)
    tags = hashtags_in(raw)
    keywords = [item.lower() for item in (context.get("keywords") or [])]
    niche = [item.lower() for item in (context.get("niche") or [])]
    reasons: list[str] = []
    score = 8.0

    length_pts, length_why = _length_score(n)
    score += length_pts
    reasons.append(length_why)

    head = body[:40].lower()
    head_words = tokens(head)[:4]
    keyword_hits = [item for item in keywords[:8] if item in head or item in head_words]
    tag_hits = [item for item in niche if item in {tag.lower() for tag in tags} or item in tokens(raw)]
    if keyword_hits:
        score += 18
        reasons.append(f"Clip keyword up front: {keyword_hits[0]}")
    elif tag_hits:
        score += 12
        reasons.append(f"Clip topic in the title: {tag_hits[0]}")
    else:
        score += 4
        reasons.append("No clip keyword in the first 40 characters")

    pitch_words = {
        item
        for item in tokens(str(context.get("pitch") or ""))
        if item not in FILLER and item not in WEAK_LEAD and len(item) >= 4
    }
    overlap = pitch_words & set(words)
    if len(overlap) >= 2:
        score += 22
        reasons.insert(0, "Matches the editor description")
    elif len(overlap) == 1:
        score += 10
        reasons.insert(0, "Uses a word from the editor description")

    emotion_hits = [word for word in words if word in EMOTION]
    if emotion_hits:
        score += 12
        reasons.append(f"Emotional trigger: {emotion_hits[0]}")
    else:
        score += 3

    proven = False
    if re.search(r"\bbest\b.+\bever\b", body, flags=re.I) or (
        re.search(r"\bever\b", body, flags=re.I) and "best" in words
    ):
        score += 14
        reasons.append("Credibility format: best / ever")
        proven = True
    elif any(frame in body.lower() for frame in ("caught on", "watch this", "pov")):
        score += 13
        reasons.append("Witness / caught-on-camera frame")
        proven = True
    elif words and words[0] in {"how", "why", "wait"}:
        score += 9
        reasons.append("Curiosity opener, without a question mark")
        proven = True
    elif words and words[0].isdigit():
        score += 4
        reasons.append("Number led. Fine on long video, weak on a Short")
        proven = True
    elif body.endswith("?"):
        score -= 6
        reasons.append("Question format. Only ~7% of top Shorts use one")
    else:
        score += 6

    if body and not body.isupper():
        score += 6
        reasons.append("Sentence case reads as more trustworthy")
    else:
        score += 1
        if body.isupper() and len(body) > 8:
            reasons.append("All caps reads as spam")
    marks = len(EMOJI_RE.findall(raw))
    if 1 <= marks <= 2:
        score += 10
        reasons.append("One or two emoji act as a visual anchor in the feed")
    elif marks > 2:
        score -= 6
        reasons.append("More than two emoji crowds out the words")

    specific = False
    if any(item in tokens(raw) for item in niche[:3]):
        score += 8
        specific = True
        reasons.append("Specific to this clip, not a generic teaser")
    elif words and words[0] in VAGUE_OPENER:
        score -= 4
        reasons.append(f"Opens on '{words[0]}', which measured weakest of any lead (0.78x)")
    else:
        score += 5

    hash_pts = 6
    if not tags:
        hash_pts = 7
        reasons.append("No hashtags in the title, so the hook keeps the character budget")
    else:
        generic = [tag for tag in tags if tag in GENERIC_TAGS]
        useful = [tag for tag in tags if tag in niche or tag in keywords]
        if len(tags) > 3:
            hash_pts = 1
            reasons.append("More than 3 title hashtags looks like tag stuffing")
        elif generic and not useful:
            hash_pts = 2
            reasons.append("Generic tags (#trending, #fyp) do not help search")
        elif useful:
            hash_pts = 9
            reasons.append("Hashtags match this clip's topic")
            if generic:
                hash_pts -= 3
                reasons.append("Drop #trending / #fyp; keep the niche tags")
        else:
            hash_pts = 4
            reasons.append("Title hashtags are not in this clip's keywords")
        if any(raw.lower().find(f"#{tag}") < 40 for tag in tags):
            hash_pts = max(0, hash_pts - 2)
    score += hash_pts

    if not proven and n >= 20:
        score += 2

    if specific and emotion_hits and 20 <= n <= 70:
        score += 4

    value = int(max(1, min(100, round(score))))
    return {
        "title": raw,
        "score": value,
        # The weights above add up past 100 for a strong title, so `score` is
        # clamped for display and stops telling two good titles apart. The raw
        # total is what rank_titles sorts on, otherwise every candidate lands
        # on 100 and the winner is decided by whatever order the model replied.
        "rawScore": round(score, 1),
        "band": band_for(value),
        "reasons": reasons[:5],
    }


def clip_hashtags(context: dict) -> list[str]:
    tags: list[str] = []
    for item in context.get("niche") or []:
        if item and item not in tags:
            tags.append(item)
        if len(tags) >= 2:
            break
    category = context.get("category") or ""
    if category and category not in tags and len(tags) < 3:
        tags.append(category)
    return tags[:3]


def with_hashtags(body: str, context: dict) -> str:
    body = tidy(body)
    tags = clip_hashtags(context)
    if not body or not tags:
        return body
    packed = body + " " + " ".join(f"#{tag}" for tag in tags)
    return packed[:100].rstrip()


def rank_titles(titles: list[str], context: dict) -> list[dict]:
    ranked = [rank_title(item, context) for item in titles if tidy(item)]
    # Sort on the unclamped total. `score` is capped at 100 for display, so
    # sorting on it made every strong candidate tie and left the choice to
    # reply order rather than to the rules.
    ranked.sort(key=lambda item: -item["rawScore"])
    seen: set[str] = set()
    unique: list[dict] = []
    for item in ranked:
        key = item["title"].lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return unique


# Words that carry no distinguishing weight when comparing two titles. Left in,
# "Losing the best hammer" and "Lost best hammer" look like near duplicates
# partly because of the filler they share.
_TITLE_NOISE = {
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "to", "in",
    "on", "of", "and", "for", "with", "at", "it", "its", "this", "that",
    "these", "those", "my", "your", "i", "you", "we", "they", "he", "she",
    "me", "him", "her", "them", "us", "do", "does", "did", "have", "has",
    "had", "get", "got", "go", "going", "just", "so", "then", "than", "now",
    "not", "no", "but", "if", "out", "up", "down", "over", "about",
}


def title_content_tokens(title: str) -> set[str]:
    """Distinctive words in a title, for comparing one title to another."""
    return {word for word in tokens(body_text(title)) if word not in _TITLE_NOISE}


def title_similarity(left: str, right: str) -> float:
    """0.0 for unrelated titles, 1.0 when one title's words cover the other.

    Overlap rather than Jaccard, because the near-duplicates that matter here
    are usually a short title sitting inside a longer one. "Actually Getting
    Control Points" against "Actually getting control points feels good" shares
    every content word of the first; Jaccard calls that 0.67, overlap calls it
    1.0. Jaccard also rated four titles all about the same lost hammer at only
    0.33, which is why the first attempt at this changed nothing.
    """
    a = title_content_tokens(left)
    b = title_content_tokens(right)
    if not a or not b:
        return 0.0
    return len(a & b) / min(len(a), len(b))


def subject_nouns(title: str, context: dict | None = None) -> set[str]:
    """The words that carry what the title is actually about.

    Two titles on one idea usually reuse the same noun even when the phrasing
    differs, which is how "losing the best hammer" and "best hammer loss" get
    caught. Words the clip is already known by are used when present; failing
    that the longest content word stands in for the subject.
    """
    words = title_content_tokens(title)
    if not words:
        return set()
    known = {
        str(item).lower()
        for item in list((context or {}).get("keywords") or []) + list((context or {}).get("niche") or [])
    }
    hits = words & known
    return hits or {max(words, key=len)}


def select_diverse_titles(
    ranked: list[dict],
    limit: int = 4,
    near_duplicate: float = 0.5,
    context: dict | None = None,
) -> list[dict]:
    """Keep the best title, then choose the rest for saying something new.

    Taking the four highest scores tends to return four phrasings of one idea,
    which makes the alternatives useless: the reader is shown the same
    suggestion four times. So the first pick is always the best scorer, and
    after that a candidate has to clear two bars. It cannot restate something
    already chosen, and it is preferred if it does not reuse a subject the
    earlier picks have used. A lower-scoring title that opens a different angle
    beats a stronger one that merely repeats the winner.

    If the pool runs short of titles clearing both bars the rules relax instead
    of returning fewer options, because four imperfect options beat one good
    one.
    """
    pool = [item for item in ranked if tidy(item.get("title") or "")]
    if not pool:
        return []
    ordered = sorted(pool, key=lambda item: -item["rawScore"])
    chosen: list[dict] = []
    used_subjects: set[str] = set()

    def closest_to_chosen(item: dict) -> float:
        if not chosen:
            return 0.0
        return max(title_similarity(item["title"], picked["title"]) for picked in chosen)

    for _ in range(limit):
        rest = [item for item in ordered if not any(item is seen for seen in chosen)]
        if not rest:
            break
        fresh = [item for item in rest if closest_to_chosen(item) < near_duplicate]
        if fresh:
            best = max(
                fresh,
                key=lambda item: (
                    not (subject_nouns(item["title"], context) & used_subjects),
                    item["rawScore"],
                ),
            )
        else:
            # Nothing distinct left. Take the least repetitive so the set still grows.
            best = min(rest, key=lambda item: (closest_to_chosen(item), -item["rawScore"]))
        chosen.append(best)
        used_subjects |= subject_nouns(best["title"], context)
    return chosen


def main() -> int:
    payload = json.loads(sys.stdin.read() or "{}")
    context = extract_context(
        str(payload.get("text") or ""),
        source_title=payload.get("sourceTitle"),
        tags=payload.get("tags") or [],
        description=str(payload.get("description") or ""),
    )
    title = str(payload.get("title") or "")
    titles = payload.get("titles") or ([title] if title else [])
    if isinstance(titles, str):
        titles = [titles]
    ranked = rank_titles([str(item) for item in titles], context)
    if len(ranked) == 1:
        sys.stdout.write(json.dumps(ranked[0]))
    else:
        sys.stdout.write(json.dumps({"ranks": ranked, "context": {"topic": context.get("topic"), "niche": context.get("niche")}}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
