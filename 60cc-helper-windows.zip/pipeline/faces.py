"""Find a still face in a Short window. Prints JSON. No tracking."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

try:
    import cv2
    import numpy as np
except ImportError:
    cv2 = None
    np = None


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return min(hi, max(lo, float(value)))


def _cascade():
    if cv2 is None:
        return None
    name = "haarcascade_frontalface_default.xml"
    bundled = getattr(cv2.data, "haarcascades", "")
    path = Path(bundled) / name if bundled else Path(name)
    if not path.is_file():
        return None
    detector = cv2.CascadeClassifier(str(path))
    if detector.empty():
        return None
    return detector


def _grab_frame(source: Path, at: float, width: int = 640) -> tuple[np.ndarray | None, float]:
    with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as handle:
        dest = Path(handle.name)
    try:
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-nostdin",
            "-loglevel",
            "error",
            "-ss",
            f"{max(0.0, at):.3f}",
            "-i",
            str(source),
            "-frames:v",
            "1",
            "-vf",
            f"scale={width}:-2",
            "-y",
            str(dest),
        ]
        subprocess.run(cmd, check=False, capture_output=True, timeout=20)
        image = cv2.imread(str(dest))
        return image, width / max(image.shape[1], 1) if image is not None else 1.0
    except (OSError, subprocess.TimeoutExpired, cv2.error):
        return None, 1.0
    finally:
        try:
            dest.unlink(missing_ok=True)
        except OSError:
            pass


def _faces(detector: cv2.CascadeClassifier, image: np.ndarray) -> list[tuple[int, int, int, int]]:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)
    found = detector.detectMultiScale(gray, scaleFactor=1.12, minNeighbors=5, minSize=(28, 28))
    return [(int(x), int(y), int(w), int(h)) for x, y, w, h in found]


def _sample_times(start: float, end: float, count: int = 5) -> list[float]:
    lo = float(start) + 0.2
    hi = max(lo + 0.2, float(end) - 0.2)
    if count <= 1 or hi <= lo:
        return [lo]
    return [lo + (hi - lo) * i / (count - 1) for i in range(count)]


def _pick_face(hits: list[tuple[float, float, float, float]]) -> tuple[float, float, float, float] | None:
    if not hits:
        return None
    scored: list[tuple[float, tuple[float, float, float, float]]] = []
    for box in hits:
        area = box[2] * box[3]
        cx, cy = box[0] + box[2] / 2, box[1] + box[3] / 2
        stable = sum(
            1
            for other in hits
            if abs((other[0] + other[2] / 2) - cx) < 0.12 and abs((other[1] + other[3] / 2) - cy) < 0.12
        )
        scored.append((area * (1 + 0.35 * stable), box))
    scored.sort(key=lambda item: item[0], reverse=True)
    return scored[0][1]


def _expand(box: tuple[float, float, float, float], pad: float = 0.42) -> dict:
    x, y, w, h = box
    cx, cy = x + w / 2, y + h / 2
    nw, nh = min(1.0, w * (1 + pad)), min(1.0, h * (1 + pad * 1.15))
    nx = _clamp(cx - nw / 2)
    ny = _clamp(cy - nh / 2)
    nw = min(nw, 1.0 - nx)
    nh = min(nh, 1.0 - ny)
    return {"x": round(nx, 4), "y": round(ny, 4), "w": round(nw, 4), "h": round(nh, 4)}


def pan_from_face(width: int, height: int, box: dict) -> tuple[float, float]:
    cx = (box["x"] + box["w"] / 2) * width
    cy = (box["y"] + box["h"] / 2) * height
    target = 9 / 16
    if width / max(height, 1) > target + 0.01:
        crop_w = height * 9 / 16
        span = max(1.0, width - crop_w)
        return _clamp((cx - crop_w / 2) / span), 0.5
    if width / max(height, 1) < target - 0.01:
        crop_h = width * 16 / 9
        span = max(1.0, height - crop_h)
        return 0.5, _clamp((cy - crop_h / 2) / span)
    return 0.5, 0.5


def detect_face(source: Path, start: float, end: float) -> dict:
    detector = _cascade()
    if detector is None:
        return {"found": False, "error": "Could not load a face finder on your computer."}
    hits: list[tuple[float, float, float, float]] = []
    src_w = src_h = 0
    for at in _sample_times(start, end):
        image, _scale = _grab_frame(source, at)
        if image is None:
            continue
        ih, iw = image.shape[:2]
        if not src_w:
            probe = subprocess.run(
                [
                    "ffprobe",
                    "-v",
                    "error",
                    "-select_streams",
                    "v:0",
                    "-show_entries",
                    "stream=width,height",
                    "-of",
                    "json",
                    str(source),
                ],
                capture_output=True,
                text=True,
                timeout=20,
                check=False,
            )
            try:
                streams = json.loads(probe.stdout or "{}").get("streams") or []
                src_w = int(streams[0]["width"])
                src_h = int(streams[0]["height"])
            except (KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError):
                src_w, src_h = iw, ih
        sx = src_w / max(iw, 1)
        sy = src_h / max(ih, 1)
        for x, y, w, h in _faces(detector, image):
            hits.append(((x * sx) / src_w, (y * sy) / src_h, (w * sx) / src_w, (h * sy) / src_h))
    picked = _pick_face(hits)
    if picked is None or src_w < 2 or src_h < 2:
        return {"found": False, "error": "Could not find a webcam in this window. Draw the area on the video.", "width": src_w, "height": src_h}
    box = _expand(picked)
    crop_x, crop_y = pan_from_face(src_w, src_h, box)
    return {
        "found": True,
        "cropX": round(crop_x, 4),
        "cropY": round(crop_y, 4),
        "faceBox": box,
        "gameBox": {"x": 0, "y": 0, "w": 1, "h": 1},
        "width": src_w,
        "height": src_h,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--source")
    parser.add_argument("--start", type=float)
    parser.add_argument("--end", type=float)
    args = parser.parse_args()
    if args.check:
        ok = cv2 is not None and _cascade() is not None
        print(
            json.dumps(
                {
                    "ok": ok,
                    "error": None
                    if ok
                    else "Find webcam is not available. Draw the area on the video.",
                }
            )
        )
        return
    if not args.source or args.start is None or args.end is None:
        print(json.dumps({"found": False, "error": "Find webcam is not available. Draw the area on the video."}))
        sys.exit(0)
    source = Path(args.source)
    if not source.is_file():
        print(json.dumps({"found": False, "error": "No source video for this job."}))
        sys.exit(0)
    if cv2 is None or _cascade() is None:
        print(json.dumps({"found": False, "error": "Find webcam is not available. Draw the area on the video."}))
        sys.exit(0)
    try:
        payload = detect_face(source, args.start, args.end)
    except Exception as exc:
        payload = {"found": False, "error": "Could not find a webcam in this window."}
        print(str(exc), file=sys.stderr)
    print(json.dumps(payload))


if __name__ == "__main__":
    main()
