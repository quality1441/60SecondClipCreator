#!/usr/bin/env python3
"""60 Second Clip Creator pipeline: fetch, transcribe, pick highlights, render 9:16 clips."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qs, urlparse

_PIPELINE_DIR = Path(__file__).resolve().parent
if str(_PIPELINE_DIR) not in sys.path:
    sys.path.insert(0, str(_PIPELINE_DIR))

from captions import apply_cue_hold, cue_groups, default_caption_style, normalize_style, write_ass
from clip_edits import (
    build_edit_filter,
    clip_pieces,
    output_duration,
    remap_caption_cues,
    remap_words,
    saved_caption_words,
    simple_render,
)
from diarize import assign_speakers, stamp_segments, unique_voices
from asr import (
    WHISPER_MODEL as ASR_MODEL,
    speaker2_gate,
    transcript_can_resume,
    transcript_is_complete,
    transcript_last_end,
    transcribe_dual,
    transcribe_resume,
)
from laughter import detect_laughter, laugh_overlap_seconds
from scenes import cuts_in_window, detect_scene_cuts, first_cut_in_window

WHISPER_MODEL = ASR_MODEL


HOOK_WORDS = {
    "absolutely",
    "actually",
    "amazing",
    "awesome",
    "because",
    "bruh",
    "christ",
    "cinema",
    "clutch",
    "cooked",
    "crazy",
    "damn",
    "dude",
    "finally",
    "fire",
    "god",
    "goated",
    "gosh",
    "hell",
    "holy",
    "how",
    "huge",
    "hype",
    "important",
    "insane",
    "incredible",
    "jesus",
    "legendary",
    "lit",
    "look",
    "lord",
    "massive",
    "mistake",
    "never",
    "nuts",
    "omg",
    "peak",
    "perfect",
    "remember",
    "ridiculous",
    "secret",
    "sick",
    "stop",
    "tip",
    "trick",
    "unbelievable",
    "unhinged",
    "unreal",
    "wait",
    "warning",
    "watch",
    "whoa",
    "why",
    "wild",
    "woah",
    "wow",
}

FONT_DIR = None  # resolved below


def resolve_font_dir() -> Path:
    repo = Path(__file__).resolve().parents[1] / "fonts"
    if any(repo.glob("*.ttf")):
        return repo
    linux = Path("/usr/share/fonts/truetype/liberation")
    if linux.is_dir():
        return linux
    truetype = Path("/usr/share/fonts/truetype")
    if truetype.is_dir():
        return truetype
    windir = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
    if windir.is_dir():
        return windir
    return repo


FONT_DIR = resolve_font_dir()
WHISPER_MODEL = os.environ.get("CUTLINE_WHISPER_MODEL", ASR_MODEL)
ENCODE_PRESET = os.environ.get("CUTLINE_X264_PRESET", "veryslow")
ENCODE_CRF = os.environ.get("CUTLINE_X264_CRF", "14")
DRAFT_PRESET = os.environ.get("CUTLINE_X264_DRAFT_PRESET", "medium")
DRAFT_CRF = os.environ.get("CUTLINE_X264_DRAFT_CRF", "18")
ENCODE_AUDIO_BITRATE = os.environ.get("CUTLINE_AUDIO_BITRATE", "320k")
FULL_VIDEO_MAX_SECONDS = float(os.environ.get("CUTLINE_FULL_VIDEO_MAX_SECONDS", "180"))
YTDLP_FORMAT = os.environ.get(
    "CUTLINE_YTDLP_FORMAT",
    "bv*[height>=720][height<=2160]+ba/bv*[height<=2160]+ba/b[height>=720]/b",
)
YTDLP_SORT = os.environ.get("CUTLINE_YTDLP_SORT", "res:2160,fps")
MIN_SOURCE_HEIGHT = int(os.environ.get("CUTLINE_MIN_SOURCE_HEIGHT", "720"))
OUT_SIZES = ((720, 1280), (1080, 1920), (1440, 2560), (2160, 3840))


TIMED_STAGES = frozenset({"queued", "downloading", "transcribing", "scoring", "rendering"})


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def parse_iso(value: object) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def elapsed_seconds(started: object, ended: object | None = None) -> float | None:
    start = parse_iso(started)
    if start is None:
        return None
    finish = parse_iso(ended) if ended is not None else datetime.now(timezone.utc)
    if finish is None:
        finish = datetime.now(timezone.utc)
    return max(0.0, (finish - start).total_seconds())


def read_json(path: Path, fallback=None):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError, TypeError, UnicodeError):
        return {} if fallback is None else fallback


def write_status(job_dir: Path, **updates) -> dict:
    path = job_dir / "status.json"
    data: dict = {}
    if path.exists():
        loaded = read_json(path, {})
        if isinstance(loaded, dict):
            data = loaded
    previous_stage = data.get("stage")
    previous_started = data.get("stageStartedAt")
    previous_total = data.get("totalDuration")
    timings = dict(data["stageDurations"]) if isinstance(data.get("stageDurations"), dict) else {}
    now = utc_now()
    data.update(updates)
    data["updatedAt"] = now
    next_stage = data.get("stage")
    if next_stage == "queued" and previous_stage not in (None, "queued"):
        timings = {}
        previous_total = None
        data["totalDuration"] = None
    if next_stage != previous_stage:
        if previous_stage in TIMED_STAGES:
            freeze = previous_total is not None and previous_stage in timings
            if not freeze:
                elapsed = elapsed_seconds(previous_started, now)
                if elapsed is not None:
                    timings[previous_stage] = round(elapsed, 1)
        if next_stage in ("done", "error"):
            data["stageStartedAt"] = None
            if previous_total is None:
                total = elapsed_seconds(data.get("createdAt"), now)
                if total is not None:
                    data["totalDuration"] = round(total, 1)
            else:
                data["totalDuration"] = previous_total
        else:
            data["stageStartedAt"] = now
    elif data.get("stageStartedAt") in (None, "") and next_stage not in ("done", "error", None):
        data["stageStartedAt"] = now
    data["stageDurations"] = timings
    if next_stage != previous_stage:
        for key in ("detailPercent", "detailLabel", "bytesDone", "bytesTotal", "etaSeconds", "speedLabel"):
            if key not in updates:
                data[key] = None
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(path)
    return data


_STATUS_TICK: dict[str, tuple[float, str | None]] = {}


def write_status_throttled(job_dir: Path, interval: float = 0.5, **updates) -> dict | None:
    key = str(job_dir.resolve())
    now = time.monotonic()
    last_time, last_stage = _STATUS_TICK.get(key, (0.0, None))
    stage = updates.get("stage")
    current_stage = stage if stage is not None else last_stage
    if now - last_time < interval and current_stage == last_stage:
        return None
    _STATUS_TICK[key] = (now, current_stage)
    return write_status(job_dir, **updates)


def mark_saved(job_dir: Path, step: str) -> None:
    status = read_json(job_dir / "status.json", {})
    steps = status.get("savedSteps")
    if not isinstance(steps, list):
        steps = []
    if step not in steps:
        steps.append(step)
    write_status(job_dir, savedSteps=steps, savedAt=utc_now())


def minutes_clock(seconds: float) -> str:
    total = max(0, int(round(float(seconds))))
    minutes = total // 60
    if minutes < 1:
        return f"{total}s"
    if minutes < 120:
        return f"{minutes} min"
    hours = minutes // 60
    rest = minutes % 60
    if rest:
        return f"{hours} hr {rest} min"
    return f"{hours} hr"


def heard_label(heard: float, total: float) -> str:
    if total <= 0:
        return minutes_clock(heard)
    return f"{minutes_clock(heard)} of {minutes_clock(total)}"


YT_DOWNLOAD_RE = re.compile(
    r"\[download\]\s+(?P<pct>[\d.]+)%"
    r"(?:\s+of\s+~?\s*(?P<total>[\d.]+\s*[KMGTkmgt]?i?B))?"
    r"(?:\s+at\s+(?P<speed>[\d.]+\s*[KMGTkmgt]?i?B/s))?"
    r"(?:\s+ETA\s+(?P<eta>[\d:]+))?",
)


def parse_size_bytes(text: str | None) -> int | None:
    if not text:
        return None
    match = re.match(r"([\d.]+)\s*([KMGTkmgt]?)i?B", text.strip())
    if not match:
        return None
    amount = float(match.group(1))
    unit = match.group(2).upper()
    scale = {"": 1, "K": 1024, "M": 1024**2, "G": 1024**3, "T": 1024**4}.get(unit, 1)
    return int(amount * scale)


def parse_eta_seconds(text: str | None) -> int | None:
    if not text:
        return None
    parts = text.strip().split(":")
    try:
        nums = [int(part) for part in parts]
    except ValueError:
        return None
    if len(nums) == 3:
        return nums[0] * 3600 + nums[1] * 60 + nums[2]
    if len(nums) == 2:
        return nums[0] * 60 + nums[1]
    if len(nums) == 1:
        return nums[0]
    return None


def run(cmd: list[str], cwd: Path | None = None) -> None:
    print("+", " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=cwd, check=True)


def _subprocess_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def probe_media(path: Path) -> dict:
    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-print_format",
            "json",
            "-show_format",
            "-show_streams",
            str(path),
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    raw = (result.stdout or "").strip()
    if result.returncode != 0:
        detail = (result.stderr or raw).strip()
        raise RuntimeError(
            "The source video could not be read. Click Discover Shorts to finish the file."
            + (f" {detail[:180]}" if detail and "{" not in detail else "")
        )
    try:
        info = json.loads(raw or "{}")
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            "The source video could not be read. Click Discover Shorts to finish the file."
        ) from exc
    width = height = None
    duration = None
    has_audio = False
    has_video = False
    for stream in info.get("streams") or []:
        kind = stream.get("codec_type")
        if kind == "audio":
            has_audio = True
        if kind == "video":
            if (stream.get("disposition") or {}).get("attached_pic"):
                continue
            try:
                stream_w = int(stream.get("width") or 0)
                stream_h = int(stream.get("height") or 0)
            except (TypeError, ValueError):
                continue
            if stream_w < 2 or stream_h < 2:
                continue
            if width is None or stream_w * stream_h > int(width) * int(height):
                has_video = True
                width = stream_w
                height = stream_h
                if stream.get("duration"):
                    try:
                        duration = float(stream["duration"])
                    except (TypeError, ValueError):
                        pass
    if duration is None:
        try:
            duration = float((info.get("format") or {}).get("duration") or 0)
        except (TypeError, ValueError):
            duration = 0.0
    if not has_video or float(duration or 0) < 1:
        raise RuntimeError(
            "The source video is incomplete. Click Discover Shorts to finish the file."
        )
    return {
        "width": width,
        "height": height,
        "duration": duration,
        "has_audio": has_audio,
        "has_video": has_video,
    }


def friendly_error(exc: BaseException) -> str:
    chunks = [_subprocess_text(exc)]
    if isinstance(exc, subprocess.CalledProcessError):
        chunks.append(_subprocess_text(exc.stderr))
        chunks.append(_subprocess_text(exc.stdout))
    combined = "\n".join(part for part in chunks if part.strip())
    low = combined.lower()
    if "sign in to confirm" in low or "not a bot" in low:
        return (
            "YouTube blocked the download (bot check). Export cookies from a logged-in "
            "browser to data/youtube-cookies.txt, or set YTDLP_COOKIES to that file, then retry."
        )
    if "unplayable" in low or "this video is not available" in low:
        return (
            "YouTube says this video is not available from this network. It may be "
            "unlisted, region-locked, still processing, or limited to signed-in viewers."
        )
    if "does not contain any stream" in low or "output file does not contain any stream" in low:
        return (
            "The source file has no audio track yet (video-only YouTube fragment). "
            "Click Discover Shorts again to finish downloading audio and mux it."
        )
    if "ffmpeg" in low and "not found" in low:
        return "ffmpeg is not installed. Install ffmpeg and retry."
    if "yt-dlp" in low and "not found" in low:
        return "yt-dlp is not installed. Create the Python venv from requirements.txt and retry."
    last = combined.strip().splitlines()[-1].strip()[:500] if combined.strip() else ""
    if (
        not last
        or last.startswith("b'")
        or last.startswith('b"')
        or last.startswith("{")
        or last.startswith("[")
        or last.startswith("Command '[")
        or last.startswith("Command \"[")
    ):
        return "The source video could not be read. Click Discover Shorts to finish the file."
    return last


def jobs_root() -> Path:
    return Path(__file__).resolve().parents[1] / "data" / "jobs"


def youtube_video_id(url: str | None) -> str | None:
    if not url:
        return None
    text = url.strip()
    if not text:
        return None
    if not re.match(r"^https?://", text, re.I):
        text = "https://" + text
    try:
        parsed = urlparse(text)
    except ValueError:
        return None
    host = (parsed.hostname or "").lower()
    if host == "youtu.be":
        candidate = parsed.path.strip("/").split("/")[0]
        return candidate if re.fullmatch(r"[\w-]{11}", candidate or "") else None
    if "youtube.com" not in host:
        return None
    query_id = parse_qs(parsed.query).get("v", [None])[0]
    if query_id and re.fullmatch(r"[\w-]{11}", query_id):
        return query_id
    parts = [part for part in parsed.path.split("/") if part]
    if len(parts) >= 2 and parts[0] in {"shorts", "embed", "live"} and re.fullmatch(
        r"[\w-]{11}", parts[1]
    ):
        return parts[1]
    return None


def source_height(path: Path) -> int:
    try:
        return int(probe_media(path).get("height") or 0)
    except (OSError, subprocess.CalledProcessError, KeyError, TypeError, ValueError):
        return 0


def clear_job_source(job_dir: Path) -> None:
    for path in job_dir.glob("source.*"):
        suffix = path.suffix.lower()
        if suffix in {".mp4", ".mkv", ".webm", ".mov", ".m4a"} or path.name.endswith(".json"):
            path.unlink(missing_ok=True)


def find_cached_source(url: str | None, exclude: Path | None = None) -> Path | None:
    video_id = youtube_video_id(url)
    if not video_id:
        return None
    root = jobs_root()
    if not root.is_dir():
        return None
    skip = exclude.resolve() if exclude else None
    matches: list[tuple[int, float, Path]] = []
    for job in root.iterdir():
        if not job.is_dir():
            continue
        if skip and job.resolve() == skip:
            continue
        status_path = job / "status.json"
        if not status_path.is_file():
            continue
        try:
            payload = json.loads(status_path.read_text())
        except (OSError, json.JSONDecodeError):
            continue
        if youtube_video_id(payload.get("url")) != video_id:
            continue
        for candidate in (
            job / "source.mp4",
            job / "source.mkv",
            job / "source.webm",
            job / "source.mov",
        ):
            if not candidate.is_file():
                continue
            media = None
            try:
                media = probe_media(candidate)
            except (OSError, subprocess.CalledProcessError, KeyError, TypeError, ValueError, json.JSONDecodeError):
                break
            height = int(media.get("height") or 0)
            if height < MIN_SOURCE_HEIGHT or not media.get("has_audio"):
                break
            matches.append((height, candidate.stat().st_mtime, candidate))
            break
    if not matches:
        return None
    matches.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return matches[0][2]


def has_audio_stream(path: Path | None) -> bool:
    if not path or not path.is_file():
        return False
    try:
        return bool(probe_media(path).get("has_audio"))
    except (OSError, subprocess.CalledProcessError, KeyError, TypeError, ValueError, json.JSONDecodeError):
        return False


def ytdlp_fragments(job_dir: Path) -> tuple[Path | None, Path | None]:
    video = None
    audio = None
    for path in sorted(job_dir.glob("source.f*")):
        if not path.is_file() or path.name.endswith(".part"):
            continue
        try:
            media = probe_media(path)
        except (OSError, subprocess.CalledProcessError, KeyError, TypeError, ValueError, json.JSONDecodeError):
            continue
        if media.get("has_video") and not media.get("has_audio") and video is None:
            video = path
        elif media.get("has_audio") and audio is None:
            audio = path
    return video, audio


def mux_video_audio(video: Path, audio: Path, dest: Path) -> Path:
    run(
        [
            "ffmpeg",
            "-y",
            "-i",
            str(video),
            "-i",
            str(audio),
            "-c",
            "copy",
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-shortest",
            "-movflags",
            "+faststart",
            str(dest),
        ]
    )
    return dest


def merged_source(job_dir: Path) -> Path | None:
    for candidate in (
        job_dir / "source.mp4",
        job_dir / "source.mkv",
        job_dir / "source.webm",
        job_dir / "source.mov",
    ):
        if candidate.is_file() and has_audio_stream(candidate):
            return candidate
    video, audio = ytdlp_fragments(job_dir)
    if video and audio:
        return mux_video_audio(video, audio, job_dir / "source.mp4")
    return None


SOURCE_NAMES = ("source.mp4", "source.mkv", "source.webm", "source.mov")


def cached_source_path(job_dir: Path, source_file: str | None = None) -> Path | None:
    candidates: list[Path] = []
    if source_file:
        candidates.append(Path(source_file))
    status = read_json(job_dir / "status.json", {})
    stored = status.get("sourceFile") if isinstance(status, dict) else None
    if stored:
        candidates.append(Path(str(stored)))
    seen: set[str] = set()
    for item in candidates:
        try:
            resolved = item.resolve()
        except OSError:
            continue
        key = str(resolved).lower() if os.name == "nt" else str(resolved)
        if key in seen or not resolved.is_file():
            continue
        seen.add(key)
        return resolved
    for name in SOURCE_NAMES:
        path = job_dir / name
        if not (path.is_file() or path.is_symlink()):
            continue
        try:
            if path.resolve().is_file():
                return path
        except OSError:
            if path.is_file():
                return path
    return None


def drop_job_source_alias(job_dir: Path, original: Path) -> None:
    """Remove an alias to a local source in the job folder. Never delete a real source file."""
    try:
        origin = original.resolve()
    except OSError:
        origin = original
    for name in SOURCE_NAMES:
        dest = job_dir / name
        if not (dest.exists() or dest.is_symlink()):
            continue
        try:
            if dest.resolve() == origin:
                continue
        except OSError:
            pass
        if dest.is_symlink():
            try:
                dest.unlink()
            except OSError:
                pass
            continue
        try:
            links = dest.stat().st_nlink
        except OSError:
            continue
        if links and links > 1:
            try:
                dest.unlink()
            except OSError:
                pass


def materialize_source(source: Path, job_dir: Path, *, copy_if_needed: bool = True) -> Path:
    dest = job_dir / "source.mp4"
    resolved = source.resolve()
    if resolved == dest.resolve():
        return dest
    if copy_if_needed and not has_audio_stream(source):
        raise RuntimeError(
            f"{source.name} has no audio track. Finish the YouTube fetch so video and audio can be muxed."
        )
    if dest.exists() or dest.is_symlink():
        dest.unlink()
    try:
        os.link(resolved, dest)
        return dest
    except OSError:
        pass
    try:
        os.symlink(resolved, dest)
        return dest
    except OSError:
        pass
    if copy_if_needed:
        shutil.copy2(resolved, dest)
        return dest
    return resolved


def same_fs_path(left: Path, right: Path) -> bool:
    try:
        a = str(left.resolve())
        b = str(right.resolve())
    except OSError:
        return False
    if os.name == "nt":
        return a.lower() == b.lower()
    return a == b


def same_media_file(left: Path, right: Path) -> bool:
    if same_fs_path(left, right):
        return True
    try:
        a = left.stat()
        b = right.stat()
    except OSError:
        return False
    if a.st_ino and a.st_dev and a.st_ino == b.st_ino and a.st_dev == b.st_dev:
        return True
    return a.st_size == b.st_size and int(a.st_mtime) == int(b.st_mtime) and a.st_size > 1_000_000


def adopt_cached_transcript(job_dir: Path, origin: Path | None = None) -> None:
    dest = job_dir / "transcript.json"
    if dest.is_file() and dest.stat().st_size > 64:
        return
    folders: list[Path] = []
    origin_resolved = origin.resolve() if origin is not None else None
    if origin_resolved is not None:
        folders.append(origin_resolved.parent)
    jobs_root = job_dir.parent
    if jobs_root.is_dir() and origin_resolved is not None:
        for folder in jobs_root.iterdir():
            if not folder.is_dir() or same_fs_path(folder, job_dir):
                continue
            cached = folder / "source.mp4"
            if cached.is_file() and same_media_file(cached, origin_resolved):
                folders.append(folder)
    seen: set[str] = set()
    for folder in folders:
        candidate = folder / "transcript.json"
        try:
            resolved = candidate.resolve()
            key = str(resolved).lower() if os.name == "nt" else str(resolved)
        except OSError:
            continue
        if key in seen:
            continue
        seen.add(key)
        if not candidate.is_file() or candidate.stat().st_size < 64:
            continue
        if same_fs_path(candidate, dest):
            continue
        shutil.copy2(candidate, dest)
        return


def parse_caption_style(raw: str | None) -> dict:
    if not raw:
        return default_caption_style()
    try:
        return normalize_style(json.loads(raw))
    except json.JSONDecodeError:
        return default_caption_style()


def cookies_path() -> Path | None:
    env = os.environ.get("YTDLP_COOKIES")
    candidates = []
    if env:
        candidates.append(Path(env).expanduser())
    repo_root = Path(__file__).resolve().parents[1]
    candidates.append(repo_root / "data" / "youtube-cookies.txt")
    candidates.append(Path.cwd() / "data" / "youtube-cookies.txt")
    for path in candidates:
        resolved = path.resolve()
        if resolved.is_file():
            return resolved
    return None


def ytdlp_bin() -> str:
    found = shutil.which("yt-dlp")
    if found:
        return found
    name = "yt-dlp.exe" if os.name == "nt" else "yt-dlp"
    sibling = Path(sys.executable).with_name(name)
    if sibling.is_file():
        return str(sibling)
    return "yt-dlp"


def _run_ytdlp_progress(cmd: list[str], job_dir: Path) -> tuple[int, list[str]]:
    proc = subprocess.Popen(
        cmd,
        cwd=job_dir,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
    )
    tail: list[str] = []
    assert proc.stdout is not None
    for line in proc.stdout:
        text = line.rstrip("\n")
        tail.append(text)
        if len(tail) > 80:
            tail.pop(0)
        low = text.lower()
        parsed = YT_DOWNLOAD_RE.search(text)
        if parsed:
            pct = float(parsed.group("pct") or 0)
            total = parse_size_bytes(parsed.group("total"))
            speed = (parsed.group("speed") or "").strip()
            eta = parse_eta_seconds(parsed.group("eta"))
            done = int(total * pct / 100.0) if total else None
            write_status_throttled(
                job_dir,
                stage="downloading",
                progress=round(8 + 20 * min(1.0, pct / 100.0), 1),
                message="Fetching the video from YouTube.",
                detailPercent=round(pct, 1),
                bytesDone=done,
                bytesTotal=total,
                etaSeconds=eta,
                speedLabel=speed or None,
            )
        elif "[merger]" in low or "merging formats" in low:
            write_status(
                job_dir,
                stage="downloading",
                progress=26,
                message="Combining video and audio into one file.",
                etaSeconds=None,
            )
        elif "extracting audio" in low or ("destination" in low and "audio" in low):
            write_status_throttled(
                job_dir,
                stage="downloading",
                progress=22,
                message="Fetching the audio.",
            )
    code = proc.wait()
    return code, tail


def download_youtube(url: str, job_dir: Path) -> tuple[Path, dict]:
    write_status(
        job_dir,
        stage="downloading",
        progress=8,
        message="Fetching the video from YouTube.",
    )
    ytdlp = ytdlp_bin()
    out_tmpl = str(job_dir / "source.%(ext)s")
    node = shutil.which("node")
    cookies = cookies_path()
    if cookies:
        attempts: list[dict] = [
            {"clients": "web,web_safari,tv", "impersonate": None, "ipv4": False, "ejs": True},
            {"clients": "web", "impersonate": None, "ipv4": True, "ejs": True},
            {"clients": "tv", "impersonate": None, "ipv4": True, "ejs": True},
            {"clients": "web_safari,mweb", "impersonate": "chrome", "ipv4": True, "ejs": True},
        ]
        write_status(
            job_dir,
            stage="downloading",
            progress=8,
            message="Fetching with a saved YouTube sign-in.",
        )
    else:
        attempts = [
            {"clients": "tv", "impersonate": None, "ipv4": True, "ejs": True},
            {"clients": "web_safari,mweb", "impersonate": "chrome", "ipv4": True, "ejs": True},
            {"clients": "ios", "impersonate": None, "ipv4": False, "ejs": False},
            {"clients": "web_embedded,android_vr", "impersonate": None, "ipv4": True, "ejs": True},
            {"clients": "android,ios,tv", "impersonate": "chrome", "ipv4": False, "ejs": True},
            {"clients": "android", "impersonate": "chrome", "ipv4": True, "ejs": False},
        ]
    last_error = ""
    log_path = job_dir / "yt-dlp.log"
    log_path.write_text("", encoding="utf-8")
    pending_video, pending_audio = ytdlp_fragments(job_dir)
    if pending_video and not pending_audio:
        write_status(
            job_dir,
            stage="downloading",
            progress=14,
            message="Video is already on disk. Fetching the audio next.",
        )
    for index, attempt in enumerate(attempts, start=1):
        write_status(
            job_dir,
            stage="downloading",
            progress=8,
            message=(
                "Fetching the video from YouTube."
                if index == 1
                else f"Trying another way to fetch this video ({index} of {len(attempts)})."
            ),
        )
        cmd = [
            ytdlp,
            "--no-playlist",
            "-f",
            YTDLP_FORMAT,
            "-S",
            YTDLP_SORT,
            "--merge-output-format",
            "mp4",
            "-o",
            out_tmpl,
            "--write-info-json",
            "--newline",
            "--extractor-args",
            f"youtube:player_client={attempt['clients']}",
        ]
        if node:
            cmd += ["--js-runtimes", f"node:{node}"]
        if attempt.get("ejs"):
            cmd += ["--remote-components", "ejs:github"]
        if cookies:
            cmd += ["--cookies", str(cookies)]
        if attempt["ipv4"]:
            cmd.append("-4")
        if attempt["impersonate"]:
            cmd += ["--impersonate", attempt["impersonate"]]
        cmd.append(url)
        print("+", " ".join(cmd), flush=True)
        header = (
            f"\n--- attempt {index} of {len(attempts)} "
            f"exit pending ---\n"
        )
        with log_path.open("a", encoding="utf-8", errors="replace") as handle:
            handle.write(header)
        code, tail = _run_ytdlp_progress(cmd, job_dir)
        with log_path.open("a", encoding="utf-8", errors="replace") as handle:
            handle.write(f"exit={code}\n")
            if code != 0:
                handle.write("\n".join(tail[-40:]) + "\n")
        if code != 0:
            last_error = "\n".join(tail[-40:])
            source = merged_source(job_dir)
            height = source_height(source) if source else 0
            if source and height >= MIN_SOURCE_HEIGHT:
                with log_path.open("a", encoding="utf-8", errors="replace") as handle:
                    handle.write(f"muxed after failed yt-dlp: source={source} height={height}\n")
                break
            continue
        source = merged_source(job_dir)
        height = source_height(source) if source else 0
        with log_path.open("a", encoding="utf-8", errors="replace") as handle:
            handle.write(f"source={source} height={height}\n")
        if height < MIN_SOURCE_HEIGHT:
            last_error = f"The download was below {MIN_SOURCE_HEIGHT}p."
            if source:
                source.unlink(missing_ok=True)
            continue
        break
    else:
        video, audio = ytdlp_fragments(job_dir)
        if video and not audio:
            raise RuntimeError(
                "The video is on disk, but the soundtrack never finished. "
                "Click Discover Shorts to try fetching the audio again."
            )
        raise RuntimeError(last_error or "Could not fetch this YouTube video.")

    source = merged_source(job_dir)
    if source is None:
        video, audio = ytdlp_fragments(job_dir)
        if video and not audio:
            raise RuntimeError(
                "The video is on disk, but the soundtrack never finished. "
                "Click Discover Shorts to try fetching the audio again."
            )
        raise RuntimeError("The YouTube fetch finished, but no video file was written.")
    if source.suffix not in {".mp4", ".mkv", ".webm", ".mov"}:
        remux = job_dir / "source.mp4"
        run(["ffmpeg", "-y", "-i", str(source), "-c", "copy", str(remux)])
        source = remux

    meta = {"title": None, "duration": None}
    info_files = list(job_dir.glob("source.*.json")) + list(job_dir.glob("*.info.json"))
    if info_files:
        payload = json.loads(info_files[0].read_text(encoding="utf-8"))
        meta["title"] = payload.get("title")
        meta["duration"] = payload.get("duration")
    return source, meta


def extract_audio(source: Path, job_dir: Path) -> Path:
    if not has_audio_stream(source):
        raise RuntimeError(
            "This file has no soundtrack. Click Discover Shorts to finish fetching video and audio together."
        )
    wav = job_dir / "audio.wav"
    run(
        [
            "ffmpeg",
            "-y",
            "-i",
            str(source),
            "-ac",
            "1",
            "-ar",
            "16000",
            str(wav),
        ]
    )
    return wav


def _without_speakers(transcript: dict) -> dict:
    words = []
    for word in transcript.get("words") or []:
        item = dict(word)
        item.pop("speaker", None)
        words.append(item)
    segments = []
    for seg in transcript.get("segments") or []:
        item = dict(seg)
        item.pop("speaker", None)
        segments.append(item)
    next_payload = dict(transcript)
    next_payload["words"] = words
    next_payload["segments"] = segments
    next_payload["speakers"] = []
    next_payload.pop("diarizeMethod", None)
    return next_payload


def _style_max_speakers(_job_dir: Path, style: dict | None) -> int:
    try:
        n = int((style or {}).get("speechLabels") or 0)
    except (TypeError, ValueError):
        n = 0
    if n >= 2:
        return min(4, n)
    return 4


def _job_max_speakers(job_dir: Path) -> int:
    status = read_json(job_dir / "status.json", {})
    style = status.get("captionStyle") if isinstance(status, dict) else {}
    return _style_max_speakers(job_dir, style if isinstance(style, dict) else {})


def _maybe_enable_speech_labels(job_dir: Path, speakers: list[str]) -> None:
    count = min(4, len(speakers))
    if count < 2:
        return
    status = read_json(job_dir / "status.json", {})
    if not isinstance(status, dict):
        return
    style = status.get("captionStyle")
    if not isinstance(style, dict):
        return
    try:
        current = int(style.get("speechLabels") or 0)
    except (TypeError, ValueError):
        current = 0
    if current > 0:
        return
    next_style = dict(style)
    next_style["speechLabels"] = count
    write_status(job_dir, captionStyle=next_style)


def transcribe(wav: Path, job_dir: Path, source: Path) -> dict:
    write_status(
        job_dir,
        stage="transcribing",
        progress=30,
        message="Listening to the speech.",
        transcriptionEngine=f"faster-whisper {WHISPER_MODEL}",
    )
    duration = 0.0
    try:
        duration = float(probe_media(source).get("duration") or 0)
    except Exception:
        duration = 0.0

    def on_progress(heard: float) -> None:
        total = duration if duration > 0 else max(heard, 1.0)
        frac = min(1.0, max(0.0, heard / total))
        write_status_throttled(
            job_dir,
            stage="transcribing",
            progress=round(30 + 24 * frac, 1),
            message="Listening to the speech.",
            detailLabel=heard_label(heard, total),
        )

    payload = transcribe_dual(wav, source, job_dir, on_progress=on_progress)
    return finish_transcript(wav, job_dir, payload)


def finish_transcript(wav: Path, job_dir: Path, payload: dict) -> dict:
    write_status(
        job_dir,
        stage="transcribing",
        progress=55,
        message="Labeling voices on the captions.",
    )
    words = assign_speakers(
        wav,
        [dict(word) for word in payload.get("words") or []],
        max_speakers=_job_max_speakers(job_dir),
    )
    speakers = unique_voices(words)
    segments = stamp_segments(payload.get("segments") or [], words)
    result = {
        "language": payload.get("language") or "en",
        "duration": payload.get("duration"),
        "segments": segments,
        "words": words,
        "speakers": speakers,
        "diarizeMethod": "overlap" if speakers else None,
        "transcriptionEngine": payload.get("transcriptionEngine")
        or f"faster-whisper {WHISPER_MODEL} dual-pass quiet-boost",
        "gates": speaker2_gate({"words": words, "segments": segments}),
    }
    if not speakers:
        result.pop("diarizeMethod", None)
    (job_dir / "transcript.json").write_text(json.dumps(result, indent=2))
    _maybe_enable_speech_labels(job_dir, speakers)
    return result


def window_text(segments: list[dict], start: float, end: float) -> str:
    parts = []
    for seg in segments:
        if seg["end"] > start and seg["start"] < end:
            parts.append(seg["text"])
    return " ".join(parts).strip()


def window_voices(transcript: dict | None, start: float, end: float) -> int:
    seen: set[str] = set()
    for word in (transcript or {}).get("words") or []:
        try:
            word_start = float(word.get("start") or 0)
            word_end = float(word.get("end") or word_start)
        except (TypeError, ValueError):
            continue
        if word_end <= start or word_start >= end:
            continue
        speaker = str(word.get("speaker") or "").strip()
        if speaker:
            seen.add(speaker)
    return len(seen)


def moment_brief(clip: dict) -> str:
    bits: list[str] = []
    if clip.get("laugh"):
        bits.append("laughter")
    try:
        scenes = int(clip.get("sceneCuts") or 0)
    except (TypeError, ValueError):
        scenes = 0
    if scenes == 1:
        bits.append("a scene change")
    elif scenes > 1:
        bits.append(f"{scenes} scene changes")
    try:
        voices = int(clip.get("voices") or 0)
    except (TypeError, ValueError):
        voices = 0
    if voices >= 2:
        bits.append(f"{voices} voices")
    return ", ".join(bits)


def score_window(
    segments: list[dict],
    start: float,
    end: float,
    duration: float,
    laugh_spans: list[tuple[float, float, float]] | None = None,
    scene_cuts: list[float] | None = None,
    voices: int = 0,
) -> float:
    text = window_text(segments, start, end)
    words = WORD_RE.findall(text.lower())
    dur = max(end - start, 1.0)
    density = len(words) / dur
    energy = sum(1 for word in words if word in HOOK_WORDS)
    punct = text.count("!") + text.count("?")
    penalty = 0.2 if start < 1.5 and duration > 50 else 0.0
    length_bonus = 0.45 if 22 <= (end - start) <= 48 else 0.32 if 48 < (end - start) <= 60 else 0.12 if (end - start) >= 18 else 0.0
    laugh = laugh_overlap_seconds(start, end, laugh_spans or [])
    laugh_bonus = 0.7 * min(laugh, 2.8) + (0.4 if laugh >= 0.35 else 0.0)
    cuts = cuts_in_window(start, end, scene_cuts or [])
    scene_bonus = 0.2 * min(len(cuts), 4)
    if any(start < time <= start + 4.0 for time in cuts):
        scene_bonus += 0.28
    voice_bonus = 0.18 if voices >= 2 else 0.0
    return (
        density * 1.35
        + energy * 0.55
        + punct * 0.25
        + length_bonus
        + laugh_bonus
        + scene_bonus
        + voice_bonus
        - penalty
    )


def clip_score_100(raw: float) -> float:
    """Map the raw highlight heuristic onto 0-100. About 8 raw is high 80s (green)."""
    return round(min(100.0, max(0.0, float(raw) * 10.5)), 1)


def full_video_clip(transcript: dict, duration: float, title: str | None) -> list[dict]:
    text = window_text(transcript.get("segments") or [], 0.0, duration)
    end = round(duration, 3)
    return [
        {
            "id": "clip-01",
            "start": 0.0,
            "end": end,
            "duration": end,
            "score": 100.0,
            "captionPreview": text[:180],
        }
    ]


MIN_HIGHLIGHT_SCORE = 0.7
AUTO_ENCODE_MAX = 6
LEAD_IN_SECONDS = 20.0
TAIL_SECONDS = 20.0
MAX_CLIP_SECONDS = 60.0
MIN_CLIP_SECONDS = 15.0
MAX_WINDOW_OVERLAP = 2.0
WORD_RE = re.compile(r"[A-Za-z0-9']+")


class _BinStats:
    def __init__(self, segments: list[dict], duration: float, bin_s: float = 0.5):
        self.bin_s = bin_s
        n = max(1, int(float(duration) / bin_s) + 4)
        words = [0] * n
        hooks = [0] * n
        punct = [0] * n
        for seg in segments:
            text = str(seg.get("text") or "")
            tokens = WORD_RE.findall(text.lower())
            try:
                start = float(seg.get("start") or 0)
            except (TypeError, ValueError):
                start = 0.0
            index = min(n - 1, max(0, int(start / bin_s)))
            words[index] += len(tokens)
            hooks[index] += sum(1 for token in tokens if token in HOOK_WORDS)
            punct[index] += text.count("!") + text.count("?")
        self._w = [0]
        self._h = [0]
        self._p = [0]
        for value in words:
            self._w.append(self._w[-1] + value)
        for value in hooks:
            self._h.append(self._h[-1] + value)
        for value in punct:
            self._p.append(self._p[-1] + value)
        self.n = n

    def counts(self, start: float, end: float) -> tuple[int, int, int]:
        lo = min(self.n, max(0, int(start / self.bin_s)))
        hi = min(self.n, max(lo, int(end / self.bin_s)))
        return self._w[hi] - self._w[lo], self._h[hi] - self._h[lo], self._p[hi] - self._p[lo]


def score_bins(
    stats: _BinStats,
    start: float,
    end: float,
    duration: float,
    laugh_spans: list[tuple[float, float, float]] | None = None,
    scene_cuts: list[float] | None = None,
    voices: int = 0,
) -> float:
    words_n, energy, punct = stats.counts(start, end)
    dur = max(end - start, 1.0)
    density = words_n / dur
    penalty = 0.2 if start < 1.5 and duration > 50 else 0.0
    length_bonus = (
        0.45
        if 22 <= (end - start) <= 48
        else 0.32
        if 48 < (end - start) <= 60
        else 0.12
        if (end - start) >= 18
        else 0.0
    )
    laugh = laugh_overlap_seconds(start, end, laugh_spans or [])
    laugh_bonus = 0.7 * min(laugh, 2.8) + (0.4 if laugh >= 0.35 else 0.0)
    cuts = cuts_in_window(start, end, scene_cuts or [])
    scene_bonus = 0.2 * min(len(cuts), 4)
    if any(start < time <= start + 4.0 for time in cuts):
        scene_bonus += 0.28
    voice_bonus = 0.18 if voices >= 2 else 0.0
    return (
        density * 1.35
        + energy * 0.55
        + punct * 0.25
        + length_bonus
        + laugh_bonus
        + scene_bonus
        + voice_bonus
        - penalty
    )


def highlight_cap(max_clips: int) -> int | None:
    """None keeps every decent non-overlapping window. A positive --max-clips is a hard limit."""
    if max_clips > 0:
        return max(1, max_clips)
    return None


def first_hook_time(segments: list[dict], start: float, end: float) -> float | None:
    for seg in segments:
        seg_start = float(seg.get("start") or 0)
        seg_end = float(seg.get("end") or seg_start)
        if seg_end <= start or seg_start >= end:
            continue
        for word in seg.get("words") or []:
            token = str(word.get("word") or "").lower()
            if any(part in HOOK_WORDS for part in WORD_RE.findall(token)):
                at = float(word.get("start") or seg_start)
                if start <= at <= end:
                    return at
        text = str(seg.get("text") or "").lower()
        if any(part in HOOK_WORDS for part in WORD_RE.findall(text)):
            return max(start, seg_start)
    return None


def critical_time(
    start: float,
    end: float,
    segments: list[dict],
    laugh_spans: list[tuple[float, float, float]],
    scene_cuts: list[float] | None = None,
) -> float:
    laugh_starts = [
        float(ls)
        for ls, le, _weight in laugh_spans
        if float(le) > start and float(ls) < end
    ]
    if laugh_starts:
        return min(max(start, t) for t in laugh_starts)
    cut = first_cut_in_window(start, end, scene_cuts or [])
    if cut is not None:
        return cut
    hook = first_hook_time(segments, start, end)
    if hook is not None:
        return hook
    return start


def last_payoff_time(
    start: float,
    end: float,
    laugh_spans: list[tuple[float, float, float]],
) -> float:
    laugh_ends = [
        float(le)
        for ls, le, _weight in laugh_spans
        if float(le) > start and float(ls) < end
    ]
    if laugh_ends:
        return max(laugh_ends)
    return end


def apply_side_pads(
    start: float,
    end: float,
    duration: float,
    critical: float,
    payoff: float,
) -> tuple[float, float]:
    core_start = float(start)
    core_end = max(float(end), float(payoff))
    new_start = max(0.0, min(core_start, float(critical)) - LEAD_IN_SECONDS)
    new_end = min(float(duration), max(core_end, float(payoff)) + TAIL_SECONDS)
    if new_end - new_start <= MAX_CLIP_SECONDS:
        if new_end - new_start < MIN_CLIP_SECONDS:
            new_end = min(float(duration), new_start + MIN_CLIP_SECONDS)
            if new_end - new_start < MIN_CLIP_SECONDS:
                new_start = max(0.0, new_end - MIN_CLIP_SECONDS)
        return round(new_start, 3), round(new_end, 3)

    core_len = core_end - core_start
    if core_len >= MAX_CLIP_SECONDS:
        new_end = min(float(duration), max(core_end, float(payoff)) + TAIL_SECONDS)
        new_start = max(0.0, new_end - MAX_CLIP_SECONDS)
        if float(critical) < new_start:
            new_start = max(0.0, float(critical) - 4.0)
            new_end = min(float(duration), new_start + MAX_CLIP_SECONDS)
        return round(new_start, 3), round(new_end, 3)

    leftover = MAX_CLIP_SECONDS - core_len
    want_left = max(0.0, core_start - new_start)
    want_right = max(0.0, new_end - core_end)
    total_want = want_left + want_right
    if total_want <= 0:
        new_end = min(float(duration), core_start + MAX_CLIP_SECONDS)
        return round(core_start, 3), round(new_end, 3)
    left = leftover * (want_left / total_want)
    right = leftover - left
    new_start = max(0.0, core_start - left)
    new_end = min(float(duration), core_end + right)
    return round(new_start, 3), round(new_end, 3)


def _span_overlap(a0: float, a1: float, b0: float, b1: float) -> float:
    return max(0.0, min(a1, b1) - max(a0, b0))


def _window_iou(a0: float, a1: float, b0: float, b1: float) -> float:
    overlap = _span_overlap(a0, a1, b0, b1)
    union = (a1 - a0) + (b1 - b0) - overlap
    return overlap / union if union > 1e-6 else 0.0


def windows_are_same_proposal(a0: float, a1: float, b0: float, b1: float) -> bool:
    overlap = _span_overlap(a0, a1, b0, b1)
    shorter = min(max(a1 - a0, 1.0), max(b1 - b0, 1.0))
    return overlap >= 0.5 * shorter or _window_iou(a0, a1, b0, b1) >= 0.3


def collapse_duplicate_windows(highlights: list[dict]) -> list[dict]:
    ranked = sorted(
        highlights,
        key=lambda item: (
            -int(bool(item.get("encoded") or item.get("file"))),
            -float(item.get("score") or 0),
            float(item.get("start") or 0),
        ),
    )
    kept: list[dict] = []
    for item in ranked:
        start = float(item.get("start") or 0)
        end = float(item.get("end") or start)
        if any(
            windows_are_same_proposal(
                start,
                end,
                float(other.get("start") or 0),
                float(other.get("end") or other.get("start") or 0),
            )
            for other in kept
        ):
            continue
        kept.append(item)
    return rank_highlights(kept)


def _trim_away_from(
    start: float,
    end: float,
    other_start: float,
    other_end: float,
    max_overlap: float,
    min_len: float,
) -> tuple[float, float] | None:
    if _span_overlap(start, end, other_start, other_end) <= max_overlap + 1e-6:
        return start, end
    hangs_left = start < other_start - 1e-6
    hangs_right = end > other_end + 1e-6
    if hangs_left and not hangs_right:
        end = min(end, other_start + max_overlap)
    elif hangs_right and not hangs_left:
        start = max(start, other_end - max_overlap)
    elif hangs_left and hangs_right:
        left_end = other_start + max_overlap
        right_start = other_end - max_overlap
        if (left_end - start) >= (end - right_start):
            end = left_end
        else:
            start = right_start
    else:
        return None
    if end - start < min_len:
        return None
    if _span_overlap(start, end, other_start, other_end) > max_overlap + 1e-6:
        return None
    return start, end


def resolve_window_overlaps(
    picked: list[tuple[float, float, float]],
    duration: float,
    max_overlap: float = MAX_WINDOW_OVERLAP,
    min_len: float = MIN_CLIP_SECONDS,
) -> list[tuple[float, float, float]]:
    ranked = sorted(picked, key=lambda item: (-item[2], item[0]))
    kept: list[tuple[float, float, float]] = []
    for start, end, score in ranked:
        start = max(0.0, float(start))
        end = min(float(duration), float(end))
        dropped = False
        for other_start, other_end, _other_score in kept:
            trimmed = _trim_away_from(start, end, other_start, other_end, max_overlap, min_len)
            if trimmed is None:
                dropped = True
                break
            start, end = trimmed
        if dropped or end - start < min_len:
            continue
        kept.append((round(start, 3), round(end, 3), score))
    if not kept and picked:
        start, end, score = max(picked, key=lambda item: (item[2], item[1] - item[0]))
        start = max(0.0, float(start))
        end = min(float(duration), max(start + min_len, float(end)))
        kept = [(round(start, 3), round(end, 3), score)]
    kept.sort(key=lambda item: item[0])
    return kept


def pick_highlights(
    transcript: dict,
    duration: float,
    max_clips: int = 0,
    source_title: str | None = None,
    wav_path: Path | None = None,
    source_path: Path | None = None,
    job_dir: Path | None = None,
    focus: str = "",
) -> list[dict]:
    segments = transcript.get("segments") or []
    cap = highlight_cap(max_clips)
    focus_terms: list[str] = []
    focus_raw = (focus or "").strip()
    if focus_raw:
        focus_terms = [token for token in re.split(r"[^A-Za-z0-9]+", focus_raw.lower()) if len(token) >= 3]
    if job_dir is not None:
        write_status(
            job_dir,
            stage="scoring",
            progress=62,
            message="Looking for laughs and scene changes.",
        )
    laugh_spans = detect_laughter(wav_path, transcript) if wav_path or transcript else []
    if job_dir is not None:
        write_status(
            job_dir,
            stage="scoring",
            progress=62.5,
            message="Looking for scene changes.",
        )
    scene_cuts = detect_scene_cuts(source_path, job_dir)
    stats = _BinStats(segments, duration)
    if duration < 70:
        lengths = [15, 16, 18]
        if duration >= 45:
            lengths.extend([22, 30, 45])
        if duration >= 60:
            lengths.append(60)
        stride = 3.0
    elif duration >= 3600:
        lengths = [22, 36, 48, 60]
        stride = 8.0
    elif duration >= 1200:
        lengths = [18, 28, 45, 60]
        stride = 5.0
    else:
        lengths = [15, 18, 22, 28, 36, 45, 52, 60]
        stride = 3.0
    overlap_limit = MAX_WINDOW_OVERLAP

    def scored(start: float, end: float) -> float:
        base = score_bins(stats, start, end, duration, laugh_spans, scene_cuts)
        if focus_terms:
            text = window_text(segments, start, end).lower()
            hits = sum(1 for term in focus_terms if term in text)
            if hits:
                base += 0.35 * min(hits, 3)
        return base

    if job_dir is not None:
        write_status(
            job_dir,
            stage="scoring",
            progress=63,
            message=(
                "Scoring highlight windows. This is a long video, so windows are spaced farther apart."
                if duration >= 1200
                else "Scoring highlight windows."
            ),
        )

    windows: list[tuple[float, float, float]] = []
    for length in lengths:
        if length > duration:
            continue
        t = 0.0
        while t + 15 <= duration + 0.05:
            end = min(t + length, duration)
            if end - t >= 15:
                windows.append((t, end, scored(t, end)))
            t += stride
    top_laughs = sorted(laugh_spans, key=lambda item: -item[2])[:24]
    for laugh_start, laugh_end, _weight in top_laughs:
        for length in (18, 22, 28, 45, 60):
            start = max(0.0, laugh_start - LEAD_IN_SECONDS)
            end = min(duration, max(start + length, laugh_end + TAIL_SECONDS))
            if end - start < 15:
                continue
            windows.append((start, end, scored(start, end)))
    for cut in scene_cuts[:80]:
        for length in (18, 22, 28, 45):
            start = max(0.0, cut - 2.5)
            end = min(duration, start + length)
            if end - start < 15:
                continue
            windows.append((start, end, scored(start, end)))
    windows.sort(key=lambda item: -item[2])
    picked: list[tuple[float, float, float]] = []
    for start, end, score in windows:
        laugh = laugh_overlap_seconds(start, end, laugh_spans)
        scenes = cuts_in_window(start, end, scene_cuts)
        min_score = 0.45 if laugh >= 0.35 or scenes else MIN_HIGHLIGHT_SCORE
        if score < min_score and picked:
            continue
        if any(max(0.0, min(end, pe) - max(start, ps)) > overlap_limit for ps, pe, _ in picked):
            continue
        picked.append((start, end, score))
        if cap is not None and len(picked) >= cap:
            break
    if not picked:
        end = min(max(15.0, duration), 60.0)
        picked = [(0.0, end, 0.4)]
    picked.sort(key=lambda item: item[0])
    if cap is None or len(picked) < cap:
        gaps: list[tuple[float, float]] = []
        cursor = 0.0
        for start, end, _score in picked:
            if start - cursor >= 15:
                gaps.append((cursor, start))
            cursor = max(cursor, end)
        if duration - cursor >= 15:
            gaps.append((cursor, duration))
        extras: list[tuple[float, float, float]] = []
        for g0, g1 in gaps:
            t = g0
            while t + 15 <= g1 + 0.05 and (cap is None or len(picked) + len(extras) < cap):
                fill = 60 if g1 - t >= 60 else 45 if g1 - t >= 45 else 18
                end = min(t + fill, g1)
                if end - t < 15:
                    break
                score = scored(t, end)
                laugh = laugh_overlap_seconds(t, end, laugh_spans)
                scenes = cuts_in_window(t, end, scene_cuts)
                if score >= (0.45 if laugh >= 0.35 or scenes else MIN_HIGHLIGHT_SCORE):
                    extras.append((t, end, score))
                t = end + 0.4
        picked.extend(extras)
        picked.sort(key=lambda item: item[0])
    padded: list[tuple[float, float, float]] = []
    for start, end, score in picked:
        critical = critical_time(start, end, segments, laugh_spans, scene_cuts)
        payoff = last_payoff_time(start, end, laugh_spans)
        start, end = apply_side_pads(start, end, duration, critical, payoff)
        padded.append((start, end, score))
    padded = resolve_window_overlaps(padded, duration)
    highlights = []
    for start, end, _score in padded:
        text = window_text(segments, start, end)
        laugh = laugh_overlap_seconds(start, end, laugh_spans)
        scenes = cuts_in_window(start, end, scene_cuts)
        voices = window_voices(transcript, start, end)
        clip = {
            "start": round(start, 3),
            "end": round(end, 3),
            "duration": round(end - start, 3),
            "score": clip_score_100(scored(start, end) + (0.18 if voices >= 2 else 0.0)),
            "captionPreview": text[:180],
            "laugh": laugh >= 0.35,
        }
        if scenes:
            clip["sceneCuts"] = len(scenes)
        if voices:
            clip["voices"] = voices
        highlights.append(clip)
    return collapse_duplicate_windows(highlights)


def rank_highlights(highlights: list[dict]) -> list[dict]:
    ranked = sorted(
        highlights,
        key=lambda item: (-float(item.get("score") or 0), float(item.get("start") or 0)),
    )
    numbered = []
    for index, item in enumerate(ranked, start=1):
        clip = dict(item)
        clip["id"] = f"clip-{index:02d}"
        numbered.append(clip)
    return numbered


def resolved_min_highlight_score(args: argparse.Namespace) -> float:
    value = getattr(args, "min_highlight_score", None)
    if value is None or float(value) < 0:
        try:
            value = float(os.environ.get("CUTLINE_MIN_HIGHLIGHT_SCORE") or 0)
        except ValueError:
            value = 0.0
    return max(0.0, min(100.0, float(value)))


def apply_min_highlight_score(highlights: list[dict], floor: float) -> list[dict]:
    if floor <= 0 or not highlights:
        return highlights
    kept = [item for item in highlights if float(item.get("score") or 0) >= floor]
    if not kept:
        kept = [max(highlights, key=lambda item: (float(item.get("score") or 0), -float(item.get("start") or 0)))]
    return collapse_duplicate_windows(kept)


def select_auto_encode(highlights: list[dict]) -> tuple[list[dict], float]:
    if not highlights:
        return highlights, 0.0
    ranked = rank_highlights(highlights)
    chosen_ids = {item["id"] for item in ranked[:AUTO_ENCODE_MAX]}
    cutoff = round(float(ranked[min(len(ranked), AUTO_ENCODE_MAX) - 1].get("score") or 0), 3)
    marked = []
    for item in ranked:
        clip = dict(item)
        start = float(clip.get("start") or 0)
        end = float(clip.get("end") or start)
        clip["duration"] = round(end - start, 3)
        clip["autoEncode"] = clip["id"] in chosen_ids
        clip["encoded"] = False
        marked.append(clip)
    return marked, cutoff


def clip_file_stem(clip: dict) -> str:
    raw = str(clip.get("suggestedTitle") or clip.get("title") or clip.get("id") or "short")
    cleaned = []
    for ch in raw:
        if ch in '<>:"/\\|?*' or ord(ch) < 32:
            cleaned.append(" ")
        else:
            cleaned.append(ch)
    stem = " ".join("".join(cleaned).split()).strip(" .")[:80]
    return stem or str(clip.get("id") or "short")


def titled_mp4_name(clip: dict, taken: set[str]) -> str:
    stem = clip_file_stem(clip)
    candidate = f"{stem}.mp4"
    if candidate.lower() in taken:
        candidate = f"{stem} - {clip.get('id') or 'clip'}.mp4"
    return candidate


def encoded_mp4_path(clips_dir: Path, clip: dict) -> Path | None:
    named = str(clip.get("file") or "").strip()
    if named:
        path = clips_dir / Path(named).name
        if path.is_file():
            return path
    fallback = clips_dir / f"{clip.get('id')}.mp4"
    return fallback if fallback.is_file() else None


def apply_titled_mp4(clip: dict, clips_dir: Path, taken: set[str]) -> dict:
    item = dict(clip)
    src = encoded_mp4_path(clips_dir, item)
    if src is None:
        item.pop("file", None)
        item["encoded"] = False
        return item
    name = titled_mp4_name(item, taken)
    dest = clips_dir / name
    if src.resolve() != dest.resolve():
        if dest.exists():
            dest.unlink()
        src.replace(dest)
    stale = str(item.get("file") or "").strip()
    if stale and stale != name:
        old = clips_dir / Path(stale).name
        if old.is_file() and old.resolve() != dest.resolve():
            old.unlink()
    taken.add(name.lower())
    item["file"] = name
    item["encoded"] = True
    poster = clips_dir / f"{item['id']}.jpg"
    if poster.is_file():
        item["poster"] = poster.name
    return item


def titled_side_mp4_name(clip: dict, kind: str, taken: set[str]) -> str:
    stem = clip_file_stem(clip)
    candidate = f"{stem} - {kind}.mp4"
    if candidate.lower() in taken:
        candidate = f"{stem} - {kind} - {clip.get('id') or 'clip'}.mp4"
    return candidate


def encoded_side_mp4_path(clips_dir: Path, clip: dict, field: str, fallback: str) -> Path | None:
    named = str(clip.get(field) or "").strip()
    if named:
        path = clips_dir / Path(named).name
        if path.is_file():
            return path
    path = clips_dir / fallback
    return path if path.is_file() else None


def apply_titled_side_mp4(
    clip: dict,
    clips_dir: Path,
    field: str,
    kind: str,
    fallback: str,
    taken: set[str],
) -> dict:
    item = dict(clip)
    src = encoded_side_mp4_path(clips_dir, item, field, fallback)
    if src is None:
        item.pop(field, None)
        return item
    name = titled_side_mp4_name(item, kind, taken)
    dest = clips_dir / name
    if src.resolve() != dest.resolve():
        if dest.exists():
            dest.unlink()
        src.replace(dest)
    stale = str(item.get(field) or "").strip()
    if stale and stale != name:
        old = clips_dir / Path(stale).name
        if old.is_file() and old.resolve() != dest.resolve():
            old.unlink()
    taken.add(name.lower())
    item[field] = name
    return item


def drop_wide_outputs(clip: dict, clips_dir: Path, keep: set[str] | None = None) -> dict:
    item = dict(clip)
    keep = keep or set()
    mapping = {
        "wideFile": f"{item.get('id')}-wide.mp4",
        "wideCaptionFile": f"{item.get('id')}-wide-captions.mp4",
    }
    for field, fallback in mapping.items():
        if field in keep:
            continue
        named = str(item.get(field) or "").strip()
        for name in {named, fallback}:
            if not name:
                continue
            path = clips_dir / Path(name).name
            if path.is_file():
                path.unlink(missing_ok=True)
        item.pop(field, None)
    return item


def finalize_clip(clip: dict, clips_dir: Path, taken: set[str] | None = None) -> dict:
    item = dict(clip)
    start = float(item.get("start") or 0)
    end = float(item.get("end") or start)
    item["duration"] = round(end - start, 3)
    names = taken if taken is not None else set()
    item = apply_titled_mp4(item, clips_dir, names)
    item = apply_titled_side_mp4(
        item, clips_dir, "wideFile", "wide", f"{item.get('id')}-wide.mp4", names
    )
    item = apply_titled_side_mp4(
        item,
        clips_dir,
        "wideCaptionFile",
        "wide captions",
        f"{item.get('id')}-wide-captions.mp4",
        names,
    )
    return item


def _even(value: float) -> int:
    n = max(2, int(round(float(value))))
    return n if n % 2 == 0 else n - 1


def output_frame_size(crop_w: float, crop_h: float) -> tuple[int, int]:
    width = _even(crop_w)
    height = _even(crop_h)
    long = max(width, height)
    best = (width, height)
    for out_w, out_h in OUT_SIZES:
        if long + 0.5 >= out_h or long + 0.5 >= out_w:
            best = (out_w, out_h)
    return best


def short_output_size(
    width: int,
    height: int,
    crop_x: float = 0.5,
    crop_y: float = 0.5,
) -> tuple[int, int]:
    _crop, crop_w, crop_h = vertical_crop(width, height, crop_x, crop_y)
    return output_frame_size(crop_w, crop_h)


def media_size_fields(media: dict) -> dict:
    fields: dict = {}
    try:
        width = int(media.get("width") or 0)
        height = int(media.get("height") or 0)
    except (TypeError, ValueError):
        width = height = 0
    if width >= 2:
        fields["sourceWidth"] = width
    if height >= 2:
        fields["sourceHeight"] = height
    try:
        duration = float(media.get("duration") or 0)
    except (TypeError, ValueError):
        duration = 0.0
    if duration > 0:
        fields["sourceDuration"] = round(duration, 3)
    return fields


def vertical_crop(
    width: int,
    height: int,
    crop_x: float = 0.5,
    crop_y: float = 0.5,
) -> tuple[str, int, int]:
    target = 9 / 16
    pan_x = min(1.0, max(0.0, float(crop_x)))
    pan_y = min(1.0, max(0.0, float(crop_y)))
    if width / height > target + 0.01:
        crop_w = _even(height * 9 / 16)
        crop_h = _even(height)
        x = _even((width - crop_w) * pan_x)
        x = max(0, min(x, max(0, width - crop_w)))
        crop = f"crop={crop_w}:{crop_h}:{x}:0"
    elif width / height < target - 0.01:
        crop_w = _even(width)
        crop_h = _even(width * 16 / 9)
        y = max(0, _even((height - crop_h) * pan_y))
        y = max(0, min(y, max(0, height - crop_h)))
        crop = f"crop={crop_w}:{crop_h}:0:{y}"
    else:
        crop_w = _even(width)
        crop_h = _even(height)
        crop = f"crop={crop_w}:{crop_h}:0:0"
    return crop, crop_w, crop_h


def _px_box(width: int, height: int, raw: object) -> tuple[int, int, int, int] | None:
    if not isinstance(raw, dict):
        return None
    try:
        x = float(raw.get("x"))
        y = float(raw.get("y"))
        w = float(raw.get("w"))
        h = float(raw.get("h"))
    except (TypeError, ValueError):
        return None
    if w < 0.04 or h < 0.04:
        return None
    px = max(0, min(width - 2, _even(x * width)))
    py = max(0, min(height - 2, _even(y * height)))
    pw = max(2, min(_even(w * width), width - px))
    ph = max(2, min(_even(h * height), height - py))
    if pw % 2:
        pw -= 1
    if ph % 2:
        ph -= 1
    if pw < 2 or ph < 2:
        return None
    return px, py, pw, ph


def _webcam_size(camera: dict) -> float:
    try:
        value = float(camera.get("size"))
    except (TypeError, ValueError):
        value = 1.0
    return min(1.6, max(0.4, value))


def _webcam_place(camera: dict) -> str:
    raw = str(camera.get("place") or "")
    places = {
        "top-left",
        "top-middle",
        "top-right",
        "middle-left",
        "middle-middle",
        "middle-right",
        "bottom-left",
        "bottom-middle",
        "bottom-right",
    }
    if raw in places:
        return raw
    layout = str(camera.get("layout") or "")
    if layout == "face-bottom":
        return "bottom-middle"
    if layout == "face-top":
        return "top-middle"
    return "top-right"


def _webcam_border_px(camera: dict) -> int:
    raw = str(camera.get("border") or "thin")
    if raw == "none":
        return 0
    if raw == "thick":
        return 12
    return 4


def _webcam_border_color(camera: dict) -> str:
    raw = str(camera.get("borderColor") or "white").strip()
    named = {
        "white": "white",
        "black": "black",
        "gold": "0xE8C547",
        "teal": "0x25D0C6",
    }
    if raw.lower() in named:
        return named[raw.lower()]
    match = re.fullmatch(r"#?([0-9A-Fa-f]{6})", raw)
    if match:
        return "0x" + match.group(1).upper()
    short = re.fullmatch(r"#?([0-9A-Fa-f]{3})", raw)
    if short:
        a, b, c = short.group(1).upper()
        return "0x" + a + a + b + b + c + c
    return "white"


def _webcam_border_kind(camera: dict) -> str:
    raw = str(camera.get("borderStyle") or "solid")
    if raw in {"solid", "dashed", "dotted", "glow"}:
        return raw
    return "solid"


def _webcam_enter(camera: dict) -> str:
    raw = str(camera.get("enter") or "cut")
    if raw in {"cut", "fade", "slide"}:
        return raw
    return "cut"


def _webcam_shape(camera: dict) -> str:
    raw = str(camera.get("shape") or "square")
    if raw in {"star", "rect"}:
        raw = "square"
    if raw in {"square", "circle", "hex"}:
        return raw
    return "square"


def _square_face(fx: int, fy: int, fw: int, fh: int) -> tuple[int, int, int, int]:
    side = min(fw, fh)
    if side % 2:
        side -= 1
    if side < 2:
        side = 2
    fx = fx + _even((fw - side) / 2)
    fy = fy + _even((fh - side) / 2)
    return fx, fy, side, side


def _shape_alpha(shape: str, border: int, kind: str) -> str | None:
    if shape not in {"circle", "hex"}:
        return None
    ring = "255"
    if kind in {"dashed", "dotted"}:
        steps = 22 if kind == "dotted" else 16
        on = 0.38 if kind == "dotted" else 0.48
        if shape == "hex":
            turn = "mod(atan2((Y-H/2)/max(H/2\\,1)\\,(X-W/2)/max(W/2\\,1))+2*PI\\,2*PI)/(2*PI)"
        else:
            turn = "mod(atan2(Y-H/2\\,X-W/2)+2*PI\\,2*PI)/(2*PI)"
        ring = f"if(lt(mod(({turn})*{steps}\\,1)\\,{on})\\,255\\,0)"
    if shape == "circle":
        r = "hypot(X-W/2\\,Y-H/2)"
        outer = "min(W\\,H)/2"
        inner = f"max({outer}-{border}\\,1)"
        inside = f"lte({r}\\,{outer})"
        video = f"lte({r}\\,{inner})"
    else:
        hex_a = "atan2((X-W/2)/max(W/2\\,1)\\,(H/2-Y)/max(H/2\\,1))"
        r_out = "hypot((X-W/2)/max(W/2\\,1)\\,(Y-H/2)/max(H/2\\,1))"
        r_in = (
            f"hypot((X-W/2)/max(W/2-{border}\\,1)\\,(Y-H/2)/max(H/2-{border}\\,1))"
        )
        limit = f"cos(PI/6)/cos(mod(({hex_a})+PI/6\\,PI/3)-PI/6)"
        inside = f"lte({r_out}\\,{limit})"
        video = f"lte({r_in}\\,{limit})"
    expr = f"if({inside}\\,if({video}\\,255\\,{ring})\\,0)"
    fill = f"if({video}\\,{{ch}}(X\\,Y)\\,{{ch}}(0\\,0))"
    return (
        "geq="
        f"lum='{fill.format(ch='lum')}':"
        f"cb='{fill.format(ch='cb')}':"
        f"cr='{fill.format(ch='cr')}':"
        f"a='{expr}'"
    )


def _webcam_overlay(ox: int, oy: int, inset_w: int, inset_h: int, place: str, enter: str) -> str:
    if enter != "slide":
        return f"overlay={ox}:{oy}"
    dur = 0.45
    row, col = place.split("-", 1)
    if col == "left":
        x = f"if(lt(t\\,{dur})\\,{ox}-({dur}-t)/{dur}*{inset_w}\\,{ox})"
        y = str(oy)
    elif col == "right":
        x = f"if(lt(t\\,{dur})\\,{ox}+({dur}-t)/{dur}*{inset_w}\\,{ox})"
        y = str(oy)
    elif row == "top":
        x = str(ox)
        y = f"if(lt(t\\,{dur})\\,{oy}-({dur}-t)/{dur}*{inset_h}\\,{oy})"
    else:
        x = str(ox)
        y = f"if(lt(t\\,{dur})\\,{oy}+({dur}-t)/{dur}*{inset_h}\\,{oy})"
    return f"overlay=x='{x}':y='{y}'"


def split_filter(
    width: int,
    height: int,
    srt_path: Path,
    camera: dict,
    crop_x: float = 0.5,
    crop_y: float = 0.5,
) -> str:
    place = _webcam_place(camera)
    row, col = place.split("-", 1)
    scale = _webcam_size(camera)
    crop, crop_w, crop_h = vertical_crop(width, height, crop_x, crop_y)
    out_w, out_h = output_frame_size(crop_w, crop_h)
    face = _px_box(width, height, camera.get("faceBox"))
    if face is None:
        return vertical_filter(width, height, srt_path, crop_x, crop_y)
    fx, fy, fw, fh = face
    shape = _webcam_shape(camera)
    if shape in {"square", "circle"}:
        fx, fy, fw, fh = _square_face(fx, fy, fw, fh)
    subs = _subtitle_filter(srt_path)
    if shape in {"square", "circle"}:
        inset = max(2, _even(out_w * 0.42 * scale))
        max_h = max(2, _even(out_h * min(0.72, 0.40 * scale)))
        if inset > max_h:
            inset = max_h
        inset_w = inset_h = inset
    else:
        inset_w = max(2, _even(out_w * 0.42 * scale))
        inset_h = max(2, _even(inset_w * (fh / max(fw, 1))))
        max_h = max(2, _even(out_h * min(0.72, 0.40 * scale)))
        if inset_h > max_h:
            inset_h = max_h
            inset_w = max(2, _even(inset_h * (fw / max(fh, 1))))
    border = _webcam_border_px(camera)
    kind = _webcam_border_kind(camera)
    color = _webcam_border_color(camera)
    if kind == "glow" and border > 0:
        border = border + 6
    cam_bits = [f"crop={fw}:{fh}:{fx}:{fy}", f"scale={inset_w}:{inset_h}:flags=lanczos"]
    if border > 0:
        pad_w = _even(inset_w + border * 2)
        pad_h = _even(inset_h + border * 2)
        cam_bits.append(f"pad={pad_w}:{pad_h}:{border}:{border}:{color}")
        inset_w, inset_h = pad_w, pad_h
    enter = _webcam_enter(camera)
    mask = _shape_alpha(shape, border, kind)
    need_alpha = bool(mask) or enter == "fade" or (border > 0 and kind in {"dashed", "dotted"})
    if need_alpha:
        cam_bits.append("format=yuva420p")
    if mask:
        cam_bits.append(mask)
    elif border > 0 and kind in {"dashed", "dotted"}:
        period = 8 if kind == "dotted" else 16
        dash = 3 if kind == "dotted" else 8
        edge = max(1, border - 1)
        cam_bits.append(
            "geq=lum='lum(X\\,Y)':cb='cb(X\\,Y)':cr='cr(X\\,Y)':"
            f"a='if(gt(min(X\\,W-1-X\\,Y\\,H-1-Y)\\,{edge})\\,255\\,"
            f"if(lt(mod(X+Y\\,{period})\\,{dash})\\,255\\,0))'"
        )
    if enter == "fade":
        cam_bits.append("fade=t=in:st=0:d=0.45:alpha=1")
    pad_x = max(0, _even(out_w * 0.04))
    pad_y = max(0, _even(out_h * 0.04))
    if col == "left":
        ox = pad_x
    elif col == "right":
        ox = max(0, out_w - inset_w - pad_x)
    else:
        ox = max(0, _even((out_w - inset_w) / 2))
    if row == "top":
        oy = pad_y
    elif row == "bottom":
        oy = max(0, out_h - inset_h - pad_y)
    else:
        oy = max(0, _even((out_h - inset_h) / 2))
    if ox + inset_w > out_w:
        ox = max(0, out_w - inset_w)
    if oy + inset_h > out_h:
        oy = max(0, out_h - inset_h)
    overlay = _webcam_overlay(ox, oy, inset_w, inset_h, place, enter)
    cam = ",".join(cam_bits)
    return (
        f"split=2[base][cam];"
        f"[base]{crop},scale={out_w}:{out_h}:flags=lanczos[bg];"
        f"[cam]{cam}[fc];"
        f"[bg][fc]{overlay},{subs}[vout]"
    )


def vertical_filter(
    width: int,
    height: int,
    srt_path: Path,
    crop_x: float = 0.5,
    crop_y: float = 0.5,
) -> str:
    crop, crop_w, crop_h = vertical_crop(width, height, crop_x, crop_y)
    out_w, out_h = output_frame_size(crop_w, crop_h)
    escaped = str(srt_path).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
    fonts = str(FONT_DIR).replace("\\", "/").replace(":", "\\:")
    parts = [crop]
    if (crop_w, crop_h) != (out_w, out_h):
        parts.append(
            f"scale={out_w}:{out_h}:flags=lanczos+accurate_rnd+full_chroma_int+full_chroma_inp"
        )
        if out_w > crop_w + 1 or out_h > crop_h + 1:
            upscale = max(out_w / max(crop_w, 1), out_h / max(crop_h, 1))
            amount = 0.15 if upscale >= 2.5 else 0.28
            parts.append(f"unsharp=5:5:{amount}:5:5:0.0")
    parts.append(_subtitle_filter(srt_path))
    return ",".join(parts)


def _subtitle_filter(srt_path: Path) -> str:
    escaped = str(srt_path).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
    fonts = str(FONT_DIR).replace("\\", "/").replace(":", "\\:")
    return f"subtitles='{escaped}':fontsdir='{fonts}'"


def wide_filter(width: int, height: int, srt_path: Path | None = None) -> str:
    out_w, out_h = _even(width), _even(height)
    parts: list[str] = []
    if out_w != int(width) or out_h != int(height):
        parts.append(f"crop={out_w}:{out_h}:0:0")
    if srt_path is not None:
        parts.append(_subtitle_filter(srt_path))
    return ",".join(parts) if parts else "null"


def _ffmpeg_encode_window(
    source: Path,
    pieces: list[dict],
    vf: str,
    media: dict,
    quality: str,
    dest: Path,
    edit_fx: str = "cut",
) -> None:
    preset = ENCODE_PRESET if quality == "final" else DRAFT_PRESET
    crf = str(ENCODE_CRF if quality == "final" else DRAFT_CRF)
    has_audio = bool(media.get("has_audio", True))
    audio_args = ["-c:a", "aac", "-b:a", ENCODE_AUDIO_BITRATE] if has_audio else ["-an"]
    duration = output_duration(pieces)
    common_tail = [
        "-c:v",
        "libx264",
        "-preset",
        preset,
        "-crf",
        crf,
        "-profile:v",
        "high",
        "-x264-params",
        "aq-mode=3:aq-strength=0.9:deblock=-1,-1:psy-rd=1.00,0.15:mbtree=1",
        *audio_args,
        "-movflags",
        "+faststart",
        "-pix_fmt",
        "yuv420p",
        "-colorspace",
        "bt709",
        "-color_primaries",
        "bt709",
        "-color_trc",
        "bt709",
        "-color_range",
        "tv",
        str(dest),
    ]
    if simple_render(pieces):
        if ";" in vf or vf.strip().endswith("[vout]"):
            graph = vf if vf.lstrip().startswith("[0:v]") else f"[0:v]{vf}"
            if not graph.endswith("[vout]"):
                graph = f"{graph}[vout]"
            maps = ["-map", "[vout]"]
            if has_audio:
                maps += ["-map", "0:a"]
            run(
                [
                    "ffmpeg",
                    "-y",
                    "-ss",
                    f"{pieces[0]['start']:.3f}",
                    "-i",
                    str(source),
                    "-t",
                    f"{duration:.3f}",
                    "-filter_complex",
                    graph,
                    *maps,
                    *common_tail,
                ]
            )
            return
        run(
            [
                "ffmpeg",
                "-y",
                "-ss",
                f"{pieces[0]['start']:.3f}",
                "-i",
                str(source),
                "-t",
                f"{duration:.3f}",
                "-vf",
                vf,
                *common_tail,
            ]
        )
        return
    cmd = ["ffmpeg", "-y"]
    for piece in pieces:
        span = float(piece["end"]) - float(piece["start"])
        if float(piece.get("freeze") or 0) > 0:
            span = max(span, 0.08)
        cmd += [
            "-ss",
            f"{piece['start']:.3f}",
            "-t",
            f"{span:.3f}",
            "-i",
            str(source),
        ]
    graph, maps = build_edit_filter(pieces, vf, has_audio=has_audio, edit_fx=edit_fx)
    cmd += ["-filter_complex", graph, *maps, *common_tail]
    run(cmd)


def render_clip(
    source: Path,
    clip: dict,
    transcript: dict,
    media: dict,
    clips_dir: Path,
    style: dict,
    quality: str = "draft",
) -> dict:
    clips_dir.mkdir(parents=True, exist_ok=True)
    srt_path = clips_dir / f"{clip['id']}.ass"
    mp4_path = clips_dir / f"{clip['id']}.mp4"
    poster_path = clips_dir / f"{clip['id']}.jpg"
    pieces = clip_pieces(clip)
    if not pieces:
        raise RuntimeError(f"{clip.get('id') or 'clip'} has no video left after cut-outs.")
    duration = output_duration(pieces)
    if isinstance(clip, dict) and "captions" in clip and isinstance(clip.get("captions"), list):
        cues = apply_cue_hold(
            remap_caption_cues(clip.get("captions"), pieces, duration),
            (style or {}).get("hold") or 0,
            duration,
        )
    else:
        source_words = saved_caption_words(clip, transcript)
        mapped_words = remap_words(source_words, pieces)
        cues = cue_groups({"words": mapped_words}, 0.0, duration, style)
    write_ass(cues, srt_path, style, duration=duration)
    crop_x = clip.get("cropX")
    crop_y = clip.get("cropY")
    try:
        crop_x = 0.5 if crop_x is None else float(crop_x)
    except (TypeError, ValueError):
        crop_x = 0.5
    try:
        crop_y = 0.5 if crop_y is None else float(crop_y)
    except (TypeError, ValueError):
        crop_y = 0.5
    vf = vertical_filter(media["width"], media["height"], srt_path, crop_x, crop_y)
    camera = clip.get("camera") if isinstance(clip.get("camera"), dict) else {}
    if _px_box(int(media["width"]), int(media["height"]), camera.get("faceBox")):
        vf = split_filter(media["width"], media["height"], srt_path, camera, crop_x, crop_y)
    try:
        out_w, out_h = short_output_size(int(media["width"]), int(media["height"]), crop_x, crop_y)
    except (TypeError, ValueError, KeyError):
        out_w = out_h = 0
    _ffmpeg_encode_window(
        source,
        pieces,
        vf,
        media,
        quality,
        mp4_path,
        edit_fx=str(clip.get("editFx") or "cut"),
    )
    run(
        [
            "ffmpeg",
            "-y",
            "-ss",
            "0.4",
            "-i",
            str(mp4_path),
            "-frames:v",
            "1",
            "-update",
            "1",
            "-q:v",
            "2",
            str(poster_path),
        ]
    )
    clip = dict(clip)
    clip["file"] = mp4_path.name
    clip["poster"] = poster_path.name
    clip["duration"] = round(duration, 3)
    clip["encoded"] = True
    if out_w >= 2 and out_h >= 2:
        clip["width"] = out_w
        clip["height"] = out_h
    return clip


def render_wide_clip(
    source: Path,
    clip: dict,
    transcript: dict,
    media: dict,
    clips_dir: Path,
    style: dict,
    quality: str = "final",
    captions: bool = False,
) -> dict:
    clips_dir.mkdir(parents=True, exist_ok=True)
    pieces = clip_pieces(clip)
    if not pieces:
        raise RuntimeError(f"{clip.get('id') or 'clip'} has no video left after cut-outs.")
    duration = output_duration(pieces)
    dest_name = f"{clip['id']}-wide-captions.mp4" if captions else f"{clip['id']}-wide.mp4"
    dest = clips_dir / dest_name
    srt_path = None
    if captions:
        srt_path = clips_dir / f"{clip['id']}-wide.ass"
        source_words = saved_caption_words(clip, transcript)
        mapped_words = remap_words(source_words, pieces)
        cues = cue_groups({"words": mapped_words}, 0.0, duration, style)
        write_ass(cues, srt_path, style, duration=duration)
    vf = wide_filter(int(media["width"]), int(media["height"]), srt_path)
    _ffmpeg_encode_window(
        source,
        pieces,
        vf,
        media,
        quality,
        dest,
        edit_fx=str(clip.get("editFx") or "cut"),
    )
    next_clip = dict(clip)
    field = "wideCaptionFile" if captions else "wideFile"
    next_clip[field] = dest.name
    next_clip["wideWidth"] = _even(int(media["width"]))
    next_clip["wideHeight"] = _even(int(media["height"]))
    return next_clip


def clips_from_status(job_dir: Path, transcript: dict, duration: float, title: str | None) -> list[dict]:
    highlights_path = job_dir / "highlights.json"
    if highlights_path.is_file():
        try:
            packed = json.loads(highlights_path.read_text())
            if isinstance(packed, list) and packed:
                return packed
        except json.JSONDecodeError:
            pass
    status_path = job_dir / "status.json"
    if status_path.is_file():
        try:
            payload = json.loads(status_path.read_text())
        except json.JSONDecodeError:
            payload = {}
        clips = payload.get("clips") or []
        if clips:
            packed = []
            for index, item in enumerate(clips, start=1):
                start = float(item.get("start") or 0)
                end = float(item.get("end") or duration)
                clip = {
                    "id": item.get("id") or f"clip-{index:02d}",
                    "start": start,
                    "end": end,
                    "duration": round(end - start, 3),
                    "score": float(item.get("score") or 1),
                    "title": item.get("title") or (title or "Full video"),
                    "captionPreview": item.get("captionPreview") or "",
                    "encoded": bool(item.get("encoded") or item.get("file")),
                    "autoEncode": bool(item.get("autoEncode")),
                }
                if item.get("file"):
                    clip["file"] = item["file"]
                if item.get("poster"):
                    clip["poster"] = item["poster"]
                for key in (
                    "suggestedTitle",
                    "suggestedTitles",
                    "titleRanks",
                    "suggestedDescription",
                    "suggestedTags",
                    "suggestEngine",
                    "suggestModel",
                    "laugh",
                    "sceneCuts",
                    "voices",
                    "cuts",
                    "speeds",
                    "holds",
                    "publishReady",
                    "youtubeUpload",
                    "tiktokUpload",
                    "instagramUpload",
                    "wideFile",
                    "wideCaptionFile",
                    "camera",
                ):
                    if item.get(key) not in (None, "", []):
                        clip[key] = item[key]
                if "captions" in item and item.get("captions") is not None:
                    clip["captions"] = item.get("captions") or []
                if item.get("cropX") is not None:
                    try:
                        clip["cropX"] = float(item["cropX"])
                    except (TypeError, ValueError):
                        pass
                if item.get("cropY") is not None:
                    try:
                        clip["cropY"] = float(item["cropY"])
                    except (TypeError, ValueError):
                        pass
                if item.get("width") is not None:
                    try:
                        clip["width"] = int(item["width"])
                    except (TypeError, ValueError):
                        pass
                if item.get("height") is not None:
                    try:
                        clip["height"] = int(item["height"])
                    except (TypeError, ValueError):
                        pass
                if item.get("wideWidth") is not None:
                    try:
                        clip["wideWidth"] = int(item["wideWidth"])
                    except (TypeError, ValueError):
                        pass
                if item.get("wideHeight") is not None:
                    try:
                        clip["wideHeight"] = int(item["wideHeight"])
                    except (TypeError, ValueError):
                        pass
                if clip.get("cuts") or clip.get("speeds") or clip.get("holds"):
                    clip["duration"] = output_duration(clip_pieces(clip))
                packed.append(clip)
            return packed
    return full_video_clip(transcript, duration, title)


def ensure_speakers(transcript: dict, wav: Path, max_speakers: int = 4) -> dict:
    words = transcript.get("words") or []
    if any(str(word.get("speaker") or "").strip() for word in words):
        return transcript
    if not wav.is_file():
        return _without_speakers(transcript)
    labeled = assign_speakers(wav, [dict(word) for word in words], max_speakers=max_speakers)
    speakers = unique_voices(labeled)
    next_payload = dict(transcript)
    next_payload["words"] = labeled
    next_payload["segments"] = stamp_segments(transcript.get("segments") or [], labeled)
    next_payload["speakers"] = speakers
    if speakers:
        next_payload["diarizeMethod"] = "overlap"
    else:
        next_payload.pop("diarizeMethod", None)
    return next_payload


def render_highlights(
    source: Path,
    highlights: list[dict],
    transcript: dict,
    media: dict,
    job_dir: Path,
    style: dict,
    only_ids: set[str] | None = None,
    quality: str = "draft",
) -> list[dict]:
    clips_dir = job_dir / "clips"
    targets = [clip for clip in highlights if only_ids is None or clip.get("id") in only_ids]
    live_by_id = {clip["id"]: dict(clip) for clip in highlights}
    taken: set[str] = set()
    kind = "draft" if quality == "draft" else "final"
    for index, clip in enumerate(targets):
        pct = 70 + int(28 * (index / max(len(targets), 1)))
        name = str(clip.get("suggestedTitle") or clip.get("title") or clip.get("id") or "Short")
        write_status(
            job_dir,
            stage="rendering",
            progress=pct,
            message=f"Encoding Short {index + 1} of {len(targets)} ({kind}).",
            detailLabel=name,
            captionStyle=style,
            clips=list(live_by_id[item["id"]] for item in highlights),
        )
        rendered = render_clip(source, clip, transcript, media, clips_dir, style, quality=quality)
        live_by_id[clip["id"]] = finalize_clip({**live_by_id[clip["id"]], **rendered}, clips_dir, taken)
        write_status(
            job_dir,
            stage="rendering",
            progress=round(70 + 28 * ((index + 1) / max(len(targets), 1)), 1),
            message=f"Encoding Short {index + 1} of {len(targets)} ({kind}).",
            detailLabel=name,
            captionStyle=style,
            clips=list(live_by_id[item["id"]] for item in highlights),
        )
    return [live_by_id[clip["id"]] for clip in highlights]


def recaption_job(args: argparse.Namespace, style: dict) -> None:
    job_dir = Path(args.job_dir).resolve()
    source = cached_source_path(job_dir, args.source_file)
    transcript_path = job_dir / "transcript.json"
    if source is None or not transcript_path.is_file():
        raise RuntimeError("Updating captions needs the source video and a saved transcript.")
    status_path = job_dir / "status.json"
    status = read_json(status_path, {}) if status_path.is_file() else {}
    encode_threshold = status.get("encodeThreshold") if isinstance(status, dict) else None
    write_status(
        job_dir,
        stage="rendering",
        progress=72,
        message="Updating captions on the encoded Shorts.",
        captionStyle=style,
        error=None,
    )
    transcript = read_json(transcript_path, {})
    wav = job_dir / "audio.wav"
    transcript = ensure_speakers(transcript, wav, max_speakers=_style_max_speakers(job_dir, style))
    transcript_path.write_text(json.dumps(transcript, indent=2))
    media = probe_media(source)
    write_status(job_dir, **media_size_fields(media))
    highlights = clips_from_status(job_dir, transcript, media["duration"], args.title)
    clips_dir = job_dir / "clips"
    already = {item["id"] for item in highlights if encoded_mp4_path(clips_dir, item)}
    if not already:
        raise RuntimeError("No encoded Shorts to recaption. Encode a review window first.")
    (job_dir / "highlights.json").write_text(json.dumps(highlights, indent=2))
    rendered = render_highlights(
        source, highlights, transcript, media, job_dir, style, only_ids=already, quality="final"
    )
    encoded_n = sum(1 for item in rendered if item.get("encoded"))
    review_n = len(rendered) - encoded_n
    extra = f" {review_n} window{'s' if review_n != 1 else ''} still in review." if review_n else ""
    write_status(
        job_dir,
        stage="done",
        progress=100,
        message=f"Ready. {encoded_n} vertical clip{'s' if encoded_n != 1 else ''} with updated captions.{extra}",
        clips=rendered,
        captionStyle=style,
        encodeThreshold=encode_threshold,
        error=None,
    )


def encode_clip_job(args: argparse.Namespace, style: dict) -> None:
    job_dir = Path(args.job_dir).resolve()
    clip_id = str(args.encode_clip or "").strip()
    source = cached_source_path(job_dir, args.source_file)
    transcript_path = job_dir / "transcript.json"
    if source is None or not transcript_path.is_file():
        raise RuntimeError("Encoding a review clip needs a cached source video and transcript.json.")
    status_path = job_dir / "status.json"
    status = read_json(status_path, {}) if status_path.is_file() else {}
    encode_threshold = status.get("encodeThreshold") if isinstance(status, dict) else None
    write_status(
        job_dir,
        stage="rendering",
        progress=74,
        message=f"Encoding {clip_id} from the saved source.",
        captionStyle=style,
        error=None,
    )
    transcript = read_json(transcript_path, {})
    wav = job_dir / "audio.wav"
    transcript = ensure_speakers(transcript, wav, max_speakers=_style_max_speakers(job_dir, style))
    transcript_path.write_text(json.dumps(transcript, indent=2))
    media = probe_media(source)
    write_status(job_dir, **media_size_fields(media))
    highlights = clips_from_status(job_dir, transcript, media["duration"], args.title)
    if not any(item.get("id") == clip_id for item in highlights):
        raise RuntimeError(f"No review window named {clip_id}.")
    rendered = render_highlights(
        source, highlights, transcript, media, job_dir, style, only_ids={clip_id}, quality="final"
    )
    clips_dir = job_dir / "clips"
    wide_mode = str(getattr(args, "wide", "") or "off").strip().lower()
    if wide_mode not in {"plain", "captions", "both"}:
        wide_mode = "off"
    taken: set[str] = set()
    next_clips: list[dict] = []
    for item in rendered:
        clip = dict(item)
        if clip.get("id") == clip_id:
            keep: set[str] = set()
            if wide_mode in {"plain", "both"}:
                keep.add("wideFile")
                write_status(
                    job_dir,
                    stage="rendering",
                    progress=88,
                    message=f"Writing the full-screen video for {clip_id}.",
                )
                clip = render_wide_clip(
                    source, clip, transcript, media, clips_dir, style, quality="final", captions=False
                )
            if wide_mode in {"captions", "both"}:
                keep.add("wideCaptionFile")
                write_status(
                    job_dir,
                    stage="rendering",
                    progress=92,
                    message=f"Writing the full-screen video with captions for {clip_id}.",
                )
                clip = render_wide_clip(
                    source, clip, transcript, media, clips_dir, style, quality="final", captions=True
                )
            clip = drop_wide_outputs(clip, clips_dir, keep=keep)
        clip = finalize_clip(clip, clips_dir, taken)
        next_clips.append(clip)
    rendered = next_clips
    (job_dir / "highlights.json").write_text(json.dumps(rendered, indent=2))
    encoded_n = sum(1 for item in rendered if item.get("encoded"))
    review_n = len(rendered) - encoded_n
    extra = f" {review_n} window{'s' if review_n != 1 else ''} still in review." if review_n else ""
    write_status(
        job_dir,
        stage="done",
        progress=100,
        message=f"Ready. Encoded {clip_id}. {encoded_n} Short{'s' if encoded_n != 1 else ''} on disk.{extra}",
        clips=rendered,
        captionStyle=style,
        encodeThreshold=encode_threshold,
        error=None,
    )


def resolve_source(args: argparse.Namespace, job_dir: Path) -> Path:
    if args.source_file:
        source = Path(args.source_file).resolve()
        if not source.exists():
            raise FileNotFoundError(f"Source file not found: {source}")
        write_status(
            job_dir,
            stage="transcribing",
            progress=22,
            message="Using the local file. YouTube will not be fetched.",
            title=args.title or source.stem,
            sourceFile=str(source),
        )
        adopt_cached_transcript(job_dir, source)
        drop_job_source_alias(job_dir, source)
        return source

    existing = merged_source(job_dir)
    if existing:
        write_status(
            job_dir,
            stage="downloading",
            progress=18,
            message="Using the source already in this project. YouTube will not be fetched.",
            title=args.title or existing.stem,
        )
        if args.source_file:
            adopt_cached_transcript(job_dir, Path(args.source_file).resolve())
        else:
            adopt_cached_transcript(job_dir, existing)
        return existing

    if args.skip_download:
        raise FileNotFoundError("skip-download was set, but this job folder has no source video.")

    cached = find_cached_source(args.url, exclude=job_dir)
    if cached:
        write_status(
            job_dir,
            stage="downloading",
            progress=18,
            message="Using a saved copy of this video. YouTube will not be fetched.",
            title=args.title or cached.stem,
        )
        adopt_cached_transcript(job_dir, cached)
        return materialize_source(cached, job_dir)

    if not args.url:
        raise ValueError("A YouTube URL is required.")
    source, meta = download_youtube(args.url, job_dir)
    if meta.get("title") and not args.title:
        write_status(job_dir, title=meta["title"])
    return materialize_source(source, job_dir)


def _flag_value(name: str) -> str:
    flag = f"--{name}"
    prefix = f"{flag}="
    argv = sys.argv[1:]
    for index, item in enumerate(argv):
        if item.startswith(prefix):
            return item[len(prefix) :].strip()
        if item == flag and index + 1 < len(argv) and not str(argv[index + 1]).startswith("-"):
            return str(argv[index + 1]).strip()
    return ""


def run_job(args: argparse.Namespace) -> None:
    job_dir = Path(args.job_dir).resolve()
    job_dir.mkdir(parents=True, exist_ok=True)
    style = parse_caption_style(args.caption_style)
    if not (args.caption_style or "").strip():
        existing_status = job_dir / "status.json"
        if existing_status.is_file():
            try:
                payload = json.loads(existing_status.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                payload = {}
            if isinstance(payload.get("captionStyle"), dict):
                style = parse_caption_style(json.dumps(payload["captionStyle"]))

    status = {
        "id": job_dir.name,
        "url": args.url,
        "title": args.title,
        "stage": "queued",
        "progress": 4,
        "message": "Starting Discover Shorts.",
        "error": None,
        "clips": [],
        "createdAt": utc_now(),
        "sourceDuration": None,
        "transcriptionEngine": None,
        "mode": "full" if args.full_video else "highlights",
        "captionStyle": style,
    }
    if args.recaption_only:
        recaption_job(args, style)
        return
    encode_id = str(args.encode_clip or "").strip()
    if not encode_id:
        encode_id = _flag_value("encode-clip")
        if encode_id:
            args.encode_clip = encode_id
    if encode_id:
        encode_clip_job(args, style)
        return

    if not (job_dir / "status.json").exists():
        write_status(job_dir, **status)
    else:
        write_status(
            job_dir,
            stage="queued",
            progress=4,
            message="Starting Discover Shorts.",
            error=None,
            captionStyle=style,
        )

    source = resolve_source(args, job_dir)
    if args.source_file:
        adopt_cached_transcript(job_dir, Path(args.source_file).resolve())
    media = probe_media(source)
    write_status(job_dir, title=args.title or None, **media_size_fields(media))
    mark_saved(job_dir, "downloaded")

    if getattr(args, "download_only", False):
        write_status(
            job_dir,
            stage="done",
            progress=100,
            message=(
                "The source video is saved on this computer. Nothing was transcribed or generated. "
                "Run Discover Shorts again on this source to find moments."
            ),
            captionStyle=style,
            clips=[],
            speakers=[],
        )
        return

    transcript_path = job_dir / "transcript.json"
    existing_transcript = None
    if transcript_path.is_file():
        try:
            existing_transcript = json.loads(transcript_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            existing_transcript = None
    if args.skip_transcribe and existing_transcript is None:
        raise RuntimeError("skip-transcribe was set, but no usable transcript.json was found beside this source.")
    source_duration = float(media["duration"] or 0)
    if transcript_is_complete(existing_transcript, source_duration):
        transcript = existing_transcript or {}
        write_status(
            job_dir,
            stage="scoring",
            progress=58,
            message="Using the transcript already on disk.",
            detailLabel=heard_label(transcript_last_end(transcript), source_duration),
            transcriptPreview=" ".join(
                seg.get("text", "") for seg in (transcript.get("segments") or [])[:4]
            ).strip()[:280],
            transcriptionEngine=transcript.get("transcriptionEngine") or f"faster-whisper {WHISPER_MODEL}",
            speakers=transcript.get("speakers") or [],
        )
    elif transcript_can_resume(existing_transcript, source_duration):
        last = transcript_last_end(existing_transcript)
        write_status(
            job_dir,
            stage="transcribing",
            progress=40,
            message=f"Resuming from {minutes_clock(last)} of {minutes_clock(source_duration)}.",
            detailLabel=heard_label(last, source_duration),
        )
        wav = job_dir / "audio.wav"
        if not wav.is_file():
            write_status(
                job_dir,
                stage="transcribing",
                progress=32,
                message="Pulling audio from the source.",
            )
            wav = extract_audio(source, job_dir)

        def on_resume_progress(heard: float) -> None:
            total = source_duration if source_duration > 0 else max(heard, 1.0)
            frac = min(1.0, max(0.0, heard / total))
            write_status_throttled(
                job_dir,
                stage="transcribing",
                progress=round(32 + 24 * frac, 1),
                message="Listening to the speech.",
                detailLabel=heard_label(heard, total),
            )

        payload = transcribe_resume(
            wav, job_dir, existing_transcript or {}, last, source_duration, on_progress=on_resume_progress
        )
        transcript = finish_transcript(wav, job_dir, payload)
        write_status(
            job_dir,
            transcriptPreview=" ".join(seg["text"] for seg in (transcript.get("segments") or [])[:4]).strip()[:280],
            transcriptionEngine=transcript.get("transcriptionEngine"),
            speakers=transcript.get("speakers") or [],
        )
    else:
        write_status(
            job_dir,
            stage="transcribing",
            progress=28,
            message="Pulling audio from the source.",
        )
        wav = extract_audio(source, job_dir)
        transcript = transcribe(wav, job_dir, source)
        preview = " ".join(seg["text"] for seg in transcript["segments"][:4]).strip()
        write_status(
            job_dir,
            transcriptPreview=preview[:280],
            transcriptionEngine=f"faster-whisper {WHISPER_MODEL}",
            speakers=transcript.get("speakers") or [],
        )

    mark_saved(job_dir, "transcribed")

    full_video = bool(args.full_video)
    if full_video and float(media["duration"] or 0) > FULL_VIDEO_MAX_SECONDS:
        write_status(
            job_dir,
            stage="scoring",
            progress=60,
            message=(
                f"This video is {minutes_clock(float(media['duration']))}. "
                "Full video is limited to 3 minutes, so highlight windows will be used instead."
            ),
        )
        full_video = False
    write_status(
        job_dir,
        mode="full" if full_video else "highlights",
        captionStyle=style,
    )
    encode_threshold = 0.0
    only_ids: set[str] | None = None
    if full_video:
        write_status(
            job_dir,
            stage="rendering",
            progress=62,
            message="Skipping highlight picking. Encoding the full video as one 9:16 Short.",
        )
        highlights = full_video_clip(transcript, media["duration"], args.title)
        for item in highlights:
            item["autoEncode"] = True
    else:
        write_status(
            job_dir,
            stage="scoring",
            progress=62,
            message="Scoring highlight windows.",
        )
        wav_path = job_dir / "audio.wav"
        highlights = pick_highlights(
            transcript,
            media["duration"],
            max_clips=args.max_clips,
            source_title=args.title,
            wav_path=wav_path if wav_path.is_file() else None,
            source_path=source,
            job_dir=job_dir,
            focus=args.focus,
        )
        highlights = apply_min_highlight_score(highlights, resolved_min_highlight_score(args))
        laugh_n = sum(1 for item in highlights if item.get("laugh"))
        scene_n = sum(1 for item in highlights if int(item.get("sceneCuts") or 0) > 0)
        if laugh_n or scene_n:
            write_status(
                job_dir,
                stage="scoring",
                progress=64,
                message=(
                    "Picked highlight windows."
                    + (" Some include laughter." if laugh_n else "")
                    + (" Some include a scene change." if scene_n else "")
                ),
            )
        highlights, encode_threshold = select_auto_encode(highlights)
        only_ids = {item["id"] for item in highlights if item.get("autoEncode")}
    if not getattr(args, "skip_llm", False):
        chat_ready = False
        try:
            import suggest as suggest_mod

            chat_ready = suggest_mod.llm_config() is not None
        except Exception:
            chat_ready = False
        if chat_ready:
            from suggest import attach_suggestions

            titled = [item for item in highlights if item.get("autoEncode")]
            title_total = len(titled)
            write_status(
                job_dir,
                stage="scoring",
                progress=66,
                message="Writing titles.",
                detailLabel=f"Short 1 of {title_total}" if title_total else None,
            )
            segments = transcript.get("segments") or []
            upgraded = []
            titled_index = 0
            for item in highlights:
                if item.get("autoEncode"):
                    titled_index += 1
                    write_status(
                        job_dir,
                        stage="scoring",
                        progress=round(66 + 3 * (titled_index / max(title_total, 1)), 1),
                        message="Writing titles.",
                        detailLabel=f"Short {titled_index} of {title_total}",
                    )
                    text = window_text(segments, float(item["start"]), float(item["end"]))
                    brief = moment_brief(item)
                    if brief:
                        text = f"This moment has {brief}.\n{text}"
                    if args.focus:
                        text = f"The viewer's interest is: {args.focus}.\n{text}"
                    try:
                        upgraded.append(
                            attach_suggestions(
                                item,
                                text,
                                source_title=args.title,
                                use_llm=True,
                                style=style,
                                models_limit=1,
                            )
                        )
                    except Exception as exc:
                        print(f"Chat titles skipped for {item.get('id')}: {exc}", file=sys.stderr)
                        upgraded.append(item)
                else:
                    upgraded.append(item)
            highlights = upgraded
    (job_dir / "highlights.json").write_text(json.dumps(highlights, indent=2))
    mark_saved(job_dir, "windows")

    rendered = render_highlights(source, highlights, transcript, media, job_dir, style, only_ids=only_ids)
    (job_dir / "highlights.json").write_text(json.dumps(rendered, indent=2))
    encoded_n = sum(1 for item in rendered if item.get("encoded"))
    review_n = len(rendered) - encoded_n
    if review_n:
        done_message = (
            f"Ready. {encoded_n} Short{'s' if encoded_n != 1 else ''} encoded "
            f"(the highest scores, down to {encode_threshold:.0f}). "
            f"{review_n} more saved as timestamps for review."
        )
    else:
        done_message = f"Ready. {encoded_n} vertical clip{'s' if encoded_n != 1 else ''} with captions."

    mark_saved(job_dir, "clips")

    write_status(
        job_dir,
        stage="done",
        progress=100,
        message=done_message,
        clips=rendered,
        captionStyle=style,
        speakers=transcript.get("speakers") or [],
        encodeThreshold=encode_threshold,
        error=None,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="60 Second Clip Creator YouTube-to-Shorts pipeline")
    parser.add_argument("--job-dir", required=True)
    parser.add_argument("--url")
    parser.add_argument("--source-file")
    parser.add_argument("--title")
    parser.add_argument(
        "--max-clips",
        type=int,
        default=0,
        help="Highlight cap. 0 keeps every decent non-overlapping window.",
    )
    parser.add_argument(
        "--full-video",
        action="store_true",
        help="Skip highlight picking and render the whole source as one 9:16 clip.",
    )
    parser.add_argument(
        "--skip-download",
        action="store_true",
        help="Never call yt-dlp. Use --source-file or a source video already in the job folder.",
    )
    parser.add_argument(
        "--skip-transcribe",
        action="store_true",
        help="Reuse transcript.json in the job folder. Do not run Whisper.",
    )
    parser.add_argument(
        "--recaption-only",
        action="store_true",
        help="Reburn captions from the cached source and transcript. Do not fetch or transcribe.",
    )
    parser.add_argument(
        "--encode-clip",
        default="",
        help="Encode one review window by id (clip-07) from the cached source.",
    )
    parser.add_argument(
        "--wide",
        default="off",
        help="Also write a full-screen file of that window: off, plain, captions, or both.",
    )
    parser.add_argument(
        "--skip-llm",
        action="store_true",
        help="Do not call a chat model. Recut and recaption always set this.",
    )
    parser.add_argument(
        "--min-highlight-score",
        type=float,
        default=-1,
        help="Drop review windows below this 0-100 score. Encoded Shorts still keep the top 6.",
    )
    parser.add_argument(
        "--caption-style",
        default="",
        help="JSON object with theme (tactical|twin|punch) and position (bottom|center|top).",
    )
    parser.add_argument(
        "--focus",
        default="",
        help="Words or phrases the highlight windows should be about. Boosts scoring, does not filter.",
    )
    parser.add_argument(
        "--download-only",
        action="store_true",
        help="Fetch the source video and stop. Do not transcribe, score, or render anything.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    job_dir = Path(args.job_dir)
    job_dir.mkdir(parents=True, exist_ok=True)
    try:
        run_job(args)
        return 0
    except Exception as exc:
        write_status(
            job_dir,
            stage="error",
            progress=0,
            error=friendly_error(exc),
            message="The pipeline stopped before clips were ready.",
        )
        traceback_path = job_dir / "error.log"
        traceback_path.write_text(traceback.format_exc())
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
