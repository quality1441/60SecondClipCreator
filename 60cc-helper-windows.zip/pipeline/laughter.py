"""Find laugh bursts from audio and transcript text (Whisper often skips laughs)."""

from __future__ import annotations

import re
import wave
from pathlib import Path

import numpy as np

LAUGH_TOKEN_RE = re.compile(
    r"(haha+|ha-ha+|hehe+|lol+|lmao|rofl|laugh|laughing|laughter|giggle|chuckle|\(laugh)",
    re.I,
)


def _load_wav(path: Path) -> tuple[np.ndarray, int]:
    with wave.open(str(path), "rb") as handle:
        sr = handle.getframerate()
        channels = handle.getnchannels()
        sample_width = handle.getsampwidth()
        frames = handle.readframes(handle.getnframes())
    if sample_width == 2:
        audio = np.frombuffer(frames, dtype=np.int16).astype(np.float32)
    else:
        audio = np.frombuffer(frames, dtype=np.uint8).astype(np.float32) - 128.0
    if channels >= 2:
        audio = audio.reshape(-1, channels).mean(axis=1)
    peak = float(np.max(np.abs(audio)) or 1.0)
    return audio / peak, sr


def _envelope(audio: np.ndarray, sr: int, hop_s: float = 0.02, win_s: float = 0.04) -> np.ndarray:
    hop = max(1, int(sr * hop_s))
    win = max(hop, int(sr * win_s))
    sq = audio * audio
    c = np.cumsum(np.concatenate(([0.0], sq)))
    idx = np.arange(win, len(c), hop)
    if idx.size == 0:
        return np.zeros(0, dtype=np.float32)
    return np.sqrt(np.maximum((c[idx] - c[idx - win]) / win, 0.0)).astype(np.float32)


def _zero_crossing_rate(audio: np.ndarray, sr: int, hop_s: float = 0.02, win_s: float = 0.04) -> np.ndarray:
    hop = max(1, int(sr * hop_s))
    win = max(hop, int(sr * win_s))
    signs = np.sign(audio)
    signs[signs == 0] = 1
    chg = (signs[1:] * signs[:-1] < 0).astype(np.float32)
    c = np.cumsum(np.concatenate(([0.0], chg)))
    idx = np.arange(win, min(len(c), len(audio) + 1), hop)
    if idx.size == 0:
        return np.zeros(0, dtype=np.float32)
    return ((c[idx] - c[idx - win]) / win).astype(np.float32)


def _merge_spans(raw: list[tuple[float, float, float]], gap: float = 0.55) -> list[tuple[float, float, float]]:
    if not raw:
        return []
    ordered = sorted(raw, key=lambda item: item[0])
    merged: list[list[float]] = [[ordered[0][0], ordered[0][1], ordered[0][2]]]
    for start, end, weight in ordered[1:]:
        if start <= merged[-1][1] + gap:
            merged[-1][1] = max(merged[-1][1], end)
            merged[-1][2] = max(merged[-1][2], weight)
        else:
            merged.append([start, end, weight])
    out: list[tuple[float, float, float]] = []
    for start, end, weight in merged:
        if end - start < 0.18:
            continue
        out.append((round(start, 3), round(end, 3), round(float(weight), 3)))
    return out


def laugh_spans_from_text(transcript: dict | None) -> list[tuple[float, float, float]]:
    if not transcript:
        return []
    raw: list[tuple[float, float, float]] = []
    for word in transcript.get("words") or []:
        token = str(word.get("word") or "")
        if not LAUGH_TOKEN_RE.search(token):
            continue
        start = max(0.0, float(word.get("start") or 0) - 0.12)
        end = float(word.get("end") or start) + 0.45
        raw.append((start, end, 0.85))
    for seg in transcript.get("segments") or []:
        text = str(seg.get("text") or "")
        if not LAUGH_TOKEN_RE.search(text):
            continue
        start = max(0.0, float(seg.get("start") or 0) - 0.2)
        end = float(seg.get("end") or start) + 0.3
        raw.append((start, end, 0.7))
    return _merge_spans(raw, gap=0.8)


def laugh_spans_from_audio(wav_path: Path) -> list[tuple[float, float, float]]:
    if not wav_path.is_file():
        return []
    audio, sr = _load_wav(wav_path)
    if audio.size < sr:
        return []
    hop_s = 0.02
    env = _envelope(audio, sr, hop_s=hop_s)
    zcr = _zero_crossing_rate(audio, sr, hop_s=hop_s)
    n = min(len(env), len(zcr))
    env = env[:n]
    zcr = zcr[:n]
    if n < 40:
        return []
    local = np.convolve(env, np.ones(80, dtype=np.float32) / 80.0, mode="same")
    rel = env / (local + 1e-4)
    block = 60
    step = 12
    hop_freq = 1.0 / hop_s
    raw: list[tuple[float, float, float]] = []
    for i in range(0, n - block, step):
        sl = env[i : i + block]
        mean_e = float(sl.mean())
        if mean_e < 0.035:
            continue
        spec = np.abs(np.fft.rfft(sl - sl.mean()))
        freqs = np.fft.rfftfreq(block, d=hop_s)
        band = (freqs >= 2.4) & (freqs <= 7.2)
        mod = float(spec[band].sum() / (spec.sum() + 1e-8))
        burst = float(np.max(rel[i : i + block]))
        z = float(np.mean(zcr[i : i + block]))
        if mod < 0.26 or burst < 1.75 or z < 0.07:
            continue
        weight = mod * min(burst, 6.0) * min(mean_e * 8.0, 3.0)
        if weight < 0.8:
            continue
        mid = (i + block / 2.0) / hop_freq
        raw.append((mid - 0.35, mid + 0.55, weight))
    if not raw:
        return []
    weights = np.array([item[2] for item in raw], dtype=np.float32)
    thr = max(float(np.percentile(weights, 92)), 0.9)
    kept = [item for item in raw if item[2] >= thr]
    return _merge_spans(kept, gap=0.5)


def detect_laughter(wav_path: Path | None, transcript: dict | None = None) -> list[tuple[float, float, float]]:
    text_spans = laugh_spans_from_text(transcript)
    audio_spans = laugh_spans_from_audio(wav_path) if wav_path else []
    return _merge_spans(text_spans + audio_spans, gap=0.65)


def laugh_overlap_seconds(start: float, end: float, spans: list[tuple[float, float, float]]) -> float:
    total = 0.0
    for s0, s1, _weight in spans:
        total += max(0.0, min(end, s1) - max(start, s0))
    return total
