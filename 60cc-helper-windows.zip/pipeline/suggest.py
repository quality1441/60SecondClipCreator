#!/usr/bin/env python3
"""Title, description, and tag suggestions for a Short window."""

from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.request
from functools import lru_cache
from pathlib import Path

from title_rank import extract_context, formula_titles, rank_titles

HOOK_WORDS = {
    "actually",
    "because",
    "crazy",
    "finally",
    "how",
    "important",
    "insane",
    "look",
    "mistake",
    "never",
    "remember",
    "secret",
    "stop",
    "tip",
    "trick",
    "wait",
    "warning",
    "watch",
    "why",
}

FILLER = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "but",
    "for",
    "from",
    "had",
    "has",
    "have",
    "i",
    "i'm",
    "im",
    "in",
    "is",
    "it",
    "it's",
    "its",
    "just",
    "like",
    "me",
    "my",
    "of",
    "oh",
    "ok",
    "okay",
    "on",
    "really",
    "so",
    "that",
    "the",
    "this",
    "to",
    "uh",
    "um",
    "was",
    "we",
    "well",
    "yeah",
    "yes",
    "you",
    "your",
}

STOP_TAGS = FILLER | {
    "about",
    "around",
    "been",
    "being",
    "bro",
    "can",
    "clip",
    "close",
    "could",
    "did",
    "do",
    "does",
    "doing",
    "done",
    "found",
    "get",
    "gonna",
    "good",
    "got",
    "here",
    "him",
    "her",
    "hopefully",
    "into",
    "know",
    "let",
    "nice",
    "none",
    "not",
    "now",
    "one",
    "out",
    "pretty",
    "right",
    "some",
    "somebody",
    "sorry",
    "thanks",
    "them",
    "then",
    "there",
    "they",
    "thing",
    "those",
    "too",
    "try",
    "up",
    "very",
    "want",
    "what",
    "when",
    "where",
    "who",
    "will",
    "with",
    "would",
    "yeah",
}

LEAD_FILLER = re.compile(
    r"^(so|and|but|well|okay|ok|um|uh|yeah|like|anyway)\s+",
    re.IGNORECASE,
)
TRAIL_FILLER = re.compile(
    r"(?:,)?\s+(so|and|but|well|yeah|like)$",
    re.IGNORECASE,
)


def clean_dashes(value: str) -> str:
    return (
        value.replace("\u2014", ",")
        .replace("\u2013", "-")
        .replace("\u2212", "-")
    )


def tidy(value: str) -> str:
    text = clean_dashes(value or "")
    text = re.sub(r"\s+", " ", text).strip(" \t\n\r\"'")
    return text


def sentences(text: str) -> list[str]:
    chunks = re.split(r"(?<=[.!?])\s+", tidy(text))
    out = []
    for chunk in chunks:
        item = LEAD_FILLER.sub("", tidy(chunk))
        if len(item) < 8:
            continue
        out.append(item)
    return out or ([tidy(text)] if tidy(text) else [])


def tokens(text: str) -> list[str]:
    return re.findall(r"[A-Za-z0-9']+", text.lower())


def trim_chars(text: str, limit: int) -> str:
    text = tidy(text)
    if len(text) <= limit:
        return text
    cut = text[: limit + 1]
    if " " in cut:
        cut = cut.rsplit(" ", 1)[0]
    return cut.rstrip(" ,;:-")


def title_case(text: str) -> str:
    words = text.split()
    small = {"a", "an", "and", "at", "for", "from", "in", "of", "on", "or", "the", "to"}
    out = []
    for index, word in enumerate(words):
        low = word.lower()
        if index > 0 and index < len(words) - 1 and low in small:
            out.append(low)
        elif word.isupper() and len(word) <= 4:
            out.append(word)
        else:
            out.append(word[:1].upper() + word[1:])
    return " ".join(out)


TITLE_MIN = 28
TITLE_MAX = 70
TITLE_SWEET_MIN = 40
TITLE_SWEET_MAX = 60
LEAD_ARTICLE = re.compile(r"^(the|a|an)\s+", re.IGNORECASE)
EMOJI_RE = re.compile(
    "["
    "\U0001F300-\U0001FAFF"
    "\U00002700-\U000027BF"
    "\U00002600-\U000026FF"
    "]+",
    flags=re.UNICODE,
)


def sentence_case(text: str) -> str:
    words = tidy(text).split()
    if not words:
        return ""
    out: list[str] = []
    cap_next = True
    for word in words:
        stripped = word.strip("\"'")
        if stripped.isupper() and 2 <= len(stripped) <= 4:
            out.append(word)
            cap_next = stripped.endswith(("?", "!", "."))
            continue
        low = stripped.lower()
        if low == "i" or low.startswith("i'"):
            rebuilt = "I" + stripped[1:]
        elif cap_next:
            rebuilt = stripped[:1].upper() + stripped[1:].lower()
        else:
            rebuilt = stripped.lower()
        out.append(word.replace(stripped, rebuilt, 1))
        cap_next = stripped.endswith(("?", "!", "."))
    return " ".join(out)


def apply_title_rules(raw: str) -> str:
    """Shape a Shorts title: hook first, 40-70 chars, no hashtags or shouty caps."""
    text = tidy(raw)
    text = re.sub(r"[#@]", "", text)
    text = EMOJI_RE.sub("", text)
    text = LEAD_FILLER.sub("", text)
    text = LEAD_ARTICLE.sub("", text)
    text = TRAIL_FILLER.sub("", text)
    if not text.endswith(("?", "!")):
        text = text.rstrip(".")
    text = sentence_case(text)
    if len(text) > TITLE_MAX and "," in text[: TITLE_MAX + 1]:
        clause = text[:TITLE_MAX].rsplit(",", 1)[0].strip()
        if len(clause) >= TITLE_MIN:
            text = clause
            if not text.endswith(("?", "!")):
                text = text.rstrip(".")
    return trim_chars(text, TITLE_MAX)


def score_title(title: str) -> float:
    text = tidy(title)
    if not text:
        return -10.0
    n = len(text)
    words = tokens(text)
    score = 0.0
    if TITLE_SWEET_MIN <= n <= TITLE_SWEET_MAX:
        score += 3.4
    elif TITLE_MIN <= n <= TITLE_MAX:
        score += 1.6
    elif n < 22:
        score -= 2.2
    else:
        score -= 1.4
    if "?" in text[:40]:
        score += 2.5
    if 5 <= len(words) <= 12:
        score += 1.7
    elif len(words) < 4:
        score -= 1.8
    repeats = sum(1 for left, right in zip(words, words[1:]) if left == right)
    score -= repeats * 1.8
    if any(word in HOOK_WORDS for word in words[:4]):
        score += 2.0
    if text.endswith("?"):
        score += 2.1
    if text.endswith("!"):
        score += 0.7
    if text.isupper() and n > 8:
        score -= 5.0
    if "#" in text or "@" in text:
        score -= 4.0
    if words and words[0] in {"the", "this", "a", "an"}:
        score -= 1.2
    if re.search(r"\d", text):
        score += 0.6
    return score


def _phrases(text: str) -> list[str]:
    found: list[str] = []
    for sentence in sentences(text):
        found.append(sentence)
        for part in re.split(r"[,;:/]", sentence):
            piece = tidy(part)
            if TITLE_MIN - 10 <= len(piece) <= TITLE_MAX + 8 and 3 <= len(tokens(piece)) <= 14:
                found.append(piece)
    return found


def _as_question(phrase: str) -> str | None:
    text = apply_title_rules(phrase)
    if not text or text.endswith("?"):
        return text or None
    words = tokens(text)
    if not words:
        return None
    if words[0] in {"why", "how", "what", "did", "do", "are", "is", "can"}:
        return apply_title_rules(text.rstrip(".!") + "?")
    if "you" in words and len(words) <= 10:
        return apply_title_rules(text.rstrip(".!") + "?")
    return None


def _open_loop(phrase: str, transcript_words: set[str]) -> str | None:
    text = apply_title_rules(phrase)
    if not text:
        return None
    words = tokens(text)
    if any(word in {"never", "almost", "wait", "insane", "actually"} for word in words):
        return text
    if "wait" in transcript_words and not text.lower().startswith("wait"):
        looped = apply_title_rules(f"Wait, {text[:1].lower() + text[1:]}")
        if TITLE_MIN <= len(looped) <= TITLE_MAX:
            return looped
    return None


def _front_load(phrase: str) -> str | None:
    if "," not in phrase:
        return None
    left, right = phrase.split(",", 1)
    left, right = tidy(left), tidy(right)
    if len(tokens(left)) < 3 or len(tokens(right)) < 2:
        return None
    right_shaped = apply_title_rules(right)
    left_shaped = apply_title_rules(left)
    if not right_shaped or not left_shaped:
        return None
    if score_title(right_shaped) < score_title(left_shaped) and not right.rstrip().endswith("?"):
        return None
    tail = left_shaped[:1].lower() + left_shaped[1:]
    if right_shaped.endswith("?"):
        combined = f"{right_shaped} {left_shaped}"
    else:
        combined = f"{right_shaped}, {tail}"
    return apply_title_rules(combined)


def _too_similar(left: str, right: str) -> bool:
    words_a, words_b = set(tokens(left)), set(tokens(right))
    if not words_a or not words_b:
        return False
    if words_a <= words_b or words_b <= words_a:
        return True
    return len(words_a & words_b) / len(words_a | words_b) >= 0.72


def _usable_phrase(phrase: str) -> bool:
    words = tokens(phrase)
    if len(words) < 3:
        return False
    content = [word for word in words if word not in STOP_TAGS and word not in FILLER and len(word) >= 4]
    if len(content) < 2:
        return False
    if len(content) / max(len(words), 1) < 0.35:
        return False
    return True


def editor_pitch(description: str) -> str:
    lines: list[str] = []
    for raw in (description or "").splitlines():
        line = tidy(raw)
        if not line:
            continue
        if line.lower().startswith("from:"):
            continue
        if line.startswith("#") or re.fullmatch(r"(#\S+\s*)+", line):
            continue
        line = re.sub(r"#\S+", "", line)
        line = LEAD_FILLER.sub("", tidy(line))
        if line:
            lines.append(line)
    return tidy(" ".join(lines))


def titles_from_pitch(pitch: str) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()

    def add(candidate: str | None) -> None:
        shaped = apply_title_rules(candidate or "")
        if not shaped or len(tokens(shaped)) < 2:
            return
        key = shaped.lower()
        if key in seen:
            return
        seen.add(key)
        out.append(shaped)

    add(pitch)
    add(trim_chars(pitch, TITLE_MAX))
    for sentence in sentences(pitch):
        add(sentence)
        add(_as_question(sentence))
        add(_front_load(sentence))
        if len(out) >= 8:
            break
    if len(out) == 1 and not out[0].endswith("?"):
        add(out[0].rstrip(".!") + "?")
    return out


def title_options(text: str, source_title: str | None, description: str = "") -> list[str]:
    """Several Shorts titles from the editor pitch when present, else the window."""
    pitch = editor_pitch(description)
    context = extract_context(text, source_title, description=pitch)
    moment = tidy(str(context.get("moment") or ""))
    raw_options: list[str] = []

    def add(candidate: str | None, require_usable: bool = True) -> None:
        shaped = apply_title_rules(candidate or "")
        if not shaped:
            return
        if require_usable and not _usable_phrase(shaped):
            if not (moment and moment in shaped.lower() and len(tokens(shaped)) >= 2):
                return
        key = shaped.lower()
        if any(key == item.lower() for item in raw_options):
            return
        raw_options.append(shaped)

    for item in titles_from_pitch(pitch):
        add(item, require_usable=False)
    if pitch and len(raw_options) >= 4:
        return raw_options[:4]

    phrases = [item for item in _phrases(text) if _usable_phrase(item)]
    transcript_words = set(tokens(text))
    ranked_phrases = []
    for phrase in phrases:
        words = tokens(phrase)
        if not words:
            continue
        score = 0.0
        if phrase.endswith("?"):
            score += 3.0
        if phrase.endswith("!"):
            score += 1.6
        score += sum(1.2 for word in words if word in HOOK_WORDS)
        if moment and moment in phrase.lower():
            score += 4.0
        if pitch:
            pitch_words = set(tokens(pitch))
            score += 3.0 * len(pitch_words & set(words))
        if 5 <= len(words) <= 14:
            score += 1.4
        ranked_phrases.append((score, phrase))
    ranked_phrases.sort(key=lambda item: -item[0])

    if moment:
        add(moment)
        add(f"What happened in the {moment}")
    if ranked_phrases:
        add(ranked_phrases[0][1])
        add(_front_load(ranked_phrases[0][1]))
        add(_as_question(ranked_phrases[0][1]))
    for _score, phrase in ranked_phrases:
        add(_front_load(phrase))
        add(_as_question(phrase))
        add(_open_loop(phrase, transcript_words))
        add(phrase)
        if len(raw_options) >= 10:
            break
    source = useful_source_title(source_title)
    if source and 4 <= len(tokens(source)) <= 12:
        add(source)

    pitch_keys = {item.lower() for item in titles_from_pitch(pitch)}
    scored = sorted(
        raw_options,
        key=lambda item: score_title(item) + (12 if item.lower() in pitch_keys else 0),
        reverse=True,
    )
    picked: list[str] = []
    for item in scored:
        if any(item.lower() == other.lower() or _too_similar(item, other) for other in picked):
            continue
        picked.append(item)
        if len(picked) >= 4:
            break
    if not picked:
        picked = [apply_title_rules(moment or source or "Untitled Short") or "Untitled Short"]
    return picked


def ranked_title_options(
    text: str,
    source_title: str | None,
    tags: list[str] | None = None,
    description: str = "",
) -> tuple[list[str], list[dict]]:
    pitch = editor_pitch(description)
    context = extract_context(text, source_title, tags=tags, description=pitch)
    spoken = title_options(text, source_title, description=pitch)
    formulas = [] if pitch else formula_titles(context)
    ranks = rank_titles([*spoken, *formulas], context)
    if pitch:
        pitch_keys = {item.lower() for item in titles_from_pitch(pitch)}
        ranks.sort(key=lambda item: (0 if item["title"].lower() in pitch_keys else 1, -item["score"]))
    picked = ranks[:4]
    if not picked:
        fallback = apply_title_rules(source_title or "Untitled Short") or "Untitled Short"
        picked = [rank_title_safe(fallback, context)]
    return [item["title"] for item in picked], picked


def rank_title_safe(title: str, context: dict) -> dict:
    ranked = rank_titles([title], context)
    return ranked[0] if ranked else {"title": title, "score": 1, "band": "red", "reasons": []}


def pick_title(text: str, source_title: str | None, description: str = "") -> str:
    return title_options(text, source_title, description=description)[0]


def useful_source_title(source_title: str | None) -> str | None:
    title = tidy(source_title or "")
    if not title:
        return None
    if title.lower() in {"source", "full video", "untitled", "untitled short"}:
        return None
    if re.fullmatch(r"source\.[a-z0-9]+", title, flags=re.IGNORECASE):
        return None
    return title


def keyword_tags(text: str, source_title: str | None, description: str = "") -> list[str]:
    source = useful_source_title(source_title)
    pitch = editor_pitch(description)
    words = tokens(f"{pitch} {text} {source or ''}")
    counts: dict[str, int] = {}
    for word in words:
        if word in STOP_TAGS or len(word) < 4:
            continue
        if word.isdigit() or "'" in word:
            continue
        counts[word] = counts.get(word, 0) + 1
    phrases: dict[str, int] = {}
    for index in range(len(words) - 1):
        left, right = words[index], words[index + 1]
        if left in STOP_TAGS or right in STOP_TAGS:
            continue
        if len(left) < 3 or len(right) < 3 or "'" in left or "'" in right:
            continue
        phrase = f"{left} {right}"
        phrases[phrase] = phrases.get(phrase, 0) + 1
    ranked_phrases = sorted(phrases.items(), key=lambda item: (-item[1], item[0]))
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    tags: list[str] = []
    seen: set[str] = set()

    def add(tag: str) -> None:
        clean = tidy(tag).lower()
        if not clean or clean in seen or len(clean) < 2:
            return
        if clean in {"shorts", "youtube shorts", "highlight", "fyp", "viral", "trending"}:
            return
        seen.add(clean)
        tags.append(clean)

    if source:
        for part in re.split(r"[\s|/,-]+", source):
            if part and part.lower() not in STOP_TAGS:
                add(part)
    for phrase, _count in ranked_phrases[:8]:
        add(phrase)
    for word, _count in ranked:
        add(word)
        if len(tags) >= 12:
            break
    add("shorts")
    add("youtube shorts")
    packed: list[str] = []
    used = 0
    for tag in tags:
        extra = len(tag) + (1 if packed else 0)
        if used + extra > 480:
            break
        packed.append(tag)
        used += extra
    return packed[:14]


def hashtags(tags: list[str]) -> str:
    marks = []
    for tag in tags:
        if " " in tag:
            continue
        token = re.sub(r"[^A-Za-z0-9]", "", tag)
        if len(token) < 3:
            continue
        marks.append(f"#{token[:24]}")
        if len(marks) >= 8:
            break
    if "#Shorts" not in marks and "#shorts" not in {item.lower() for item in marks}:
        marks.insert(0, "#Shorts")
    return " ".join(dict.fromkeys(marks))


def pick_description(text: str, title: str, source_title: str | None, tags: list[str]) -> str:
    context = extract_context(text, source_title, tags=tags)
    moment = tidy(str(context.get("moment") or ""))
    body: list[str] = []
    used = {title.lower().rstrip(".?!")}
    for sentence in sentences(text):
        key = sentence.lower().rstrip(".?!")
        if key in used:
            continue
        if not _usable_phrase(sentence) and moment not in sentence.lower():
            continue
        used.add(key)
        line = sentence if sentence.endswith(("?", "!")) else sentence.rstrip(".") + "."
        body.append(line)
        if len(body) >= 2:
            break
    if not body and moment:
        body.append(f"This clip is the {moment}.")
    lines = [title]
    if body:
        lines.extend(["", " ".join(body)])
    if useful_source_title(source_title) and tidy(source_title or "").lower() not in {title.lower()}:
        lines.extend(["", f"From: {tidy(source_title or '')}"])
    hash_line = hashtags(tags)
    if hash_line:
        lines.extend(["", hash_line])
    return "\n".join(lines).strip()


def stub_metadata(text: str) -> dict:
    preview = tidy(text).split(".")[0].strip()
    title = preview[:80] or "Untitled Short"
    return {
        "title": title,
        "titles": [title],
        "titleRanks": [],
        "description": "",
        "tags": [],
        "engine": "local",
    }


def local_metadata(text: str, source_title: str | None, duration: float, description: str = "") -> dict:
    del duration
    pitch = editor_pitch(description)
    tags = keyword_tags(text, source_title, description=pitch)
    titles, ranks = ranked_title_options(text, source_title, tags=tags, description=pitch)
    title = titles[0]
    return {
        "title": title,
        "titles": titles,
        "titleRanks": ranks,
        "description": tidy(description) if pitch else pick_description(text, title, source_title, tags),
        "tags": tags,
        "engine": "local",
    }


def _env_flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in {"1", "true", "yes", "on"}


def _http_json(url: str, payload: dict | None = None, headers: dict | None = None, timeout: float = 8.0):
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=body, method="GET" if body is None else "POST")
    request.add_header("Content-Type", "application/json")
    for key, value in (headers or {}).items():
        request.add_header(key, value)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def _studio_llm_settings() -> dict:
    path = Path(__file__).resolve().parent.parent / "data" / "studio-settings.json"
    try:
        packed = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return {}
    llm = packed.get("llm") if isinstance(packed, dict) else None
    return llm if isinstance(llm, dict) else {}


def _split_llm_models(raw: str) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for part in re.split(r"[,;\n]+", raw or ""):
        name = tidy(part)
        key = name.lower()
        if not name or key in seen:
            continue
        seen.add(key)
        out.append(name)
        if len(out) >= 6:
            break
    return out


def _match_installed_model(requested: str, names: list[str]) -> str | None:
    if requested in names:
        return requested
    stem = requested.split(":")[0]
    for name in names:
        if name == requested or name.startswith(requested + ":"):
            return name
        if ":" not in requested and name.split(":")[0] == stem:
            return name
    return None


@lru_cache(maxsize=1)
def llm_config() -> dict | None:
    if _env_flag("CUTLINE_LLM_OFF"):
        return None
    stored = _studio_llm_settings()
    env_key = (os.environ.get("CUTLINE_LLM_API_KEY") or os.environ.get("OPENAI_API_KEY") or "").strip()
    enabled = stored.get("enabled")
    if enabled is False and not env_key:
        return None
    key = env_key or str(stored.get("apiKey") or "").strip()
    base = (os.environ.get("CUTLINE_LLM_BASE_URL") or str(stored.get("baseUrl") or "")).strip().rstrip("/")
    model_raw = (
        os.environ.get("CUTLINE_LLM_MODELS")
        or os.environ.get("CUTLINE_LLM_MODEL")
        or str(stored.get("model") or "")
    ).strip()
    requested = _split_llm_models(model_raw)
    if key:
        models = requested or ["gpt-4o-mini"]
        return {
            "base": base or "https://api.openai.com/v1",
            "key": key,
            "model": models[0],
            "models": models,
        }
    if enabled is False:
        return None
    host = (os.environ.get("OLLAMA_HOST") or base or "http://127.0.0.1:11434").strip().rstrip("/")
    if host.endswith("/v1"):
        host = host[:-3]
    try:
        listing = _http_json(f"{host}/api/tags", timeout=0.6)
        names = [str(item.get("name")) for item in (listing.get("models") or []) if item.get("name")]
        if not names:
            return None
        matched: list[str] = []
        seen: set[str] = set()
        for item in requested:
            found = _match_installed_model(item, names)
            if found and found not in seen:
                seen.add(found)
                matched.append(found)
        models = matched or names[:1]
        return {"base": f"{host}/v1", "key": "ollama", "model": models[0], "models": models}
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError, ValueError):
        return None


def llm_available() -> bool:
    return llm_config() is not None


def _parse_llm_json(raw: str, context: dict | None = None) -> dict:
    text = tidy(raw)
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text, flags=re.IGNORECASE).strip()
        text = re.sub(r"```$", "", text).strip()
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("Model did not return JSON.")
    payload = json.loads(text[start : end + 1])
    titles_raw = payload.get("titles") or []
    if isinstance(titles_raw, str):
        titles_raw = [titles_raw]
    titles: list[str] = []
    seen: set[str] = set()
    for item in [payload.get("title"), *list(titles_raw)]:
        shaped = tidy(str(item or ""))
        shaped = EMOJI_RE.sub("", shaped)
        key = shaped.lower()
        if not shaped or key in seen:
            continue
        seen.add(key)
        titles.append(shaped)
        if len(titles) >= 6:
            break
    ranks = rank_titles(titles, context or {})
    pitch = tidy(str((context or {}).get("pitch") or ""))
    if pitch:
        by_title = {item["title"].lower(): item for item in ranks}
        ordered = []
        for item in titles:
            packed = by_title.get(item.lower())
            if packed:
                ordered.append(packed)
        ranks = ordered or ranks
        titles = [item["title"] for item in ranks[:4]]
    else:
        titles = [item["title"] for item in ranks[:4]]
    title = titles[0] if titles else tidy(str(payload.get("title") or ""))
    description = clean_dashes(str(payload.get("description") or "")).strip()
    tags_raw = payload.get("tags") or []
    if isinstance(tags_raw, str):
        tags = [tidy(part) for part in re.split(r"[,|\n]", tags_raw) if tidy(part)]
    else:
        tags = [tidy(str(item)) for item in tags_raw if tidy(str(item))]
    tags = [re.sub(r"^#", "", tag).lower() for tag in tags]
    transcript = tidy(str((context or {}).get("transcript") or ""))
    source_title = tidy(str((context or {}).get("source_title") or (context or {}).get("sourceTitle") or "")) or None
    if not tags:
        tags = keyword_tags(transcript, source_title, description=pitch)
    if not title:
        raise ValueError("Model JSON was missing title or description.")
    if not description:
        description = pick_description(transcript, title, source_title, tags)
    return {
        "title": title,
        "titles": titles or [title],
        "titleRanks": ranks[:4],
        "description": clean_dashes(description)[:1200],
        "tags": tags[:16],
        "engine": "llm",
    }


def _score_description(text: str, pitch: str) -> float:
    body = tidy(text)
    if not body:
        return -10.0
    score = 0.0
    n = len(body)
    if 80 <= n <= 500:
        score += 3.0
    elif n < 40:
        score -= 2.0
    if "#shorts" in body.lower():
        score += 1.5
    pitch_words = [word for word in tokens(pitch) if word not in FILLER and len(word) >= 4][:8]
    if pitch_words:
        hits = sum(1 for word in pitch_words if word in body.lower())
        score += hits * 0.6
    return score


def _merge_llm_packs(packs: list[dict], context: dict) -> dict:
    titles: list[str] = []
    seen: set[str] = set()
    descriptions: list[str] = []
    tags: list[str] = []
    tag_seen: set[str] = set()
    used: list[str] = []
    sources: dict[str, list[str]] = {}
    for pack in packs:
        model = tidy(str(pack.get("model") or ""))
        if model and model not in used:
            used.append(model)
        pack_map = pack.get("titleModels") if isinstance(pack.get("titleModels"), dict) else {}
        for item in pack.get("titles") or []:
            shaped = tidy(str(item or ""))
            key = shaped.lower()
            if not shaped:
                continue
            if key not in seen:
                seen.add(key)
                titles.append(shaped)
            for mid in list(pack_map.get(key) or ([model] if model else [])):
                mid = tidy(str(mid or ""))
                if mid and mid not in sources.setdefault(key, []):
                    sources[key].append(mid)
        description = clean_dashes(str(pack.get("description") or "")).strip()
        if description:
            descriptions.append(description)
        for tag in pack.get("tags") or []:
            name = re.sub(r"^#", "", tidy(str(tag))).lower()
            if not name or name in tag_seen:
                continue
            tag_seen.add(name)
            tags.append(name)
    ranks = rank_titles(titles, context)
    ordered = [item["title"] for item in ranks[:4]]
    title = ordered[0] if ordered else (titles[0] if titles else "")
    pitch = tidy(str(context.get("pitch") or ""))
    description = ""
    if descriptions:
        description = max(descriptions, key=lambda item: _score_description(item, pitch))
    if not tags:
        tags = keyword_tags(
            tidy(str(context.get("transcript") or "")),
            tidy(str(context.get("source_title") or "")) or None,
            description=pitch,
        )
    if not title:
        raise ValueError("Model JSON was missing title or description.")
    if not description:
        description = pick_description(
            tidy(str(context.get("transcript") or "")),
            title,
            tidy(str(context.get("source_title") or "")) or None,
            tags,
        )
    kept = {item.lower() for item in (ordered or ([title] if title else []))}
    title_models = {key: models for key, models in sources.items() if key in kept}
    return {
        "title": title,
        "titles": ordered or [title],
        "titleRanks": ranks[:4],
        "titleModels": title_models,
        "description": clean_dashes(description)[:1200],
        "tags": tags[:16],
        "engine": "llm",
        "model": "+".join(used),
    }


def _progress(**payload: object) -> None:
    sys.stderr.write("PROGRESS " + json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stderr.flush()


def llm_metadata(text: str, source_title: str | None, duration: float, description: str = "", social: str = "", models_limit: int | None = None) -> dict | None:
    config = llm_config()
    if not config:
        return None
    pitch = editor_pitch(description)
    context = extract_context(text, source_title, description=pitch)
    social_text = tidy(social)
    prompt = (
        "Write YouTube Shorts metadata for this clip. Return JSON only with keys "
        "titles, title, description, tags. "
        "If an editor description is present, that description is the video. "
        "Every title must be about that pitch. Do not fall back to random transcript filler. "
        "The transcript is only for wording and facts that support the pitch. "
        "Use the channel and post fields for names, @handles, game, first comments, "
        "and captions on YouTube, TikTok, and Instagram. Do not ignore those fields. "
        "titles: exactly 4 distinct options, 50-80 characters when possible (max 100), "
        "sentence case, no emojis, no wrapping quotes, no em dash. "
        "Do not invent facts the clip cannot pay off. "
        "Do not use #trending, #fyp, or #viral. "
        "title: copy of the strongest titles[0]. "
        "description: keep the editor pitch if present (you may tighten it), then a blank line, "
        "then 3-5 hashtags including #Shorts. Fold in the game name and handles when they fit. "
        "tags: 8-15 YouTube tags without #, from the pitch, game, and accounts first. "
        "Do not invent facts that are not in the transcript, editor description, post fields, or source title.\n\n"
        f"Source title: {source_title or '(none)'}\n"
        f"Editor description (THIS is the pitch. Titles must match it when present):\n{tidy(description)[:1500] or '(none)'}\n"
        f"Channel and post fields:\n{social_text[:2500] or '(none)'}\n"
        f"Clip moment: {tidy(str(context.get('moment') or '')) or '(none)'}\n"
        f"Clip keywords: {', '.join((context.get('keywords') or [])[:8]) or '(none)'}\n"
        f"Duration seconds: {round(float(duration or 0), 1)}\n"
        f"Transcript:\n{tidy(text)[:4000]}"
    )
    url = f"{config['base']}/chat/completions"
    messages = [
        {
            "role": "system",
            "content": (
                "You write YouTube Shorts titles, descriptions, and tags. "
                "If the editor provided a description, that is the topic. "
                "Use every channel and post field you are given, not speech captions alone. "
                "Write four titles about that pitch. Transcript filler is not the topic. "
                "50-80 characters, sentence case, no clickbait the clip cannot pay off. JSON only."
            ),
        },
        {"role": "user", "content": prompt},
    ]
    context_for_parse = dict(context)
    context_for_parse["transcript"] = tidy(text)
    context_for_parse["source_title"] = source_title or ""
    context_for_parse["pitch"] = pitch
    models = config.get("models") or [config["model"]]
    if models_limit is not None:
        models = list(models)[: max(1, int(models_limit))]
    packs: list[dict] = []
    _progress(step="start", total=len(models), models=list(models))
    for index, model in enumerate(models, start=1):
        _progress(step="model", index=index, total=len(models), model=str(model or "").strip())
        payload = {
            "model": model,
            "temperature": 0.4,
            "messages": messages,
        }
        try:
            data = _http_json(
                url,
                payload,
                headers={"Authorization": f"Bearer {config['key']}"},
                timeout=90.0,
            )
            content = (((data.get("choices") or [{}])[0].get("message") or {}).get("content")) or ""
            parsed = _parse_llm_json(str(content), context_for_parse)
            parsed["model"] = str(model or "").strip()
            if parsed.get("model"):
                parsed["titleModels"] = {
                    tidy(str(item)).lower(): [parsed["model"]]
                    for item in (parsed.get("titles") or [])
                    if tidy(str(item))
                }
            packs.append(parsed)
            _progress(step="model-done", index=index, total=len(models), model=str(model or "").strip(), ok=True)
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError, ValueError, KeyError):
            _progress(step="model-done", index=index, total=len(models), model=str(model or "").strip(), ok=False)
            continue
    if not packs:
        return None
    if len(packs) == 1:
        return packs[0]
    _progress(step="merge", total=len(models))
    try:
        return _merge_llm_packs(packs, context_for_parse)
    except ValueError:
        return packs[0]


def empty_metadata() -> dict:
    return {
        "title": "",
        "titles": [],
        "titleRanks": [],
        "description": "",
        "tags": [],
        "engine": "none",
    }


def social_from_look(style: dict | None) -> str:
    socials = style.get("socials") if isinstance(style, dict) else None
    if not isinstance(socials, dict):
        socials = {}
    lines: list[str] = []
    name = tidy(str(socials.get("name") or ""))
    if name:
        lines.append(f"Name: {name}")
    for key, label in (
        ("twitch", "Twitch"),
        ("youtube", "YouTube"),
        ("kick", "Kick"),
        ("instagram", "Instagram"),
        ("tiktok", "TikTok"),
    ):
        packed = socials.get(key) if isinstance(socials.get(key), dict) else {}
        handle = tidy(str((packed or {}).get("handle") or ""))
        if handle:
            lines.append(f"{label}: {handle}")
    for badge in socials.get("custom") or []:
        if not isinstance(badge, dict):
            continue
        label = tidy(str(badge.get("label") or ""))
        if label:
            lines.append(f"Badge: {label}")
    packed = {}
    path = Path(__file__).resolve().parent.parent / "data" / "studio-settings.json"
    try:
        packed = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        packed = {}
    youtube = packed.get("youtube") if isinstance(packed.get("youtube"), dict) else {}
    instagram = packed.get("instagramUpload") if isinstance(packed.get("instagramUpload"), dict) else {}
    game = tidy(str(youtube.get("gameTitle") or ""))
    if game:
        lines.append(f"Game: {game}")
    comment = tidy(str(youtube.get("firstComment") or ""))
    if comment:
        lines.append(f"YouTube first comment: {comment}")
    ig_comment = tidy(str(instagram.get("firstComment") or ""))
    if ig_comment:
        lines.append(f"Instagram first comment: {ig_comment}")
    collab = tidy(str(instagram.get("collaborators") or ""))
    if collab:
        lines.append(f"Instagram collaborators: {collab}")
    return "\n".join(lines)


def suggest_metadata(
    text: str,
    source_title: str | None = None,
    duration: float = 0.0,
    use_llm: bool = False,
    description: str = "",
    social: str = "",
    models_limit: int | None = None,
) -> dict:
    if not use_llm:
        return empty_metadata()
    if not llm_config():
        raise RuntimeError(
            "Set AI credentials in Settings first. Use Ollama on this machine, or an API key."
        )
    upgraded = llm_metadata(
        text,
        source_title,
        duration,
        description=description,
        social=social,
        models_limit=models_limit,
    )
    return upgraded or empty_metadata()


def attach_suggestions(
    clip: dict,
    text: str,
    source_title: str | None = None,
    use_llm: bool = False,
    style: dict | None = None,
    social: str = "",
    models_limit: int | None = None,
) -> dict:
    """Fill title fields on this window. Extra models add title options, not extra clips."""
    item = dict(clip)
    if not use_llm:
        return item
    start = float(item.get("start") or 0)
    end = float(item.get("end") or start)
    duration = float(item.get("duration") or (end - start))
    brief = tidy(social) or social_from_look(style)
    meta = suggest_metadata(
        text,
        source_title=source_title,
        duration=duration,
        use_llm=True,
        social=brief,
        models_limit=models_limit,
    )
    if meta.get("engine") != "llm" or not str(meta.get("title") or "").strip():
        return item
    item["title"] = meta["title"]
    item["suggestedTitle"] = meta["title"]
    item["suggestedTitles"] = meta.get("titles") or [meta["title"]]
    item["titleRanks"] = meta.get("titleRanks") or []
    item["titleModels"] = meta.get("titleModels") or {}
    item["suggestedDescription"] = meta["description"]
    item["suggestedTags"] = meta["tags"]
    item["suggestEngine"] = "llm"
    model = str(meta.get("model") or "").strip()
    if model:
        item["suggestModel"] = model
    else:
        item.pop("suggestModel", None)
    return item


def main() -> int:
    raw = sys.stdin.read()
    payload = json.loads(raw or "{}")
    if str(payload.get("mode") or "") == "rank":
        context = extract_context(
            str(payload.get("text") or ""),
            source_title=payload.get("sourceTitle"),
            tags=payload.get("tags") or [],
            description=str(payload.get("description") or ""),
        )
        titles = payload.get("titles") or []
        if isinstance(titles, str):
            titles = [titles]
        if payload.get("title") and not titles:
            titles = [payload.get("title")]
        ranked = rank_titles([str(item) for item in titles], context)
        if len(ranked) == 1:
            sys.stdout.write(json.dumps(ranked[0]))
        else:
            sys.stdout.write(json.dumps({"ranks": ranked}))
        return 0
    result = suggest_metadata(
        str(payload.get("text") or ""),
        source_title=payload.get("sourceTitle"),
        duration=float(payload.get("duration") or 0),
        use_llm=bool(payload.get("useLlm")),
        description=str(payload.get("description") or ""),
        social=str(payload.get("social") or ""),
    )
    sys.stdout.write(json.dumps(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
