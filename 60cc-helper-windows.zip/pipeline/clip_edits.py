"""Jump cuts, speed, slow-mo, and hold sections for a Short window."""

from __future__ import annotations

MIN_EDIT_SECONDS = 0.4
MIN_HOLD_SECONDS = 0.2
MIN_OUTPUT_SECONDS = 1.0
MAX_OUTPUT_SECONDS = 180.0
MAX_SOURCE_SECONDS = 180.0
MIN_FX_SECONDS = 0.05
MAX_FX_SECONDS = 3.0
_SPEED_RATES = (0.5, 0.75, 1.5, 2.0)


def _round_ms(value: float) -> float:
    return round(value * 1000) / 1000


def _speed_rate(raw: object) -> float:
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return 1.5
    return min(_SPEED_RATES, key=lambda item: abs(item - value))


def _as_spans(raw: object) -> list[dict]:
    if not isinstance(raw, list):
        return []
    spans: list[dict] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        try:
            start = float(item.get("start"))
            end = float(item.get("end"))
        except (TypeError, ValueError):
            continue
        if end - start < MIN_EDIT_SECONDS:
            continue
        span = {
            "id": str(item.get("id") or f"e{len(spans)+1}"),
            "start": _round_ms(start),
            "end": _round_ms(end),
        }
        rate = item.get("rate")
        if rate is not None:
            span["rate"] = _speed_rate(rate)
        fx = str(item.get("fx") or "")
        if fx in {"fade", "flash", "wipe", "slide", "blur", "zoom"}:
            span["fx"] = fx
        for key in ("fxIn", "fxOut"):
            try:
                time = float(item.get(key))
            except (TypeError, ValueError):
                continue
            if time == time:
                span[key] = min(MAX_FX_SECONDS, max(MIN_FX_SECONDS, round(time * 1000) / 1000))
        spans.append(span)
    return spans


def _as_holds(raw: object) -> list[dict]:
    if not isinstance(raw, list):
        return []
    holds: list[dict] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        try:
            at = float(item.get("at"))
            duration = float(item.get("duration"))
        except (TypeError, ValueError):
            continue
        if duration < MIN_HOLD_SECONDS:
            continue
        holds.append(
            {
                "id": str(item.get("id") or f"h{len(holds)+1}"),
                "at": _round_ms(at),
                "duration": _round_ms(duration),
            }
        )
        fx = str(item.get("fx") or "")
        if fx in {"fade", "flash", "wipe", "slide", "blur", "zoom"}:
            holds[-1]["fx"] = fx
        for key in ("fxIn", "fxOut"):
            try:
                time = float(item.get(key))
            except (TypeError, ValueError):
                continue
            if time == time:
                holds[-1][key] = min(MAX_FX_SECONDS, max(MIN_FX_SECONDS, round(time * 1000) / 1000))
    holds.sort(key=lambda item: item["at"])
    return holds


def _clip_span(span: dict, start: float, end: float) -> dict | None:
    a = max(start, min(span["start"], span["end"]))
    b = min(end, max(span["start"], span["end"]))
    if b - a < MIN_EDIT_SECONDS:
        return None
    next_span = dict(span)
    next_span["start"] = _round_ms(a)
    next_span["end"] = _round_ms(b)
    return next_span


def _merge_cuts(spans: list[dict]) -> list[dict]:
    ordered = sorted(spans, key=lambda item: item["start"])
    out: list[dict] = []
    for span in ordered:
        if out and span["start"] <= out[-1]["end"] + 0.05:
            out[-1]["end"] = max(out[-1]["end"], span["end"])
            continue
        out.append(dict(span))
    return out


def _in_cut(at: float, cuts: list[dict]) -> bool:
    return any(cut["start"] <= at < cut["end"] for cut in cuts)


def _insert_holds(pieces: list[dict], holds: list[dict], cuts: list[dict]) -> list[dict]:
    out = pieces
    for hold in holds:
        at = float(hold["at"])
        duration = float(hold["duration"])
        if _in_cut(at, cuts):
            continue
        next_pieces: list[dict] = []
        placed = False
        for piece in out:
            if placed or float(piece.get("freeze") or 0) > 0:
                next_pieces.append(piece)
                continue
            start = float(piece["start"])
            end = float(piece["end"])
            if at < start - 0.001:
                next_pieces.append(
                    {"start": _round_ms(at), "end": _round_ms(at), "rate": 1.0, "freeze": duration}
                )
                next_pieces.append(piece)
                placed = True
                continue
            if at >= end - 0.001:
                next_pieces.append(piece)
                continue
            if at - start >= 0.04:
                split = dict(piece)
                split["end"] = _round_ms(at)
                next_pieces.append(split)
            next_pieces.append(
                {"start": _round_ms(at), "end": _round_ms(at), "rate": 1.0, "freeze": duration}
            )
            if end - at >= 0.04:
                rest = dict(piece)
                rest["start"] = _round_ms(at)
                next_pieces.append(rest)
            placed = True
        if not placed:
            next_pieces.append(
                {"start": _round_ms(at), "end": _round_ms(at), "rate": 1.0, "freeze": duration}
            )
        out = next_pieces
    return out


def clip_pieces(clip: dict) -> list[dict]:
    start = float(clip.get("start") or 0)
    end = float(clip.get("end") or start)
    window_start, window_end = min(start, end), max(start, end)
    cuts = []
    for span in _as_spans(clip.get("cuts")):
        clipped = _clip_span(span, window_start, window_end)
        if clipped:
            cuts.append(clipped)
    cuts = _merge_cuts(cuts)

    kept: list[tuple[float, float]] = []
    cursor = window_start
    for cut in cuts:
        if cut["start"] > cursor + 0.04:
            kept.append((cursor, cut["start"]))
        cursor = max(cursor, cut["end"])
    if window_end > cursor + 0.04:
        kept.append((cursor, window_end))

    speeds = []
    for span in _as_spans(clip.get("speeds")):
        clipped = _clip_span(span, window_start, window_end)
        if clipped:
            speeds.append(clipped)
    speeds.sort(key=lambda item: item["start"])

    pieces: list[dict] = []
    for seg_start, seg_end in kept:
        marks = {seg_start, seg_end}
        for speed in speeds:
            if speed["end"] <= seg_start or speed["start"] >= seg_end:
                continue
            marks.add(max(seg_start, speed["start"]))
            marks.add(min(seg_end, speed["end"]))
        times = sorted(marks)
        for index in range(len(times) - 1):
            from_t, to_t = times[index], times[index + 1]
            if to_t - from_t < 0.04:
                continue
            mid = (from_t + to_t) / 2
            rate = 1.0
            for speed in speeds:
                if speed["start"] <= mid < speed["end"]:
                    rate = float(speed.get("rate") or 1.5)
            pieces.append({"start": _round_ms(from_t), "end": _round_ms(to_t), "rate": rate})
    holds = [
        hold
        for hold in _as_holds(clip.get("holds"))
        if window_start - 0.02 <= hold["at"] <= window_end + 0.02
    ]
    pieces = _insert_holds(pieces, holds, cuts)
    return _stamp_join_fx(pieces, cuts, speeds, holds, clip)


def _item_fx(item: dict | None, fallback: str = "cut") -> str:
    raw = str((item or {}).get("fx") or fallback or "cut")
    return raw if raw in {"cut", "fade", "flash", "wipe", "slide", "blur", "zoom"} else "cut"


def _fx_time(item: dict | None, key: str, fx: str) -> float:
    if fx == "flash":
        default = 0.2
    elif fx in {"wipe", "slide", "blur", "zoom"}:
        default = 0.5
    else:
        default = 0.4
    if not isinstance(item, dict):
        return default
    try:
        value = float(item.get(key))
    except (TypeError, ValueError):
        value = default
    if value != value:
        value = default
    return min(MAX_FX_SECONDS, max(MIN_FX_SECONDS, value))


def _stamp_join_fx(
    pieces: list[dict],
    cuts: list[dict],
    speeds: list[dict],
    holds: list[dict],
    clip: dict,
) -> list[dict]:
    fallback = str(clip.get("editFx") or "cut")
    if fallback not in {"cut", "fade", "flash", "wipe", "slide", "blur", "zoom"}:
        fallback = "cut"
    stamped: list[dict] = []
    for index, piece in enumerate(pieces):
        next_piece = dict(piece)
        if index == 0:
            next_piece["joinFx"] = "cut"
            stamped.append(next_piece)
            continue
        prev = pieces[index - 1]
        source: dict | None = None
        side = "fxIn"
        if float(piece.get("freeze") or 0) > 0:
            source = next((item for item in holds if abs(float(item["at"]) - float(piece["start"])) < 0.04), None)
            side = "fxIn"
        elif float(prev.get("freeze") or 0) > 0:
            source = next((item for item in holds if abs(float(item["at"]) - float(prev["start"])) < 0.04), None)
            side = "fxOut"
        elif float(piece["start"]) - float(prev["end"]) > 0.03:
            source = next(
                (
                    item
                    for item in cuts
                    if item["start"] >= float(prev["end"]) - 0.05 and item["end"] <= float(piece["start"]) + 0.05
                ),
                None,
            ) or next(
                (item for item in cuts if abs(float(item["end"]) - float(piece["start"])) < 0.05),
                None,
            )
            side = "fxIn"
        elif abs(float(piece.get("rate") or 1) - float(prev.get("rate") or 1)) > 0.01:
            incoming = next(
                (
                    item
                    for item in speeds
                    if float(piece["start"]) >= float(item["start"]) - 0.02 and float(piece["start"]) < float(item["end"])
                ),
                None,
            )
            outgoing = next(
                (
                    item
                    for item in speeds
                    if float(prev["end"]) > float(item["start"]) and float(prev["end"]) <= float(item["end"]) + 0.02
                ),
                None,
            )
            if incoming and abs(float(incoming.get("rate") or 1) - float(prev.get("rate") or 1)) > 0.01:
                source = incoming
                side = "fxIn"
            elif outgoing and abs(float(outgoing.get("rate") or 1) - float(piece.get("rate") or 1)) > 0.01:
                source = outgoing
                side = "fxOut"
            else:
                source = incoming or outgoing
                side = "fxIn"
        fx = _item_fx(source, fallback)
        next_piece["joinFx"] = fx
        if fx in {"fade", "flash", "wipe", "slide", "blur", "zoom"}:
            time = _fx_time(source, side, fx)
            next_piece["joinFxIn"] = time
            next_piece["joinFxOut"] = time
        stamped.append(next_piece)
    return stamped


def output_duration(pieces: list[dict]) -> float:
    total = 0.0
    for piece in pieces:
        freeze = float(piece.get("freeze") or 0)
        if freeze > 0:
            total += freeze
            continue
        rate = float(piece.get("rate") or 1) or 1
        total += (float(piece["end"]) - float(piece["start"])) / rate
    return _round_ms(total)


def source_to_output(time: float, pieces: list[dict]) -> float:
    out = 0.0
    for piece in pieces:
        freeze = float(piece.get("freeze") or 0)
        start = float(piece["start"])
        end = float(piece["end"])
        rate = float(piece.get("rate") or 1) or 1
        if freeze > 0:
            if time <= start:
                return _round_ms(out)
            out += freeze
            continue
        if time <= start:
            return _round_ms(out)
        if time < end:
            return _round_ms(out + (time - start) / rate)
        out += (end - start) / rate
    return _round_ms(out)


def remap_caption_cues(captions: object, pieces: list[dict], duration: float) -> list[dict]:
    if not isinstance(captions, list):
        return []
    cues: list[dict] = []
    limit = max(0.0, float(duration or 0))
    for item in captions:
        if not isinstance(item, dict):
            continue
        text = " ".join(str(item.get("text") or "").split())
        if not text:
            continue
        try:
            start = float(item.get("start"))
            end = float(item.get("end"))
        except (TypeError, ValueError):
            continue
        if end <= start:
            continue
        t0 = source_to_output(start, pieces)
        t1 = source_to_output(end, pieces)
        if t1 <= t0 + 0.04:
            continue
        t1 = min(limit, max(t0 + 0.05, t1))
        speaker = item.get("speaker")
        if speaker is None:
            speaker = ""
        else:
            speaker = str(speaker).strip()
            if speaker.lower() in {"none", "off"} or speaker == "0":
                speaker = ""
        tokens = text.split()
        words: list[dict] = []
        span = max(0.02, end - start)
        for index, token in enumerate(tokens):
            src0 = start + span * index / len(tokens)
            src1 = start + span * (index + 1) / len(tokens)
            w0 = source_to_output(src0, pieces)
            w1 = max(w0 + 0.02, source_to_output(src1, pieces))
            words.append(
                {
                    "start": _round_ms(w0),
                    "end": _round_ms(min(t1, w1)),
                    "word": token,
                    "speaker": speaker,
                }
            )
        cues.append(
            {
                "start": _round_ms(t0),
                "end": _round_ms(t1),
                "text": text,
                "speaker": speaker,
                "words": words,
            }
        )
    return cues


def remap_words(words: list[dict], pieces: list[dict]) -> list[dict]:
    mapped: list[dict] = []
    for word in words:
        try:
            word_start = float(word["start"])
            word_end = float(word["end"])
        except (KeyError, TypeError, ValueError):
            continue
        for piece in pieces:
            if float(piece.get("freeze") or 0) > 0:
                continue
            start = max(word_start, float(piece["start"]))
            end = min(word_end, float(piece["end"]))
            if end - start < 0.02:
                continue
            mapped.append(
                {
                    **word,
                    "start": source_to_output(start, pieces),
                    "end": max(
                        source_to_output(start, pieces) + 0.02,
                        source_to_output(end, pieces),
                    ),
                }
            )
    return mapped


def captions_as_words(captions: object) -> list[dict]:
    if not isinstance(captions, list):
        return []
    words: list[dict] = []
    for item in captions:
        if not isinstance(item, dict):
            continue
        text = " ".join(str(item.get("text") or "").split())
        if not text:
            continue
        try:
            start = float(item.get("start"))
            end = float(item.get("end"))
        except (TypeError, ValueError):
            continue
        if end <= start:
            continue
        speaker = item.get("speaker")
        if speaker is None:
            speaker = ""
        else:
            speaker = str(speaker).strip()
            if speaker.lower() in {"none", "off"} or speaker == "0":
                speaker = ""
        tokens = text.split()
        for index, token in enumerate(tokens):
            t0 = start + (end - start) * index / len(tokens)
            t1 = start + (end - start) * (index + 1) / len(tokens)
            words.append(
                {
                    "start": _round_ms(t0),
                    "end": _round_ms(max(t1, t0 + 0.02)),
                    "word": token,
                    "speaker": speaker,
                }
            )
    return words


def saved_caption_words(clip: dict, transcript: dict) -> list[dict]:
    captions = clip.get("captions") if isinstance(clip, dict) and "captions" in clip else None
    if isinstance(captions, list) and len(captions) > 0:
        return captions_as_words(captions)
    return transcript.get("words") or []


def simple_render(pieces: list[dict]) -> bool:
    if len(pieces) != 1:
        return False
    piece = pieces[0]
    if float(piece.get("freeze") or 0) > 0.01:
        return False
    return abs(float(piece.get("rate") or 1) - 1) < 0.01


def _piece_out_dur(piece: dict) -> float:
    freeze = float(piece.get("freeze") or 0)
    if freeze > 0.01:
        return freeze
    rate = float(piece.get("rate") or 1) or 1
    return max(0.05, (float(piece["end"]) - float(piece["start"])) / rate)


def _join_kind(piece: dict) -> str:
    raw = str(piece.get("joinFx") or "cut")
    return raw if raw in {"cut", "fade", "flash", "wipe", "slide", "blur", "zoom"} else "cut"


_XFADE = {
    "fade": "fade",
    "flash": "fadewhite",
    "wipe": "wipeleft",
    "slide": "slideleft",
    "blur": "hblur",
    "zoom": "zoomin",
}


def _join_overlap(piece: dict, prev_dur: float, this_dur: float, chain_dur: float) -> float:
    kind = _join_kind(piece)
    if kind == "cut":
        return 0.0
    time = _fx_time(piece, "joinFxIn", kind)
    cap = min(prev_dur, this_dur, chain_dur) * 0.8
    return min(time, max(0.05, cap))


def build_edit_filter(
    pieces: list[dict],
    vf: str,
    has_audio: bool = True,
    edit_fx: str = "cut",
) -> tuple[str, list[str]]:
    parts: list[str] = []
    count = len(pieces)
    for index, piece in enumerate(pieces):
        freeze = float(piece.get("freeze") or 0)
        rate = float(piece.get("rate") or 1) or 1
        if freeze > 0:
            parts.append(
                f"[{index}:v]trim=duration=0.05,setpts=PTS-STARTPTS,"
                f"tpad=stop_mode=clone:stop_duration={freeze:.3f},"
                f"trim=duration={freeze:.3f},setpts=PTS-STARTPTS[v{index}]"
            )
            if has_audio:
                parts.append(
                    f"[{index}:a]volume=0,atrim=0:0.05,asetpts=PTS-STARTPTS,"
                    f"apad=whole_dur={freeze:.3f},atrim=0:{freeze:.3f},asetpts=PTS-STARTPTS[a{index}]"
                )
            continue
        video = f"[{index}:v]setpts=PTS-STARTPTS"
        if abs(rate - 1) >= 0.01:
            video += f",setpts={1 / rate:.6f}*PTS"
        video += f"[v{index}]"
        parts.append(video)
        if has_audio:
            audio = f"[{index}:a]asetpts=PTS-STARTPTS"
            if abs(rate - 1) >= 0.01:
                audio += f",atempo={rate:g}"
            audio += f"[a{index}]"
            parts.append(audio)
    v_cur = "v0"
    a_cur = "a0"
    acc = _piece_out_dur(pieces[0])
    prev_dur = acc
    for index in range(1, count):
        this_dur = _piece_out_dur(pieces[index])
        kind = _join_kind(pieces[index])
        overlap = _join_overlap(pieces[index], prev_dur, this_dur, acc)
        if kind == "cut" or overlap < 0.04 or kind not in _XFADE:
            parts.append(f"[{v_cur}][v{index}]concat=n=2:v=1:a=0[vx{index}]")
            if has_audio:
                parts.append(f"[{a_cur}][a{index}]concat=n=2:v=0:a=1[ax{index}]")
            acc += this_dur
        else:
            trans = _XFADE[kind]
            offset = max(0.0, acc - overlap)
            parts.append(
                f"[{v_cur}][v{index}]xfade=transition={trans}:duration={overlap:.3f}:offset={offset:.3f}[vx{index}]"
            )
            if has_audio:
                parts.append(f"[{a_cur}][a{index}]acrossfade=d={overlap:.3f}:c1=tri:c2=tri[ax{index}]")
            acc = acc + this_dur - overlap
        v_cur = f"vx{index}"
        a_cur = f"ax{index}"
        prev_dur = this_dur
    graph_vf = ";" in vf or "[vout]" in vf
    if has_audio:
        if graph_vf:
            body = vf if vf.lstrip().startswith(f"[{v_cur}]") else f"[{v_cur}]{vf}"
            if not body.endswith("[vout]"):
                body = f"{body}[vout]"
            parts.append(body)
        else:
            parts.append(f"[{v_cur}]{vf}[vout]")
        maps = ["-map", "[vout]", "-map", f"[{a_cur}]"]
    else:
        if graph_vf:
            body = vf if vf.lstrip().startswith(f"[{v_cur}]") else f"[{v_cur}]{vf}"
            if not body.endswith("[vout]"):
                body = f"{body}[vout]"
            parts.append(body)
        else:
            parts.append(f"[{v_cur}]{vf}[vout]")
        maps = ["-map", "[vout]"]
    return ";".join(parts), maps
