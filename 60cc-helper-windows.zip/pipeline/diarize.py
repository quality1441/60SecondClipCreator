"""Map pyannote speaker turns onto existing Whisper words.

Captions stay on faster-whisper timestamps. Voice 1-4 come from overlapping
diarization turns, not loudness. Missing models or a missing access key skip
labeling instead of failing the job.
"""

from __future__ import annotations

import os
from pathlib import Path

VOICE_IDS = ("Voice1", "Voice2", "Voice3", "Voice4")
DIARIZE_METHOD = "overlap"
_MODELS = (
    "pyannote/speaker-diarization-3.1",
    "pyannote/speaker-diarization-community-1",
)
_PIPELINE = None
_PIPELINE_FAILED = False


def _plain_words(words: list[dict]) -> list[dict]:
    out: list[dict] = []
    for word in words:
        item = dict(word)
        item.pop("speaker", None)
        out.append(item)
    return out


def _hf_token() -> str:
    return (
        os.environ.get("CUTLINE_HF_TOKEN")
        or os.environ.get("HF_TOKEN")
        or os.environ.get("HUGGING_FACE_HUB_TOKEN")
        or ""
    ).strip()


def _load_pipeline():
    global _PIPELINE, _PIPELINE_FAILED
    if _PIPELINE is not None:
        return _PIPELINE
    if _PIPELINE_FAILED:
        return None
    try:
        from pyannote.audio import Pipeline
    except Exception as exc:
        print(f"voice labels skipped: pyannote.audio is not installed ({exc})", flush=True)
        _PIPELINE_FAILED = True
        return None
    token = _hf_token() or None
    last_error = ""
    for name in _MODELS:
        try:
            try:
                pipe = Pipeline.from_pretrained(name, token=token)
            except TypeError:
                pipe = Pipeline.from_pretrained(name, use_auth_token=token)
            try:
                import torch

                if torch.cuda.is_available():
                    pipe.to(torch.device("cuda"))
            except Exception:
                pass
            _PIPELINE = pipe
            print(f"voice labels: loaded {name}", flush=True)
            return pipe
        except Exception as exc:
            last_error = str(exc)
            continue
    print(f"voice labels skipped: {last_error or 'speaker models could not load'}", flush=True)
    _PIPELINE_FAILED = True
    return None


def _diarize_turns(wav_path: Path, max_speakers: int) -> list[dict]:
    pipe = _load_pipeline()
    if pipe is None:
        return []
    cap = min(4, max(1, int(max_speakers or 4)))
    kwargs: dict = {}
    if cap >= 2:
        kwargs["min_speakers"] = 1
        kwargs["max_speakers"] = cap
    try:
        try:
            annotation = pipe(str(wav_path), **kwargs)
        except TypeError:
            annotation = pipe(str(wav_path))
    except Exception as exc:
        print(f"voice labels skipped: {exc}", flush=True)
        return []
    if hasattr(annotation, "speaker_diarization"):
        annotation = annotation.speaker_diarization
    turns: list[dict] = []
    try:
        tracks = annotation.itertracks(yield_label=True)
    except Exception as exc:
        print(f"voice labels skipped: {exc}", flush=True)
        return []
    for turn, _track, speaker in tracks:
        start = float(getattr(turn, "start", 0.0) or 0.0)
        end = float(getattr(turn, "end", 0.0) or 0.0)
        if end <= start:
            continue
        turns.append({"start": start, "end": end, "speaker": str(speaker)})
    return turns


def _voice_map(turns: list[dict]) -> dict[str, str]:
    order: list[str] = []
    seen: set[str] = set()
    for turn in sorted(turns, key=lambda item: item["start"]):
        name = turn["speaker"]
        if name in seen:
            continue
        seen.add(name)
        order.append(name)
        if len(order) >= len(VOICE_IDS):
            break
    mapped = {name: VOICE_IDS[index] for index, name in enumerate(order)}
    fallback = order[-1] if order else ""
    last_voice = mapped.get(fallback, "Voice1")
    for turn in turns:
        mapped.setdefault(turn["speaker"], last_voice)
    return mapped


def _best_raw_speaker(start: float, end: float, turns: list[dict]) -> str | None:
    best = None
    best_ov = 0.0
    for turn in turns:
        overlap = min(end, turn["end"]) - max(start, turn["start"])
        if overlap > best_ov:
            best_ov = overlap
            best = turn["speaker"]
    if best is not None and best_ov > 0.02:
        return best
    mid = (start + end) * 0.5
    for turn in turns:
        if turn["start"] <= mid < turn["end"]:
            return turn["speaker"]
    return None


def assign_speakers(wav_path: Path, words: list[dict], max_speakers: int = 4) -> list[dict]:
    if not words:
        return words
    if not wav_path.is_file():
        return _plain_words(words)
    turns = _diarize_turns(wav_path, max_speakers)
    if not turns:
        return _plain_words(words)
    voice_for = _voice_map(turns)
    labeled: list[dict] = []
    for word in words:
        item = dict(word)
        raw = _best_raw_speaker(float(word["start"]), float(word["end"]), turns)
        if raw:
            item["speaker"] = voice_for.get(raw, "Voice1")
        else:
            item.pop("speaker", None)
        labeled.append(item)
    return labeled


def stamp_segments(segments: list[dict], words: list[dict]) -> list[dict]:
    stamped = []
    for seg in segments:
        counts: dict[str, int] = {}
        for word in words:
            if word["end"] > seg["start"] and word["start"] < seg["end"]:
                key = str(word.get("speaker") or "").strip()
                if key:
                    counts[key] = counts.get(key, 0) + 1
        item = dict(seg)
        if counts:
            item["speaker"] = max(counts.items(), key=lambda row: row[1])[0]
        else:
            item.pop("speaker", None)
        stamped.append(item)
    return stamped


def unique_voices(words: list[dict]) -> list[str]:
    seen: list[str] = []
    for word in words:
        key = str(word.get("speaker") or "").strip()
        if key in VOICE_IDS and key not in seen:
            seen.append(key)
    return seen
