#!/usr/bin/env python3
"""Stitch already-encoded clip files into one montage MP4 with optional layers."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

from captions import escape_ass, fmt_ass_time, _social_events, _social_styles

TIME_RE = re.compile(r"time=(\d+):(\d+):(\d+(?:\.\d+)?)")

MONTAGE_FONT = "Liberation Sans"
TEXT_BASE = {"small": 58, "medium": 84, "large": 116}
TEXT_ALIGN = {"top": 8, "middle": 5, "lower": 2}
TEXT_Y = {"top": 0.12, "middle": 0.5, "lower": 0.87}
TEXT_COLOR = "&H00FFFFFF"
TEXT_OUTLINE = "&H00101418"
STYLE_FORMAT = (
    "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, "
    "Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, "
    "MarginL, MarginR, MarginV, Encoding"
)


def load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def patch_montage(dir_path: Path, **fields: object) -> None:
    file = dir_path / "montage.json"
    row = load_json(file)
    row.update(fields)
    row["updatedAt"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    save_json(file, row)


def fail(dir_path: Path, message: str) -> int:
    patch_montage(dir_path, stage="error", error=message, message=None, progress=0)
    print(message, file=sys.stderr)
    return 1


def resolve_font_dir() -> Path:
    repo = Path(__file__).resolve().parents[1] / "fonts"
    if any(repo.glob("*.ttf")):
        return repo
    linux = Path("/usr/share/fonts/truetype/liberation")
    if linux.is_dir():
        return linux
    truetype = Path("/usr/share/fonts/truetype")
    if truetype.is_dir():
        return truetype
    windir = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
    if windir.is_dir():
        return windir
    return repo


FONT_DIR = resolve_font_dir()


def run_ffprobe(path: str) -> dict:
    try:
        raw = subprocess.check_output(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-show_entries",
                "stream=codec_type,codec_name,width,height",
                "-of",
                "json",
                path,
            ],
            stderr=subprocess.STDOUT,
        )
        return json.loads(raw.decode("utf-8", errors="replace"))
    except Exception:
        return {}


def duration_of(path: str) -> float:
    packed = run_ffprobe(path)
    try:
        return max(0.0, float((packed.get("format") or {}).get("duration") or 0))
    except (TypeError, ValueError):
        return 0.0


def has_audio(path: str) -> bool:
    packed = run_ffprobe(path)
    for stream in packed.get("streams") or []:
        if stream.get("codec_type") == "audio":
            return True
    return False


def video_size(path: str) -> tuple[int, int]:
    packed = run_ffprobe(path)
    for stream in packed.get("streams") or []:
        if stream.get("codec_type") == "video":
            w = int(stream.get("width") or 0)
            h = int(stream.get("height") or 0)
            if w > 0 and h > 0:
                return w, h
    return 1080, 1920


def parse_time(line: str) -> float | None:
    match = TIME_RE.search(line)
    if not match:
        return None
    hours, minutes, seconds = match.groups()
    return int(hours) * 3600 + int(minutes) * 60 + float(seconds)


def run_ffmpeg(args: list[str], dir_path: Path, total: float) -> int:
    proc = subprocess.Popen(
        ["ffmpeg", "-hide_banner", "-y", *args],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    last = 0.0
    tail: list[str] = []
    assert proc.stderr is not None
    for line in proc.stderr:
        at = parse_time(line)
        if at is None:
            if line.strip():
                tail.append(line.rstrip())
                if len(tail) > 12:
                    tail.pop(0)
            continue
        if total > 0:
            pct = min(96, max(8, round(8 + 88 * (at / total))))
            if at - last >= 0.4:
                last = at
                patch_montage(dir_path, progress=pct, message="Making the montage.")
    code = proc.wait()
    if code != 0:
        for line in tail:
            print(line, file=sys.stderr)
    return code


def concat_copy(files: list[str], output: Path, list_path: Path) -> int:
    lines = ["ffconcat version 1.0"]
    for item in files:
        escaped = item.replace("\\", "/").replace("'", r"'\''")
        lines.append(f"file '{escaped}'")
    list_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    proc = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(list_path),
            "-c",
            "copy",
            str(output),
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return proc.returncode


def entry_hold(entry: dict) -> float:
    if entry.get("kind") in ("image", "title"):
        try:
            return max(0.4, float(entry.get("hold") or 3.0))
        except (TypeError, ValueError):
            return 3.0
    return max(duration_of(str(entry["path"])), 0.1)


def append_inputs(args: list[str], entry: dict, size: tuple[int, int]) -> None:
    kind = entry.get("kind")
    dur = entry.get("hold", 3.0)
    if kind == "title":
        args.extend(["-f", "lavfi", "-i", f"color=c=black:s={size[0]}x{size[1]}:r=30:d={dur:.3f}"])
    elif kind == "image":
        args.extend(["-loop", "1", "-t", f"{dur:.3f}", "-i", str(entry["path"])])
    else:
        args.extend(["-i", str(entry["path"])])


def scale_video_filter(index: int, size: tuple[int, int]) -> str:
    width, height = size
    return (
        f"[{index}:v]scale={width}:{height}:force_original_aspect_ratio=decrease,"
        f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,fps=30,setsar=1,format=yuv420p"
    )


def concat_reencode(entries: list[dict], output: Path, dir_path: Path, total: float, size: tuple[int, int], subs: str | None) -> int:
    args: list[str] = []
    filters: list[str] = []
    concat_parts: list[str] = []
    for index, entry in enumerate(entries):
        append_inputs(args, entry, size)
        dur = entry_hold(entry)
        filters.append(f"{scale_video_filter(index, size)},setpts=PTS-STARTPTS[v{index}]")
        if entry.get("kind") not in ("image", "title") and has_audio(str(entry["path"])):
            filters.append(
                f"[{index}:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo,"
                f"asetpts=PTS-STARTPTS[a{index}]"
            )
        else:
            filters.append(
                f"anullsrc=r=48000:cl=stereo,atrim=0:{dur:.3f},"
                f"aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo[a{index}]"
            )
        concat_parts.append(f"[v{index}][a{index}]")
    filters.append(f"{''.join(concat_parts)}concat=n={len(entries)}:v=1:a=1[v][a]")
    v_label = "[v]"
    if subs:
        filters.append(f"[v]{subs}[vsub]")
        v_label = "[vsub]"
    args.extend(
        [
            "-filter_complex",
            ";".join(filters),
            "-map",
            v_label,
            "-map",
            "[a]",
            "-c:v",
            "libx264",
            "-preset",
            "slow",
            "-crf",
            "17",
            # The libass burn-in negotiates the link up to yuv444p, which wastes
            # bitrate and is rejected by most upload targets. Pin it back to 4:2:0.
            "-pix_fmt",
            "yuv420p",
            "-profile:v",
            "high",
            "-c:a",
            "aac",
            "-b:a",
            "160k",
            "-movflags",
            "+faststart",
            str(output),
        ]
    )
    return run_ffmpeg(args, dir_path, total)


XFADE = {
    "fade": "fade",
    "flash": "fadewhite",
    "wipe": "wipeleft",
    "slide": "slideleft",
    "blur": "hblur",
    "zoom": "zoomin",
}


def parse_entries(packed: dict) -> list[dict]:
    entries: list[dict] = []
    for item in packed.get("files") or []:
        if isinstance(item, str):
            path = item
            join_fx = "cut"
            join_seconds = 0.4
        elif isinstance(item, dict):
            path = str(item.get("path") or "")
            join_fx = str(item.get("joinFx") or "cut")
            if join_fx not in XFADE and join_fx != "cut":
                join_fx = "cut"
            try:
                join_seconds = float(item.get("joinSeconds") or 0.4)
            except (TypeError, ValueError):
                join_seconds = 0.4
            join_seconds = min(3.0, max(0.05, join_seconds))
        else:
            continue
        kind = "image" if isinstance(item, dict) and item.get("kind") == "image" else "video"
        if kind == "image":
            try:
                hold = min(60.0, max(0.4, float(item.get("hold") or 3.0)))
            except (TypeError, ValueError):
                hold = 3.0
            if not Path(path).is_file():
                continue
            entries.append({"path": path, "kind": "image", "hold": hold, "joinFx": join_fx, "joinSeconds": join_seconds})
        else:
            if not Path(path).is_file():
                continue
            entries.append({"path": path, "kind": "video", "joinFx": join_fx, "joinSeconds": join_seconds})
    return entries


def concat_xfade(entries: list[dict], output: Path, dir_path: Path, total: float, size: tuple[int, int], subs: str | None) -> int:
    args: list[str] = []
    filters: list[str] = []
    durs: list[float] = []
    for index, entry in enumerate(entries):
        append_inputs(args, entry, size)
        dur = entry_hold(entry)
        durs.append(dur)
        filters.append(f"{scale_video_filter(index, size)},setpts=PTS-STARTPTS[v{index}]")
        if entry.get("kind") not in ("image", "title") and has_audio(str(entry["path"])):
            filters.append(
                f"[{index}:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo,"
                f"asetpts=PTS-STARTPTS[a{index}]"
            )
        else:
            filters.append(
                f"anullsrc=r=48000:cl=stereo,atrim=0:{dur:.3f},"
                f"aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo[a{index}]"
            )
    v_cur = "v0"
    a_cur = "a0"
    acc = durs[0]
    for index in range(1, len(entries)):
        kind = str(entries[index].get("joinFx") or "cut")
        this_dur = durs[index]
        overlap = float(entries[index].get("joinSeconds") or 0.4)
        cap = min(durs[index - 1], this_dur, acc) * 0.8
        overlap = min(overlap, max(0.05, cap))
        # xfade needs both links on the same timebase; settb keeps the chained
        # accumulator compatible with each 1/30 source.
        filters.append(f"[{v_cur}]settb=AVTB,fps=30[vxb{index}]")
        if kind == "cut" or kind not in XFADE or overlap < 0.04:
            filters.append(f"[vxb{index}][v{index}]concat=n=2:v=1:a=0[vx{index}]")
            filters.append(f"[{a_cur}][a{index}]concat=n=2:v=0:a=1[ax{index}]")
            acc += this_dur
        else:
            trans = XFADE[kind]
            offset = max(0.0, acc - overlap)
            filters.append(
                f"[vxb{index}][v{index}]xfade=transition={trans}:duration={overlap:.3f}:offset={offset:.3f}[vx{index}]"
            )
            filters.append(f"[{a_cur}][a{index}]acrossfade=d={overlap:.3f}:c1=tri:c2=tri[ax{index}]")
            acc = acc + this_dur - overlap
        v_cur = f"vx{index}"
        a_cur = f"ax{index}"
    if subs:
        filters.append(f"[{v_cur}]{subs}[vsub]")
        v_cur = "vsub"
    args.extend(
        [
            "-filter_complex",
            ";".join(filters),
            "-map",
            f"[{v_cur}]",
            "-map",
            f"[{a_cur}]",
            "-c:v",
            "libx264",
            "-preset",
            "slow",
            "-crf",
            "17",
            "-pix_fmt",
            "yuv420p",
            "-profile:v",
            "high",
            "-c:a",
            "aac",
            "-b:a",
            "160k",
            "-movflags",
            "+faststart",
            str(output),
        ]
    )
    return run_ffmpeg(args, dir_path, total)


def style_line(name: str, fontsize: int, align: int) -> str:
    return (
        f"Style: {name},{MONTAGE_FONT},{fontsize},{TEXT_COLOR},{TEXT_COLOR},{TEXT_OUTLINE},&H00808080,"
        f"-1,0,0,0,100,100,0,0,1,{max(1, round(fontsize / 18))},0,{align},0,0,0,0"
    )


def subtitle_filter(path: Path) -> str:
    escaped = str(path).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
    fonts = str(FONT_DIR).replace("\\", "/").replace(":", "\\:")
    return f"subtitles='{escaped}':fontsdir='{fonts}'"


def segment_windows(entries: list[dict], durs: list[float]) -> list[tuple[float, float]]:
    windows: list[tuple[float, float]] = []
    acc = durs[0]
    starts = [0.0]
    for index in range(1, len(entries)):
        kind = str(entries[index].get("joinFx") or "cut")
        overlap = float(entries[index].get("joinSeconds") or 0.4)
        cap = min(durs[index - 1], durs[index], acc) * 0.8
        overlap = min(overlap, max(0.05, cap))
        if kind == "cut" or kind not in XFADE or overlap < 0.04:
            starts.append(acc)
            acc += durs[index]
        else:
            starts.append(max(0.0, acc - overlap))
            acc = acc + durs[index] - overlap
    for index, start in enumerate(starts):
        windows.append((start, start + durs[index]))
    return windows


def ass_tag(overrides: str) -> str:
    # libass only honours override tags inside a {...} block. A bare leading
    # \tag is drawn as literal text, so every generated tag gets wrapped.
    clean = overrides.strip()
    if not clean:
        return ""
    if clean.startswith("{") and clean.endswith("}"):
        return clean
    return "{" + clean + "}"


def effect_overrides(effect: str, target: tuple[int, int], off: int, anim_ms: int, do_enter: bool) -> str:
    tx, ty = target
    if effect == "pop":
        if do_enter:
            return r"\fscx150\fscy150\t(0," + f"{anim_ms}" + r",\fscx100\fscy100)"
        return r"\t(0," + f"{anim_ms}" + r",\fscx150\fscy150)"
    if effect.startswith("slide"):
        if effect == "slide-left":
            return f"\\move({tx + off},{ty},{tx},{ty},0,{anim_ms})" if do_enter else f"\\move({tx},{ty},{tx + off},{ty},0,{anim_ms})"
        if effect == "slide-right":
            return f"\\move({tx - off},{ty},{tx},{ty},0,{anim_ms})" if do_enter else f"\\move({tx},{ty},{tx - off},{ty},0,{anim_ms})"
        if effect == "slide-up":
            return f"\\move({tx},{ty + off},{tx},{ty},0,{anim_ms})" if do_enter else f"\\move({tx},{ty},{tx},{ty + off},0,{anim_ms})"
        return f"\\move({tx},{ty - off},{tx},{ty},0,{anim_ms})" if do_enter else f"\\move({tx},{ty},{tx},{ty - off},0,{anim_ms})"
    if effect == "fade":
        return f"\\fad({anim_ms},0)" if do_enter else f"\\fad(0,{anim_ms})"
    return ""


def build_overlay_ass(
    dir_path: Path,
    entries: list[dict],
    durs: list[float],
    total: float,
    size: tuple[int, int],
    packed: dict,
) -> Path | None:
    width, height = size
    overlays: list[dict] = []
    title = packed.get("title")
    title_background = True
    if isinstance(title, dict):
        text = str(title.get("text") or "").strip()
        title_background = title.get("background") is not False
        if text:
            card: dict[str, object] = {
                "text": text,
                "position": "middle",
                "enter": str(title.get("enter") or "fade"),
                "exit": str(title.get("exit") or "fade"),
                "size": "medium",
            }
            if title_background:
                card["slot"] = 0
            else:
                # Lay the card text over the first clip for its own length.
                try:
                    card_seconds = min(12.0, max(0.6, float(title.get("seconds") or 3.0)))
                except (TypeError, ValueError):
                    card_seconds = 3.0
                card["slot"] = 0
                card["until"] = card_seconds
            overlays.append(card)
    raw_overlays = packed.get("overlays") or []
    if not isinstance(raw_overlays, list):
        raw_overlays = []
    for item in raw_overlays:
        if not isinstance(item, dict):
            continue
        text = str(item.get("text") or "").strip()
        if not text:
            continue
        overlays.append(
            {
                "text": text,
                "where": str(item.get("where") or "whole"),
                "part": int(item.get("part") or 0),
                "position": str(item.get("position") or "middle"),
                "enter": str(item.get("enter") or "fade"),
                "exit": str(item.get("exit") or "fade"),
                "size": str(item.get("size") or "medium"),
            }
        )
    native_short = width == 1080 and height == 1920
    socials = packed.get("socials") if native_short and total > 0.4 else None
    slot_offset = 1 if isinstance(title, dict) else 0
    windows = segment_windows(entries, durs)
    events: list[str] = []
    styles: list[dict] = []
    scales = height / 1920.0
    for overlay in overlays:
        position = overlay["position"] if overlay["position"] in TEXT_ALIGN else "middle"
        size_key = overlay["size"] if overlay["size"] in TEXT_BASE else "medium"
        if "slot" in overlay:
            index = int(overlay["slot"])
        elif overlay["where"] == "part":
            index = slot_offset + overlay["part"]
        else:
            index = -1
        if index >= 0 and index < len(windows):
            start, end = windows[index]
        elif index < 0:
            start, end = 0.0, total
        else:
            continue
        if "until" in overlay:
            end = min(end, start + float(overlay["until"]))
        start = max(0.0, min(start, total))
        end = max(start + 0.1, min(end, total))
        if end - start < 0.12:
            continue
        anim = min(0.5, max(0.16, (end - start) * 0.24))
        if anim * 2 > end - start:
            anim = (end - start) / 3
        a_sec = min(anim, max(0.001, (end - start) / 3))
        a_ms = max(1, int(round(a_sec * 1000)))
        align = TEXT_ALIGN[position]
        ty = int(round(height * TEXT_Y[position]))
        tx = width // 2
        off = max(240, int(round(width * 0.45)))
        name = f"MT{len(styles)}_{align}"
        if not any(item["name"] == name for item in styles):
            fontsize = max(20, int(round(TEXT_BASE[size_key] * scales)))
            styles.append({"name": name, "fontsize": fontsize, "align": align})
        enter = overlay["enter"] if overlay["enter"] != "none" else ""
        exit_fx = overlay["exit"] if overlay["exit"] != "none" else ""
        text = escape_ass(overlay["text"])
        if not enter and not exit_fx:
            events.append(f"Dialogue: 20,{fmt_ass_time(start)},{fmt_ass_time(end)},{name},,0,0,0,,{text}")
            continue
        if enter:
            tag = f"\\fad({a_ms},0)" if enter == "fade" else effect_overrides(enter, (tx, ty), off, a_ms, True)
            events.append(
                f"Dialogue: 20,{fmt_ass_time(start)},{fmt_ass_time(start + a_sec)},{name},,0,0,0,,{ass_tag(tag)}{text}"
            )
        static_start = min(end, start + a_sec) if enter else start
        static_end = max(start, end - a_sec) if exit_fx else end
        if static_end - static_start > 0.04:
            events.append(
                f"Dialogue: 20,{fmt_ass_time(static_start)},{fmt_ass_time(static_end)},{name},,0,0,0,,{text}"
            )
        if exit_fx:
            tag = f"\\fad(0,{a_ms})" if exit_fx == "fade" else effect_overrides(exit_fx, (tx, ty), off, a_ms, False)
            events.append(
                f"Dialogue: 20,{fmt_ass_time(end - a_sec)},{fmt_ass_time(end)},{name},,0,0,0,,{ass_tag(tag)}{text}"
            )
    social_lines: list[str] = []
    social_styles: list[str] = []
    if isinstance(socials, dict):
        # captions already emits social badges on layers 10-12 with vector art,
        # so they can ride along unchanged above our layer-20 text.
        social_lines = _social_events({"socials": socials}, total)
        social_styles = _social_styles()
    if not events and not social_lines:
        return None
    body = "\n".join(
        [
            "[Script Info]",
            "ScriptType: v4.00+",
            f"PlayResX: {width}",
            f"PlayResY: {height}",
            "WrapStyle: 0",
            "ScaledBorderAndShadow: yes",
            "",
            "[V4+ Styles]",
            STYLE_FORMAT,
            *[style_line(item["name"], item["fontsize"], item["align"]) for item in styles],
            *social_styles,
            "",
            "[Events]",
            "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
            *events,
            *social_lines,
            "",
        ]
    )
    ass_file = dir_path / "overlay.ass"
    ass_file.write_text(body, encoding="utf-8")
    return ass_file


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dir", required=True)
    args = parser.parse_args()
    dir_path = Path(args.dir)
    packed = load_json(dir_path / "files.json")
    title = packed.get("title")
    has_title = isinstance(title, dict) and bool(str(title.get("text") or "").strip())
    # A transparent title card skips the black plate and lays the text over clip one.
    title_plate = has_title and title.get("background") is not False
    entries = parse_entries(packed)
    if title_plate:
        try:
            card_seconds = min(12.0, max(0.6, float(title.get("seconds") or 3.0)))
        except (TypeError, ValueError):
            card_seconds = 3.0
        entries.insert(0, {"kind": "title", "hold": card_seconds, "joinFx": "cut", "joinSeconds": 0.4})
    files = [str(item["path"]) for item in entries if item.get("kind") != "title"]
    output_name = str(packed.get("output") or "Montage.mp4")
    if not output_name.lower().endswith(".mp4"):
        output_name = "Montage.mp4"
    output = dir_path / Path(output_name).name
    if not files:
        return fail(dir_path, "No clip files were left to stitch.")
    size = video_size(files[0])
    for entry in entries:
        if entry.get("kind") == "video":
            size = video_size(str(entry["path"]))
            break
    durs = [entry_hold(item) for item in entries]
    total = sum(durs) or 1.0
    needs_xfade = any(item.get("joinFx") in XFADE for item in entries[1:])
    has_stills = any(item.get("kind") in ("image", "title") for item in entries)
    subs = None
    if has_title or packed.get("overlays") or packed.get("socials"):
        ass_file = build_overlay_ass(dir_path, entries, durs, total, size, packed)
        subs = subtitle_filter(ass_file) if ass_file else None
    patch_montage(dir_path, progress=8, message="Making the montage.", error=None)
    try:
        if needs_xfade or has_stills or subs:
            copy_code = 1
        else:
            copy_code = concat_copy(files, output, dir_path / "concat.txt")
    except FileNotFoundError:
        return fail(dir_path, "Video tools are missing on this machine.")
    if copy_code != 0 or not output.is_file() or output.stat().st_size < 1024:
        if output.exists():
            try:
                output.unlink()
            except OSError:
                pass
        patch_montage(dir_path, progress=12, message="Making the montage.")
        try:
            if needs_xfade:
                code = concat_xfade(entries, output, dir_path, total, size, subs)
            else:
                code = concat_reencode(entries, output, dir_path, total, size, subs)
        except FileNotFoundError:
            return fail(dir_path, "Video tools are missing on this machine.")
        if code != 0 or not output.is_file():
            return fail(dir_path, "Could not make this montage.")
    skipped = 0
    try:
        skipped = int((load_json(dir_path / "montage.json") or {}).get("skipped") or 0)
    except Exception:
        skipped = 0
    message = "Montage is ready."
    if skipped:
        message = "Montage is ready. Some clips were skipped because their files were gone."
    patch_montage(
        dir_path,
        stage="done",
        progress=100,
        outputFile=output.name,
        message=message,
        error=None,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
