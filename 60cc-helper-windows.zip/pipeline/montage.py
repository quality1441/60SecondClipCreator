#!/usr/bin/env python3
"""Stitch already-encoded clip files into one montage MP4."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
from pathlib import Path

TIME_RE = re.compile(r"time=(\d+):(\d+):(\d+(?:\.\d+)?)")


def load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def patch_montage(dir_path: Path, **fields: object) -> None:
    file = dir_path / "montage.json"
    row = load_json(file)
    row.update(fields)
    row["updatedAt"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    save_json(file, row)


def fail(dir_path: Path, message: str) -> int:
    patch_montage(dir_path, stage="error", error=message, message=None, progress=0)
    print(message, file=sys.stderr)
    return 1


def run_ffprobe(path: str) -> dict:
    try:
        raw = subprocess.check_output(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-show_entries",
                "stream=codec_type,codec_name,width,height",
                "-of",
                "json",
                path,
            ],
            stderr=subprocess.STDOUT,
        )
        return json.loads(raw.decode("utf-8", errors="replace"))
    except Exception:
        return {}


def duration_of(path: str) -> float:
    packed = run_ffprobe(path)
    try:
        return max(0.0, float((packed.get("format") or {}).get("duration") or 0))
    except (TypeError, ValueError):
        return 0.0


def has_audio(path: str) -> bool:
    packed = run_ffprobe(path)
    for stream in packed.get("streams") or []:
        if stream.get("codec_type") == "audio":
            return True
    return False


def video_size(path: str) -> tuple[int, int]:
    packed = run_ffprobe(path)
    for stream in packed.get("streams") or []:
        if stream.get("codec_type") == "video":
            w = int(stream.get("width") or 0)
            h = int(stream.get("height") or 0)
            if w > 0 and h > 0:
                return w, h
    return 1080, 1920


def parse_time(line: str) -> float | None:
    match = TIME_RE.search(line)
    if not match:
        return None
    hours, minutes, seconds = match.groups()
    return int(hours) * 3600 + int(minutes) * 60 + float(seconds)


def run_ffmpeg(args: list[str], dir_path: Path, total: float) -> int:
    proc = subprocess.Popen(
        ["ffmpeg", "-hide_banner", "-y", *args],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    last = 0.0
    assert proc.stderr is not None
    for line in proc.stderr:
        at = parse_time(line)
        if at is None:
            continue
        if total > 0:
            pct = min(96, max(8, round(8 + 88 * (at / total))))
            if at - last >= 0.4:
                last = at
                patch_montage(dir_path, progress=pct, message="Making the montage.")
    return proc.wait()


def concat_copy(files: list[str], output: Path, list_path: Path) -> int:
    lines = ["ffconcat version 1.0"]
    for item in files:
        escaped = item.replace("\\", "/").replace("'", r"'\''")
        lines.append(f"file '{escaped}'")
    list_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    proc = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(list_path),
            "-c",
            "copy",
            str(output),
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return proc.returncode


def concat_reencode(files: list[str], output: Path, dir_path: Path, total: float) -> int:
    width, height = video_size(files[0])
    args: list[str] = []
    filters: list[str] = []
    concat_parts: list[str] = []
    for index, item in enumerate(files):
        args.extend(["-i", item])
        filters.append(
            f"[{index}:v]scale={width}:{height}:force_original_aspect_ratio=decrease,"
            f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,fps=30,setsar=1,format=yuv420p[v{index}]"
        )
        if has_audio(item):
            filters.append(
                f"[{index}:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo[a{index}]"
            )
        else:
            dur = max(duration_of(item), 0.1)
            filters.append(
                f"anullsrc=r=48000:cl=stereo,atrim=0:{dur:.3f},"
                f"aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo[a{index}]"
            )
        concat_parts.append(f"[v{index}][a{index}]")
    filters.append(f"{''.join(concat_parts)}concat=n={len(files)}:v=1:a=1[v][a]")
    args.extend(
        [
            "-filter_complex",
            ";".join(filters),
            "-map",
            "[v]",
            "-map",
            "[a]",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "18",
            "-c:a",
            "aac",
            "-b:a",
            "160k",
            "-movflags",
            "+faststart",
            str(output),
        ]
    )
    return run_ffmpeg(args, dir_path, total)


XFADE = {
    "fade": "fade",
    "flash": "fadewhite",
    "wipe": "wipeleft",
    "slide": "slideleft",
    "blur": "hblur",
    "zoom": "zoomin",
}


def parse_entries(packed: dict) -> list[dict]:
    entries: list[dict] = []
    for item in packed.get("files") or []:
        if isinstance(item, str):
            path = item
            join_fx = "cut"
            join_seconds = 0.4
        elif isinstance(item, dict):
            path = str(item.get("path") or "")
            join_fx = str(item.get("joinFx") or "cut")
            if join_fx not in XFADE and join_fx != "cut":
                join_fx = "cut"
            try:
                join_seconds = float(item.get("joinSeconds") or 0.4)
            except (TypeError, ValueError):
                join_seconds = 0.4
            join_seconds = min(3.0, max(0.05, join_seconds))
        else:
            continue
        if not Path(path).is_file():
            continue
        entries.append({"path": path, "joinFx": join_fx, "joinSeconds": join_seconds})
    return entries


def concat_xfade(entries: list[dict], output: Path, dir_path: Path, total: float) -> int:
    files = [str(item["path"]) for item in entries]
    width, height = video_size(files[0])
    args: list[str] = []
    filters: list[str] = []
    durs: list[float] = []
    for index, item in enumerate(files):
        args.extend(["-i", item])
        dur = max(duration_of(item), 0.1)
        durs.append(dur)
        filters.append(
            f"[{index}:v]scale={width}:{height}:force_original_aspect_ratio=decrease,"
            f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,fps=30,setsar=1,format=yuv420p,setpts=PTS-STARTPTS[v{index}]"
        )
        if has_audio(item):
            filters.append(
                f"[{index}:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo,asetpts=PTS-STARTPTS[a{index}]"
            )
        else:
            filters.append(
                f"anullsrc=r=48000:cl=stereo,atrim=0:{dur:.3f},"
                f"aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo[a{index}]"
            )
    v_cur = "v0"
    a_cur = "a0"
    acc = durs[0]
    for index in range(1, len(files)):
        kind = str(entries[index].get("joinFx") or "cut")
        this_dur = durs[index]
        overlap = float(entries[index].get("joinSeconds") or 0.4)
        cap = min(durs[index - 1], this_dur, acc) * 0.8
        overlap = min(overlap, max(0.05, cap))
        if kind == "cut" or kind not in XFADE or overlap < 0.04:
            filters.append(f"[{v_cur}][v{index}]concat=n=2:v=1:a=0[vx{index}]")
            filters.append(f"[{a_cur}][a{index}]concat=n=2:v=0:a=1[ax{index}]")
            acc += this_dur
        else:
            trans = XFADE[kind]
            offset = max(0.0, acc - overlap)
            filters.append(
                f"[{v_cur}][v{index}]xfade=transition={trans}:duration={overlap:.3f}:offset={offset:.3f}[vx{index}]"
            )
            filters.append(f"[{a_cur}][a{index}]acrossfade=d={overlap:.3f}:c1=tri:c2=tri[ax{index}]")
            acc = acc + this_dur - overlap
        v_cur = f"vx{index}"
        a_cur = f"ax{index}"
    args.extend(
        [
            "-filter_complex",
            ";".join(filters),
            "-map",
            f"[{v_cur}]",
            "-map",
            f"[{a_cur}]",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "18",
            "-c:a",
            "aac",
            "-b:a",
            "160k",
            "-movflags",
            "+faststart",
            str(output),
        ]
    )
    return run_ffmpeg(args, dir_path, total)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dir", required=True)
    args = parser.parse_args()
    dir_path = Path(args.dir)
    packed = load_json(dir_path / "files.json")
    entries = parse_entries(packed)
    files = [str(item["path"]) for item in entries]
    output_name = str(packed.get("output") or "Montage.mp4")
    if not output_name.lower().endswith(".mp4"):
        output_name = "Montage.mp4"
    output = dir_path / Path(output_name).name
    if not files:
        return fail(dir_path, "No clip files were left to stitch.")
    total = sum(duration_of(item) for item in files) or 1.0
    needs_xfade = any(item.get("joinFx") in XFADE for item in entries[1:])
    patch_montage(dir_path, progress=8, message="Making the montage.", error=None)
    try:
        if needs_xfade:
            copy_code = 1
        else:
            copy_code = concat_copy(files, output, dir_path / "concat.txt")
    except FileNotFoundError:
        return fail(dir_path, "Video tools are missing on this machine.")
    if copy_code != 0 or not output.is_file() or output.stat().st_size < 1024:
        if output.exists():
            try:
                output.unlink()
            except OSError:
                pass
        patch_montage(dir_path, progress=12, message="Making the montage.")
        try:
            code = concat_xfade(entries, output, dir_path, total) if needs_xfade else concat_reencode(files, output, dir_path, total)
        except FileNotFoundError:
            return fail(dir_path, "Video tools are missing on this machine.")
        if code != 0 or not output.is_file():
            return fail(dir_path, "Could not make this montage.")
    skipped = 0
    try:
        skipped = int((load_json(dir_path / "montage.json") or {}).get("skipped") or 0)
    except Exception:
        skipped = 0
    message = "Montage is ready."
    if skipped:
        message = "Montage is ready. Some clips were skipped because their files were gone."
    patch_montage(
        dir_path,
        stage="done",
        progress=100,
        outputFile=output.name,
        message=message,
        error=None,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
