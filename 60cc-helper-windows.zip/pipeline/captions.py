"""ASS / libass caption themes for 60 Second Clip Creator."""

from __future__ import annotations

from pathlib import Path

from social_icons import ICON_PX, icon_drawing, icon_layers

THEMES = ("tactical", "twin", "punch")
DEFAULT_VOICE1_TAG = "DRV"
DEFAULT_VOICE2_TAG = "RDO"
DEFAULT_VOICE3_TAG = "GUE"
DEFAULT_VOICE4_TAG = "CHAT"
DEFAULT_VOICE1_COLOR = "#F2F2F2"
DEFAULT_VOICE2_COLOR = "#FFC808"
DEFAULT_VOICE3_COLOR = "#7DCFB6"
DEFAULT_VOICE4_COLOR = "#C084FC"
VOICE_IDS = ("Voice1", "Voice2", "Voice3", "Voice4")
VOICE_DEFAULTS = {
    "Voice1": (DEFAULT_VOICE1_TAG, DEFAULT_VOICE1_COLOR),
    "Voice2": (DEFAULT_VOICE2_TAG, DEFAULT_VOICE2_COLOR),
    "Voice3": (DEFAULT_VOICE3_TAG, DEFAULT_VOICE3_COLOR),
    "Voice4": (DEFAULT_VOICE4_TAG, DEFAULT_VOICE4_COLOR),
}
# PlayRes 1080x1920. Bottom MarginV is from the bottom edge; 330 sits above the speedo.
SAFE_MARGIN_V = {
    "bottom": 330,
    "center": 0,
    "top": 170,
}

# Fixed Tactical HUD capsule (PlayRes px). Pill width grows with the voice tag.
HUD_X = 48
HUD_W = 984
HUD_H = 100
HUD_R = 50
HUD_PILL_MIN = 188
HUD_PILL_PER_GLYPH = 28
HUD_TAG_MAX = 6
HUD_Y = {
    "bottom": 1488,
    "center": 910,
    "top": 208,
}
HUD_FONT = 46
HUD_TAG_FONT = 34
HUD_TRACKING = 0.0
HUD_HIGHLIGHT_PAD = 9
HUD_LINE_H = 52
HUD_MAX_ROWS = 2
HOLD_MAX = 1.5
CAPTION_SCALES = {"small": 0.82, "medium": 1.0, "large": 1.22}
PLATE_FILL = "&H00101820"
TAG_TEXT = "&H00101820"
IDLE_TEXT = "&H00F0F0F4"
LIGHT_TEXT = "&H00F0F0F4"


def default_caption_style() -> dict:
    return {
        "theme": "tactical",
        "position": "bottom",
        "karaoke": True,
        "boxed": True,
        "speakerColors": True,
        "voice1Tag": DEFAULT_VOICE1_TAG,
        "voice2Tag": DEFAULT_VOICE2_TAG,
        "voice3Tag": DEFAULT_VOICE3_TAG,
        "voice4Tag": DEFAULT_VOICE4_TAG,
        "voice1Color": DEFAULT_VOICE1_COLOR,
        "voice2Color": DEFAULT_VOICE2_COLOR,
        "voice3Color": DEFAULT_VOICE3_COLOR,
        "voice4Color": DEFAULT_VOICE4_COLOR,
        "voice1Text": "#101820",
        "voice2Text": "#101820",
        "voice3Text": "#101820",
        "voice4Text": "#101820",
        "speechLabels": 0,
        "hold": 0.0,
        "size": "medium",
        "socials": default_social_style(),
    }


def default_social_style() -> dict:
    blank = {"enabled": False, "handle": ""}
    return {
        "name": "",
        "corner": "top-right",
        "enter": "slide-right",
        "exit": "fade",
        "start": 0.8,
        "end": 0.0,
        "hold": 2.6,
        "loop": True,
        "size": "small",
        "shape": "pill",
        "icon": "left",
        "twitch": dict(blank),
        "youtube": dict(blank),
        "kick": dict(blank),
        "instagram": dict(blank),
        "tiktok": dict(blank),
        "custom": [],
    }


SOCIAL_PLATFORMS = (
    ("twitch", "#9146FF", "TW"),
    ("youtube", "#FF0000", "YT"),
    ("kick", "#53FC18", "KK"),
    ("instagram", "#E1306C", "IG"),
    ("tiktok", "#25F4EE", "TT"),
)
SOCIAL_CORNERS = (
    "top-left",
    "top-center",
    "top-right",
    "center-left",
    "center",
    "center-right",
    "bottom-left",
    "bottom-center",
    "bottom-right",
)
SOCIAL_EFFECTS = (
    "fade",
    "slide-left",
    "slide-right",
    "slide-top",
    "slide-bottom",
    "pop",
    "bounce",
    "blur",
)
SOCIAL_H = 68.0
SOCIAL_ANIM = 0.38
SOCIAL_GAP = 0.28
SOCIAL_PLATE = "&H00101820"
SOCIAL_NAME = "&H00F0F0F4"
SOCIAL_SCALES = {"small": 1.0, "medium": 1.45, "large": 1.9}
SOCIAL_SHAPES = ("pill", "square")
SOCIAL_ICON_SIDES = ("left", "right")
CUSTOM_BADGE_MAX = 4
CUSTOM_BADGE_LABEL_MAX = 16
DEFAULT_CUSTOM_BADGE_COLOR = "#B54A3C"


def _normalize_handle(raw: object) -> str:
    text = " ".join(str(raw or "").split())
    return text[:24]


def _normalize_social_time(raw: object, fallback: float, lo: float, hi: float) -> float:
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return fallback
    return max(lo, min(hi, round(value * 20) / 20))


def _normalize_socials(raw: object) -> dict:
    style = default_social_style()
    src = raw if isinstance(raw, dict) else {}
    style["name"] = _normalize_handle(src.get("name"))
    corner = str(src.get("corner") or "top-right")
    style["corner"] = corner if corner in SOCIAL_CORNERS else "top-right"
    enter = str(src.get("enter") or "slide-right")
    style["enter"] = enter if enter in SOCIAL_EFFECTS else "slide-right"
    exit_fx = str(src.get("exit") or "fade")
    style["exit"] = exit_fx if exit_fx in SOCIAL_EFFECTS else "fade"
    style["start"] = _normalize_social_time(src.get("start"), 0.8, 0.0, 600.0)
    style["end"] = _normalize_social_time(src.get("end"), 0.0, 0.0, 600.0)
    style["hold"] = _normalize_social_time(src.get("hold"), 2.6, 1.2, 8.0)
    style["loop"] = src.get("loop") is not False
    size = str(src.get("size") or "small").lower()
    style["size"] = size if size in SOCIAL_SCALES else "small"
    shape = str(src.get("shape") or "pill").lower()
    style["shape"] = shape if shape in SOCIAL_SHAPES else "pill"
    icon = str(src.get("icon") or "left").lower()
    style["icon"] = icon if icon in SOCIAL_ICON_SIDES else "left"
    for key, _color, _mark in SOCIAL_PLATFORMS:
        item = src.get(key) if isinstance(src.get(key), dict) else {}
        style[key] = {
            "enabled": bool(item.get("enabled")),
            "handle": _normalize_handle(item.get("handle")),
        }
    style["custom"] = _normalize_custom_badges(src.get("custom"))
    return style


def _normalize_custom_badges(raw: object) -> list[dict]:
    items = raw if isinstance(raw, list) else []
    out: list[dict] = []
    for entry in items:
        if len(out) >= CUSTOM_BADGE_MAX:
            break
        if not isinstance(entry, dict):
            continue
        label = " ".join(str(entry.get("label") or "").split())[:CUSTOM_BADGE_LABEL_MAX]
        if not label:
            continue
        bid = "".join(ch for ch in str(entry.get("id") or "") if ch.isalnum() or ch in "-_")[:24]
        if not bid:
            bid = f"custom-{len(out) + 1}"
        out.append(
            {
                "id": bid,
                "enabled": bool(entry.get("enabled")),
                "label": label,
                "color": _normalize_hex(entry.get("color"), DEFAULT_CUSTOM_BADGE_COLOR),
                "look": "solid" if str(entry.get("look") or "").lower() == "solid" else "social",
            }
        )
    return out


def _normalize_tag(raw: object, fallback: str) -> str:
    letters = "".join(ch for ch in str(raw or "").upper() if ch.isalnum())[:HUD_TAG_MAX]
    return letters or fallback


def _normalize_speech_labels(raw: object) -> int:
    if raw is None or raw == "":
        return 0
    try:
        value = int(float(raw))
    except (TypeError, ValueError):
        return 0
    if value <= 0:
        return 0
    return min(4, value)


def show_speech_label(style: dict) -> bool:
    return int(style.get("speechLabels") or 0) > 0


def optional_speaker(value) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.lower() in {"none", "off"} or text == "0":
        return None
    return speaker_key(value)


def label_speaker(style: dict, speaker: str) -> str:
    assigned = optional_speaker(speaker)
    if assigned is None:
        return "Voice1"
    return assigned


def _normalize_hold(raw: object) -> float:
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(HOLD_MAX, round(value * 20) / 20))


def _normalize_hex(raw: object, fallback: str) -> str:
    text = str(raw or "").strip()
    if text.startswith("#"):
        text = text[1:]
    if len(text) == 3 and all(ch in "0123456789abcdefABCDEF" for ch in text):
        text = "".join(ch * 2 for ch in text)
    if len(text) == 6 and all(ch in "0123456789abcdefABCDEF" for ch in text):
        return f"#{text.upper()}"
    return fallback


def hex_to_ass(hex_color: str) -> str:
    h = _normalize_hex(hex_color, "#FFFFFF")[1:]
    red, green, blue = h[0:2], h[2:4], h[4:6]
    return f"&H00{blue}{green}{red}"


def hex_luminance(hex_color: str) -> float:
    h = _normalize_hex(hex_color, "#FFFFFF")[1:]
    red = int(h[0:2], 16) / 255
    green = int(h[2:4], 16) / 255
    blue = int(h[4:6], 16) / 255
    return 0.2126 * red + 0.7152 * green + 0.0722 * blue


def contrast_text_ass(fill_hex: str) -> str:
    return TAG_TEXT if hex_luminance(fill_hex) > 0.45 else LIGHT_TEXT


def _contrast_hex(fill_hex: str) -> str:
    return "#101820" if hex_luminance(fill_hex) > 0.45 else "#F0F0F4"


def voice_fill(style: dict, speaker: str) -> str:
    return hex_to_ass(_voice_hex(style, speaker))


def voice_ink(style: dict, speaker: str) -> str:
    return hex_to_ass(_voice_text_hex(style, speaker))


def voice_tag(style: dict, speaker: str) -> str:
    key = speaker_key(speaker)
    fallback, _color = VOICE_DEFAULTS[key]
    tag = style.get(f"voice{key[-1]}Tag") or fallback
    return f"({tag})"


def _normalize_caption_size(raw) -> str:
    value = str(raw or "medium").lower()
    return value if value in CAPTION_SCALES else "medium"


def _caption_scale(style: dict | None = None) -> float:
    return CAPTION_SCALES.get(_normalize_caption_size((style or {}).get("size")), 1.0)


def hud_pill_w(displayed_tag: str | None = None, scale: float = 1.0) -> int:
    glyphs = HUD_TAG_MAX + 2 if displayed_tag is None else max(5, len(displayed_tag))
    extra = max(0, glyphs - 5)
    return int(round((HUD_PILL_MIN + extra * HUD_PILL_PER_GLYPH) * scale))


def normalize_style(raw: dict | None) -> dict:
    style = default_caption_style()
    if not raw:
        return style
    theme = str(raw.get("theme") or "").lower()
    if theme in THEMES:
        style["theme"] = theme
    elif raw.get("karaoke"):
        style["theme"] = "punch"
    elif raw.get("boxed"):
        style["theme"] = "tactical"
    position = str(raw.get("position") or "bottom").lower()
    if position == "middle":
        position = "center"
    if position in SAFE_MARGIN_V:
        style["position"] = position
    style["karaoke"] = style["theme"] in {"tactical", "punch"}
    style["boxed"] = style["theme"] in {"tactical", "twin"}
    style["speakerColors"] = True
    style["voice1Tag"] = _normalize_tag(raw.get("voice1Tag"), DEFAULT_VOICE1_TAG)
    style["voice2Tag"] = _normalize_tag(raw.get("voice2Tag"), DEFAULT_VOICE2_TAG)
    style["voice3Tag"] = _normalize_tag(raw.get("voice3Tag"), DEFAULT_VOICE3_TAG)
    style["voice4Tag"] = _normalize_tag(raw.get("voice4Tag"), DEFAULT_VOICE4_TAG)
    style["voice1Color"] = _normalize_hex(raw.get("voice1Color"), DEFAULT_VOICE1_COLOR)
    style["voice2Color"] = _normalize_hex(raw.get("voice2Color"), DEFAULT_VOICE2_COLOR)
    style["voice3Color"] = _normalize_hex(raw.get("voice3Color"), DEFAULT_VOICE3_COLOR)
    style["voice4Color"] = _normalize_hex(raw.get("voice4Color"), DEFAULT_VOICE4_COLOR)
    style["voice1Text"] = _normalize_hex(raw.get("voice1Text"), _contrast_hex(style["voice1Color"]))
    style["voice2Text"] = _normalize_hex(raw.get("voice2Text"), _contrast_hex(style["voice2Color"]))
    style["voice3Text"] = _normalize_hex(raw.get("voice3Text"), _contrast_hex(style["voice3Color"]))
    style["voice4Text"] = _normalize_hex(raw.get("voice4Text"), _contrast_hex(style["voice4Color"]))
    style["speechLabels"] = _normalize_speech_labels(raw.get("speechLabels"))
    style["hold"] = _normalize_hold(raw.get("hold", 0))
    style["size"] = _normalize_caption_size(raw.get("size"))
    style["socials"] = _normalize_socials(raw.get("socials"))
    return style


def fmt_ass_time(seconds: float) -> str:
    cs = max(0, int(round(seconds * 100)))
    hours, cs = divmod(cs, 360_000)
    minutes, cs = divmod(cs, 6_000)
    secs, cs = divmod(cs, 100)
    return f"{hours}:{minutes:02d}:{secs:02d}.{cs:02d}"


def escape_ass(text: str) -> str:
    return text.replace("{", "(").replace("}", ")").replace("\\", "/")


def _u16(buf: bytes, offset: int) -> int:
    return int.from_bytes(buf[offset : offset + 2], "big")


def _i16(buf: bytes, offset: int) -> int:
    value = _u16(buf, offset)
    return value - 0x10000 if value & 0x8000 else value


def _u32(buf: bytes, offset: int) -> int:
    return int.from_bytes(buf[offset : offset + 4], "big")


def _ttf_tables(data: bytes) -> dict[bytes, tuple[int, int]]:
    count = _u16(data, 4)
    tables: dict[bytes, tuple[int, int]] = {}
    for index in range(count):
        start = 12 + index * 16
        tables[data[start : start + 4]] = (_u32(data, start + 8), _u32(data, start + 12))
    return tables


def _ttf_cmap(data: bytes) -> dict[int, int]:
    tables = _ttf_tables(data)
    if b"cmap" not in tables:
        return {}
    offset, length = tables[b"cmap"]
    cmap = data[offset : offset + length]
    records = _u16(cmap, 2)
    sub_off = None
    for index in range(records):
        base = 4 + index * 8
        platform, encoding, table_off = _u16(cmap, base), _u16(cmap, base + 2), _u32(cmap, base + 4)
        if (platform, encoding) in {(3, 1), (0, 3), (0, 4)}:
            sub_off = table_off
            if platform == 3:
                break
    if sub_off is None:
        return {}
    sub = cmap[sub_off:]
    if _u16(sub, 0) != 4:
        return {}
    seg_count = _u16(sub, 6) // 2
    end_off = 14
    start_off = end_off + 2 * seg_count + 2
    delta_off = start_off + 2 * seg_count
    range_off = delta_off + 2 * seg_count
    mapping: dict[int, int] = {}
    for index in range(seg_count):
        start = _u16(sub, start_off + 2 * index)
        end = _u16(sub, end_off + 2 * index)
        delta = _i16(sub, delta_off + 2 * index)
        range_offset = _u16(sub, range_off + 2 * index)
        for code in range(start, end + 1):
            if range_offset == 0:
                glyph = (code + delta) & 0xFFFF
            else:
                glyph_off = range_off + 2 * index + range_offset + 2 * (code - start)
                glyph = _u16(sub, glyph_off)
                if glyph:
                    glyph = (glyph + delta) & 0xFFFF
            mapping[code] = glyph
    return mapping


def _ttf_advances(data: bytes) -> tuple[int, list[int]]:
    tables = _ttf_tables(data)
    head = data[tables[b"head"][0] : tables[b"head"][0] + tables[b"head"][1]]
    hhea = data[tables[b"hhea"][0] : tables[b"hhea"][0] + tables[b"hhea"][1]]
    hmtx = data[tables[b"hmtx"][0] : tables[b"hmtx"][0] + tables[b"hmtx"][1]]
    units = _u16(head, 18)
    count = _u16(hhea, 34)
    advances = [_u16(hmtx, index * 4) for index in range(count)]
    return units, advances


def _ttf_kern(data: bytes) -> dict[tuple[int, int], int]:
    tables = _ttf_tables(data)
    if b"kern" not in tables:
        return {}
    offset, length = tables[b"kern"]
    kern = data[offset : offset + length]
    if len(kern) < 16 or _u16(kern, 0) != 0:
        return {}
    sub = 4
    coverage = _u16(kern, sub + 4)
    if coverage != 1:
        return {}
    pairs = _u16(kern, sub + 6)
    cursor = sub + 14
    out: dict[tuple[int, int], int] = {}
    for _ in range(pairs):
        if cursor + 6 > len(kern):
            break
        left = _u16(kern, cursor)
        right = _u16(kern, cursor + 2)
        out[(left, right)] = _i16(kern, cursor + 4)
        cursor += 6
    return out


def _hud_font_path() -> Path | None:
    repo = Path(__file__).resolve().parents[1] / "fonts" / "LiberationSans-Regular.ttf"
    if repo.is_file():
        return repo
    return None


class _HudFont:
    def __init__(self, path: Path, size: float, tracking: float) -> None:
        data = path.read_bytes()
        self.size = size
        self.tracking = tracking
        self.units, self.advances = _ttf_advances(data)
        self.cmap = _ttf_cmap(data)
        self.kern = _ttf_kern(data)

    def glyph(self, char: str) -> int:
        return self.cmap.get(ord(char), 0)

    def advance(self, glyph: int) -> float:
        if not self.advances:
            return 0.0
        index = glyph if glyph < len(self.advances) else len(self.advances) - 1
        return self.advances[index] * self.size / self.units

    def width(self, text: str) -> float:
        if not text:
            return 0.0
        total = 0.0
        prev = None
        for char in text:
            glyph = self.glyph(char)
            if prev is not None:
                total += self.kern.get((prev, glyph), 0) * self.size / self.units
            total += self.advance(glyph) + self.tracking
            prev = glyph
        return total


_HUD_FONT: _HudFont | None | bool = False


def _hud_font() -> _HudFont | None:
    global _HUD_FONT
    if _HUD_FONT is False:
        path = _hud_font_path()
        _HUD_FONT = _HudFont(path, HUD_FONT, HUD_TRACKING) if path else None
    return None if _HUD_FONT is False else _HUD_FONT


def wrap_caption(text: str, width: int = 28) -> str:
    words = text.split()
    lines: list[str] = []
    buf: list[str] = []
    for word in words:
        tentative = " ".join(buf + [word])
        if buf and len(tentative) > width:
            lines.append(" ".join(buf))
            buf = [word]
        else:
            buf.append(word)
        if len(lines) == 1 and buf and len(" ".join(buf)) > width:
            break
    if buf and len(lines) < 2:
        lines.append(" ".join(buf))
    return r"\N".join(lines[:2])


def speaker_key(value) -> str:
    if value in (3, "3", "Voice3", "SPEAKER_02"):
        return "Voice3"
    if value in (4, "4", "Voice4", "SPEAKER_03"):
        return "Voice4"
    if value in (1, "1", "B", "Voice2", "SPEAKER_01", "RDO", "Passenger", "Radio 2"):
        return "Voice2"
    return "Voice1"


def _voice_index(speaker: str) -> int:
    key = speaker_key(speaker)
    try:
        return int(key.replace("Voice", ""))
    except ValueError:
        return 1


def _voice_hex(style: dict, speaker: str) -> str:
    key = speaker_key(speaker)
    _tag, fallback = VOICE_DEFAULTS[key]
    return style.get(f"voice{key[-1]}Color") or fallback


def _voice_text_hex(style: dict, speaker: str) -> str:
    key = speaker_key(speaker)
    fill = _voice_hex(style, speaker)
    fallback = _contrast_hex(fill)
    raw = style.get(f"voice{key[-1]}Text")
    if raw:
        return _normalize_hex(raw, fallback)
    return fallback


def _rel_word(word: dict, window_start: float, window_end: float) -> dict:
    return {
        "start": max(0.0, float(word["start"]) - window_start),
        "end": min(window_end - window_start, max(0.0, float(word["end"]) - window_start)),
        "word": word.get("word"),
        "speaker": word.get("speaker"),
    }


def cue_groups(transcript: dict, start: float, end: float, style: dict | None = None) -> list[dict]:
    style = normalize_style(style)
    words = [
        word
        for word in transcript.get("words") or []
        if word["end"] > start and word["start"] < end
    ]
    if style["theme"] == "punch":
        cues = []
        for index, word in enumerate(words):
            rel_s = max(0.0, float(word["start"]) - start)
            rel_e = min(end, float(word["end"])) - start
            if index + 1 < len(words):
                rel_e = min(rel_e, max(0.0, float(words[index + 1]["start"]) - start))
            if rel_e <= rel_s:
                rel_e = rel_s + 0.05
            token = str(word.get("word") or "").strip()
            if not token:
                continue
            cues.append(
                {
                    "start": rel_s,
                    "end": rel_e,
                    "speaker": optional_speaker(word.get("speaker")) or "",
                    "words": [_rel_word(word, start, end)],
                    "text": token,
                }
            )
        return cues

    max_words = 6
    groups: list[list[dict]] = []
    buf: list[dict] = []
    for word in words:
        same_speaker = (not buf) or optional_speaker(buf[-1].get("speaker")) == optional_speaker(
            word.get("speaker")
        )
        token = str(word.get("word") or "")
        stem = token.rstrip(".,!?")
        split_punct = (
            style["theme"] != "tactical"
            and len(buf) >= 3
            and token.endswith((".", "!", "?"))
            and len(stem) > 2
        )
        split_count = style["theme"] != "tactical" and len(buf) >= max_words
        if buf and (
            not same_speaker
            or split_count
            or split_punct
            or (word["start"] - buf[-1]["end"] > 0.55)
        ):
            groups.append(buf)
            buf = [word]
        else:
            buf.append(word)
    if buf:
        groups.append(buf)
    if style["theme"] == "tactical":
        packed: list[list[dict]] = []
        for group in groups:
            remaining = [item for item in group if str(item.get("word") or "").strip()]
            while remaining:
                scale = _caption_scale(style)
                rows, overflow = _hud_rows(
                    remaining,
                    show_pill=show_speech_label(style),
                    pill_w=hud_pill_w(scale=scale),
                    scale=scale,
                )
                fitted = [item for row in rows for item in row]
                if not fitted:
                    fitted = remaining[:1]
                    overflow = remaining[1:]
                packed.append(fitted)
                remaining = overflow
        groups = packed
    if not groups:
        for seg in transcript.get("segments") or []:
            if seg["end"] <= start or seg["start"] >= end:
                continue
            groups.append(
                [
                    {
                        "start": seg["start"],
                        "end": seg["end"],
                        "word": seg["text"],
                        "speaker": seg.get("speaker", "Voice1"),
                    }
                ]
            )
    cues = []
    for group in groups:
        rel_s = max(0.0, group[0]["start"] - start)
        rel_e = max(rel_s + 0.35, min(end, group[-1]["end"]) - start)
        cues.append(
            {
                "start": rel_s,
                "end": rel_e,
                "speaker": optional_speaker(group[0].get("speaker")) or "",
                "words": [_rel_word(item, start, end) for item in group],
                "text": " ".join(str(item.get("word") or "") for item in group).strip(),
            }
        )
    return apply_cue_hold(cues, style.get("hold") or 0, max(0.0, end - start))


def _socials_on(style: dict) -> bool:
    socials = style.get("socials") or {}
    for key, _color, _mark in SOCIAL_PLATFORMS:
        if (socials.get(key) or {}).get("enabled"):
            return True
    for badge in socials.get("custom") or []:
        if isinstance(badge, dict) and badge.get("enabled") and str(badge.get("label") or "").strip():
            return True
    return False


def _social_band(corner: str) -> str:
    text = str(corner or "top-right")
    if text.startswith("top"):
        return "top"
    if text.startswith("bottom"):
        return "bottom"
    return "center"


def _caption_dodge_px(style: dict) -> float:
    if not _socials_on(style):
        return 0.0
    socials = style.get("socials") or {}
    corner = str(socials.get("corner") or "top-right")
    band = _social_band(corner)
    position = str(style.get("position") or "bottom")
    if band != position:
        return 0.0
    if style.get("theme") == "tactical" and (corner.endswith("left") or corner.endswith("right")):
        return 0.0
    extra = (_caption_scale(style) - 1.0) * 24.0
    return SOCIAL_H * _social_scale(socials) + 32.0 + extra


def _widest_badge(style: dict) -> float:
    socials = style.get("socials") or {}
    scale = _social_scale(socials)
    shared = str(socials.get("name") or "").strip()
    widest = 220.0 * scale
    for key, _color, _mark in SOCIAL_PLATFORMS:
        item = socials.get(key) or {}
        if not item.get("enabled"):
            continue
        handle = str(item.get("handle") or "").strip() or shared
        if not handle:
            continue
        width, _height = _social_size(handle, scale)
        widest = max(widest, width)
    for badge in socials.get("custom") or []:
        if not isinstance(badge, dict) or not badge.get("enabled"):
            continue
        label = str(badge.get("label") or "").strip()
        if not label:
            continue
        width, _height = _social_size(label, scale)
        widest = max(widest, width)
    return widest


def _hud_layout(style: dict) -> tuple[float, float, float]:
    if not _socials_on(style):
        return float(HUD_X), float(HUD_W), 0.0
    socials = style.get("socials") or {}
    corner = str(socials.get("corner") or "top-right")
    band = _social_band(corner)
    position = str(style.get("position") or "bottom")
    if band != position:
        return float(HUD_X), float(HUD_W), 0.0
    if corner.endswith("left") or corner.endswith("right"):
        inset = min(420.0, _widest_badge(style) + 28.0)
        if corner.endswith("left"):
            return float(HUD_X) + inset, max(360.0, float(HUD_W) - inset), 0.0
        return float(HUD_X), max(360.0, float(HUD_W) - inset), 0.0
    extra = (_caption_scale(style) - 1.0) * 24.0
    return float(HUD_X), float(HUD_W), SOCIAL_H * _social_scale(socials) + 32.0 + extra


def _align(position: str, theme: str, speaker: str) -> int:
    if theme == "twin":
        if position == "top":
            return 7 if speaker == "Voice1" else 9
        if position == "center":
            return 4 if speaker == "Voice1" else 6
        return 1 if speaker == "Voice1" else 3
    if position == "top":
        return 8
    if position == "center":
        return 5
    return 2


def _style_line(name: str, speaker: str, theme: str, position: str, style: dict) -> str:
    dodge = _caption_dodge_px(style)
    margin_v = int(SAFE_MARGIN_V[position] + (dodge if position in {"top", "bottom"} else 0))
    align = _align(position, theme, speaker)
    fill = voice_fill(style, speaker)
    ink = voice_ink(style, speaker)
    scale = _caption_scale(style)
    hud_font = max(1, int(round(HUD_FONT * scale)))
    twin_font = max(1, int(round(44 * scale)))
    twin_outline = max(1, int(round(8 * scale)))
    punch_font = max(1, int(round(108 * scale)))
    punch_outline = max(1, int(round(12 * scale)))
    if speaker != "Voice1":
        secondary = "&H004090B0"
    else:
        secondary = "&H00A0A0A0"
    if theme == "tactical":
        return (
            f"Style: {name},Liberation Sans,{hud_font},{ink},{secondary},&H00000000,&H00000000,"
            f"0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1"
        )
    if theme == "twin":
        return (
            f"Style: {name},Liberation Sans,{twin_font},{ink},{secondary},{fill},&H64000000,"
            f"1,0,0,0,100,100,0,0,3,{twin_outline},0,{align},56,56,{margin_v},1"
        )
    return (
        f"Style: {name},Liberation Sans,{punch_font},{ink},{secondary},{fill},&H64000000,"
        f"1,0,0,0,100,100,0,0,1,{punch_outline},0,{align},40,40,{margin_v},1"
    )


def _hud_styles(style: dict | None = None) -> list[str]:
    scale = _caption_scale(style)
    tag_font = max(1, int(round(HUD_TAG_FONT * scale)))
    word_font = max(1, int(round(HUD_FONT * scale)))
    return [
        (
            "Style: HudDraw,Liberation Sans,1,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,"
            "0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1"
        ),
        (
            f"Style: HudTag,Liberation Sans,{tag_font},{TAG_TEXT},{TAG_TEXT},&H00000000,&H00000000,"
            "1,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1"
        ),
        (
            f"Style: HudWords,Liberation Sans,{word_font},{IDLE_TEXT},{IDLE_TEXT},&H00000000,&H00000000,"
            "0,0,0,0,100,100,0,0,1,0,0,4,0,0,0,1"
        ),
    ]


def wrap_word_rows(words: list[dict], width: int = 26) -> list[list[dict]]:
    items = [word for word in words if str(word.get("word") or "").strip()]
    if not items:
        return []
    line1: list[dict] = []
    line2: list[dict] = []
    length = 0
    target = line1
    for word in items:
        token = str(word.get("word") or "").strip()
        extra = len(token) + (1 if target else 0)
        if target is line1 and target and length + extra > width:
            target = line2
            length = 0
            extra = len(token)
        target.append(word)
        length += extra
    return [row for row in (line1, line2) if row]


def _event_text(cue: dict, theme: str, style: dict) -> str:
    scale = _caption_scale(style)
    if theme == "twin":
        wrap_w = max(10, int(round(18 / scale)))
        body = wrap_caption(escape_ass(cue["text"]), width=wrap_w)
    else:
        token = escape_ass(cue["text"]).strip()
        bord = max(1, int(round(12 * scale)))
        body = rf"{{\fscx112\fscy112\bord{bord}}}{token}"
    dodge = _caption_dodge_px(style)
    if dodge <= 0 or str(style.get("position") or "") != "center":
        return body
    y = 960.0 + dodge
    speaker = speaker_key(cue.get("speaker"))
    if theme == "twin":
        tag = rf"\an4\pos(56,{y:.0f})" if speaker == "Voice1" else rf"\an6\pos(1024,{y:.0f})"
    else:
        tag = rf"\an5\pos(540,{y:.0f})"
    if body.startswith("{"):
        return "{" + tag + body[1:]
    return rf"{{{tag}}}" + body


def _round_rect(w: float, h: float, r: float) -> str:
    r = min(r, w / 2, h / 2)
    return (
        f"m {r:.0f} 0 l {w - r:.0f} 0 b {w:.0f} 0 {w:.0f} 0 {w:.0f} {r:.0f} "
        f"l {w:.0f} {h - r:.0f} b {w:.0f} {h:.0f} {w:.0f} {h:.0f} {w - r:.0f} {h:.0f} "
        f"l {r:.0f} {h:.0f} b 0 {h:.0f} 0 {h:.0f} 0 {h - r:.0f} "
        f"l 0 {r:.0f} b 0 0 0 0 {r:.0f} 0"
    )


def _round_left(w: float, h: float, r: float) -> str:
    r = min(r, w / 2, h / 2)
    return (
        f"m {r:.0f} 0 l {w:.0f} 0 l {w:.0f} {h:.0f} l {r:.0f} {h:.0f} "
        f"b 0 {h:.0f} 0 {h:.0f} 0 {h - r:.0f} l 0 {r:.0f} b 0 0 0 0 {r:.0f} 0"
    )


def _round_right(w: float, h: float, r: float) -> str:
    r = min(r, w / 2, h / 2)
    return (
        f"m 0 0 l {w - r:.0f} 0 b {w:.0f} 0 {w:.0f} 0 {w:.0f} {r:.0f} "
        f"l {w:.0f} {h - r:.0f} b {w:.0f} {h:.0f} {w:.0f} {h:.0f} {w - r:.0f} {h:.0f} "
        f"l 0 {h:.0f} l 0 0"
    )


def _rect(w: float, h: float) -> str:
    return f"m 0 0 l {w:.0f} 0 l {w:.0f} {h:.0f} l 0 {h:.0f}"


def _badge_plate(width: float, height: float, shape: str) -> str:
    if shape == "square":
        return _rect(width, height)
    return _round_rect(width, height, height / 2)


def _badge_chip(width: float, height: float, shape: str, side: str = "left") -> str:
    if shape == "square":
        return _rect(width, height)
    if side == "right":
        return _round_right(width, height, height / 2)
    return _round_left(width, height, height / 2)


def _draw(layer: int, t0: str, t1: str, x: float, y: float, path: str, color: str, alpha: str) -> str:
    return (
        f"Dialogue: {layer},{t0},{t1},HudDraw,,0,0,0,,"
        rf"{{\an7\pos({x:.1f},{y:.1f})\p1\bord0\shad0\1c{color}&\1a&H{alpha}&\3a&HFF&}}{path}"
    )


def _token_width(token: str, scale: float = 1.0) -> float:
    font = _hud_font()
    if font:
        return font.width(token) * scale
    width = 0
    for char in token:
        if char in "il.,'!":
            width += 9
        elif char in "mwMW":
            width += 30
        elif char.isupper():
            width += 24
        else:
            width += 20
    return float(max(12, width)) * scale


def _space_width(scale: float = 1.0) -> float:
    font = _hud_font()
    if font:
        return font.width(" ") * scale
    return 12.0 * scale


def _text_budget(
    show_pill: bool = True,
    pill_w: int | None = None,
    plate_w: float | None = None,
    scale: float = 1.0,
) -> float:
    width = hud_pill_w(scale=scale) if pill_w is None else int(pill_w)
    gutter = width + 36 * scale if show_pill else 36 * scale
    plate = float(HUD_W if plate_w is None else plate_w)
    return plate - gutter


def _hud_rows(
    words: list[dict],
    max_rows: int = HUD_MAX_ROWS,
    show_pill: bool = True,
    pill_w: int | None = None,
    plate_w: float | None = None,
    scale: float = 1.0,
) -> tuple[list[list[dict]], list[dict]]:
    items = [word for word in words if str(word.get("word") or "").strip()]
    rows: list[list[dict]] = []
    current: list[dict] = []
    used = 0.0
    gap = _space_width(scale)
    budget = _text_budget(show_pill, pill_w, plate_w, scale)
    for index, word in enumerate(items):
        token = escape_ass(str(word.get("word") or "").strip())
        width = _token_width(token, scale)
        extra = 0.0 if not current else gap
        if current and used + extra + width > budget:
            rows.append(current)
            if len(rows) >= max_rows:
                return rows, items[index:]
            current = [word]
            used = width
        else:
            current.append(word)
            used += extra + width
    if current:
        rows.append(current)
    return rows, []


def apply_cue_hold(cues: list[dict], hold: float, window_end: float) -> list[dict]:
    extra = max(0.0, float(hold or 0))
    if extra <= 0 or not cues:
        return cues
    limit_end = max(0.0, float(window_end))
    for index, cue in enumerate(cues):
        cue["end"] = min(limit_end, float(cue["end"]) + extra)
        if cue["end"] <= float(cue["start"]):
            cue["end"] = min(limit_end, float(cue["start"]) + 0.04)
        if index + 1 >= len(cues):
            continue
        nxt = cues[index + 1]
        if float(nxt["start"]) < float(cue["end"]):
            nxt["start"] = float(cue["end"])
        if float(nxt["start"]) >= limit_end:
            nxt["start"] = max(0.0, limit_end - 0.04)
            nxt["end"] = limit_end
    last = cues[-1]
    last["end"] = min(limit_end, max(float(last["end"]), float(last["start"]) + 0.04))
    return cues


def _plate_top(position: str, height: float, dodge: float = 0.0, scale: float = 1.0) -> float:
    y = float(HUD_Y[position])
    extra = height - HUD_H * scale
    if extra <= 0:
        extra = 0.0
    if position == "top":
        return y + dodge
    if position == "center":
        return y - extra / 2 + dodge
    return y - extra - dodge


def _plate_height(row_count: int, scale: float = 1.0) -> float:
    rows = max(1, row_count)
    if rows <= 1:
        return float(HUD_H * scale)
    return float(HUD_H * scale + HUD_LINE_H * scale * (rows - 1))


def _word_slots(
    words: list[dict],
    show_pill: bool = True,
    pill_w: int | None = None,
    scale: float = 1.0,
) -> list[tuple[float, float, dict, str]]:
    slots = []
    gutter = hud_pill_w(scale=scale) if pill_w is None else int(pill_w)
    x = float(gutter + 22 * scale) if show_pill else 22.0 * scale
    gap = _space_width(scale)
    for index, word in enumerate(words):
        token = escape_ass(str(word.get("word") or "").strip())
        if index:
            x += gap
        width = _token_width(token, scale)
        slots.append((x, width, word, token))
        x += width
    return slots


def _word_windows(cue: dict, words: list[dict]) -> list[tuple[float, float, dict]]:
    if not words:
        return []
    windows: list[tuple[float, float, dict]] = []
    for index, word in enumerate(words):
        start = max(float(word["start"]), float(cue["start"]))
        end = float(word["end"])
        if index == 0:
            start = float(cue["start"])
        if index + 1 < len(words):
            end = max(end, min(float(words[index + 1]["start"]), float(cue["end"])))
        else:
            end = float(cue["end"])
        end = min(max(end, start), float(cue["end"]))
        if end <= start:
            end = min(float(cue["end"]), start + 0.04)
        windows.append((start, end, word))
    return windows


def _tactical_events(cue: dict, style: dict) -> list[str]:
    assigned = optional_speaker(cue.get("speaker"))
    speaker = assigned or "Voice1"
    position = style["position"]
    show_pill = assigned is not None
    pill_speaker = assigned or "Voice1"
    fill_hex = _voice_hex(style, speaker)
    fill = hex_to_ass(fill_hex)
    ink = voice_ink(style, speaker)
    pill_hex = _voice_hex(style, pill_speaker)
    pill_fill = hex_to_ass(pill_hex)
    pill_ink = hex_to_ass(_voice_text_hex(style, pill_speaker))
    tag = voice_tag(style, pill_speaker)
    scale = _caption_scale(style)
    pill_w = hud_pill_w(tag, scale) if show_pill else 0
    hx, hw, y_dodge = _hud_layout(style)
    t0 = fmt_ass_time(cue["start"])
    t1 = fmt_ass_time(cue["end"])
    words = [word for word in (cue.get("words") or []) if str(word.get("word") or "").strip()]
    rows, overflow = _hud_rows(words, show_pill=show_pill, pill_w=pill_w, plate_w=hw, scale=scale)
    if overflow:
        extra_rows, leftover = _hud_rows(
            overflow, max_rows=12, show_pill=show_pill, pill_w=pill_w, plate_w=hw, scale=scale
        )
        rows.extend(extra_rows)
        if leftover:
            rows.append(leftover)
    row_count = max(1, len(rows))
    height = _plate_height(row_count, scale)
    y = _plate_top(position, height, y_dodge, scale)
    plate = _round_rect(hw, height, min(HUD_R * scale, height / 2))
    events = [
        _draw(0, t0, t1, hx, y, plate, fill, "96"),
    ]
    if show_pill:
        pill = _round_left(pill_w, height, min(HUD_R * scale, height / 2))
        events.append(_draw(1, t0, t1, hx, y, pill, pill_fill, "00"))
        events.append(
            f"Dialogue: 2,{t0},{t1},HudTag,,0,0,0,,"
            rf"{{\an5\pos({hx + pill_w // 2},{y + height / 2:.1f})\bord0\shad0\1c{pill_ink}&}}{tag}"
        )
    layout: list[tuple[float, float, dict, str, float]] = []
    for row_index, row in enumerate(rows):
        if row_count == 1:
            text_y = y + height / 2
        else:
            text_y = y + 26 * scale + row_index * HUD_LINE_H * scale
        for sx, width, word, token in _word_slots(row, show_pill, pill_w, scale):
            layout.append((sx, width, word, token, text_y))
    windows = _word_windows(cue, [item[2] for item in layout])
    pad = HUD_HIGHLIGHT_PAD * scale
    highlight_h = (44.0 if row_count > 1 else 68.0) * scale
    text_x = hx + (pill_w + 22 * scale if show_pill else 22 * scale)
    if not windows:
        for sx, _width, _word, token, text_y in layout:
            events.append(
                f"Dialogue: 4,{t0},{t1},HudWords,,0,0,0,,"
                rf"{{\an4\pos({hx + sx:.1f},{text_y:.1f})\bord0\shad0\fsp0\1c{ink}&}}{token}"
            )
        if not layout:
            body = escape_ass(cue["text"])
            events.append(
                f"Dialogue: 4,{t0},{t1},HudWords,,0,0,0,,"
                rf"{{\an4\pos({text_x},{y + height / 2:.1f})\bord0\shad0\fsp0\1c{ink}&}}{body}"
            )
        return events
    for rel_s, rel_e, active in windows:
        wt0, wt1 = fmt_ass_time(rel_s), fmt_ass_time(rel_e)
        for sx, width, word, token, text_y in layout:
            word_x = hx + sx
            if word is active:
                highlight_w = width + pad * 2
                path = _round_rect(highlight_w, highlight_h, highlight_h / 2)
                highlight_y = text_y - highlight_h / 2
                events.append(_draw(3, wt0, wt1, word_x - pad, highlight_y, path, fill, "00"))
                color = ink
            else:
                color = ink
            events.append(
                f"Dialogue: 4,{wt0},{wt1},HudWords,,0,0,0,,"
                rf"{{\an4\pos({word_x:.1f},{text_y:.1f})\bord0\shad0\fsp0\1c{color}&}}{token}"
            )
    return events


def _social_styles() -> list[str]:
    return [
        (
            "Style: SocialDraw,Liberation Sans,1,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,"
            "0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1"
        ),
        (
            "Style: SocialMark,Liberation Sans,26,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,"
            "1,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1"
        ),
        (
            "Style: SocialName,Liberation Sans,32,&H00F0F0F4,&H00F0F0F4,&H00000000,&H00000000,"
            "0,0,0,0,100,100,0,0,1,0,0,4,0,0,0,1"
        ),
    ]


def _social_scale(socials: dict) -> float:
    return SOCIAL_SCALES.get(str(socials.get("size") or "small"), 1.0)


def _social_size(handle: str, scale: float = 1.0) -> tuple[float, float]:
    font = 32.0 * scale
    height = SOCIAL_H * scale
    text_w = _token_width(escape_ass(handle)) * (font / max(HUD_FONT, 1))
    width = max(220.0 * scale, height + 20.0 * scale + text_w + 24.0 * scale)
    return width, height


def _social_rest(corner: str, width: float, height: float) -> tuple[float, float]:
    margin = 48.0
    parts = str(corner or "top-right").split("-")
    vert = parts[0] if parts else "top"
    horiz = parts[1] if len(parts) > 1 else "center"
    if vert == "top":
        y = 72.0
    elif vert == "bottom":
        y = 1920.0 - margin - height
    else:
        y = (1920.0 - height) / 2.0
    if horiz == "left":
        x = margin
    elif horiz == "right":
        x = 1080.0 - margin - width
    else:
        x = (1080.0 - width) / 2.0
    return x, y


def _social_delta(effect: str) -> tuple[float, float]:
    travel = 260.0
    if effect == "slide-left":
        return (-travel, 0.0)
    if effect == "slide-right":
        return (travel, 0.0)
    if effect == "slide-top":
        return (0.0, -travel)
    if effect == "slide-bottom":
        return (0.0, travel)
    if effect == "bounce":
        return (0.0, 110.0)
    return (0.0, 0.0)


def _social_motion(effect: str, phase: str, rest_x: float, rest_y: float, dur_ms: int, org: tuple[float, float]) -> str:
    ox, oy = org
    org_tag = rf"\org({ox:.1f},{oy:.1f})"
    if phase == "hold" or effect in {"fade", "pop", "blur"} and phase == "hold":
        return rf"\pos({rest_x:.1f},{rest_y:.1f}){org_tag}"
    dx, dy = _social_delta(effect)
    if effect in {"slide-left", "slide-right", "slide-top", "slide-bottom", "bounce"}:
        start_x, start_y = rest_x + dx, rest_y + dy
        if phase == "enter":
            return (
                rf"\move({start_x:.1f},{start_y:.1f},{rest_x:.1f},{rest_y:.1f},0,{dur_ms})"
                f"{org_tag}"
            )
        return (
            rf"\move({rest_x:.1f},{rest_y:.1f},{start_x:.1f},{start_y:.1f},0,{dur_ms})"
            f"{org_tag}"
        )
    pos = rf"\pos({rest_x:.1f},{rest_y:.1f}){org_tag}"
    if effect == "fade":
        return pos + (rf"\fad({dur_ms},0)" if phase == "enter" else rf"\fad(0,{dur_ms})")
    if effect == "blur":
        if phase == "enter":
            return pos + rf"\blur12\fad({dur_ms},0)\t(0,{dur_ms},\blur0)"
        return pos + rf"\t(0,{dur_ms},\blur12)\fad(0,{dur_ms})"
    if effect == "pop":
        if phase == "enter":
            grow = max(40, int(dur_ms * 0.65))
            return pos + rf"\fscx0\fscy0\t(0,{grow},\fscx112\fscy112)\t({grow},{dur_ms},\fscx100\fscy100)"
        return pos + rf"\t(0,{dur_ms},\fscx0\fscy0)\fad(0,{max(80, dur_ms // 2)})"
    return pos


def _social_line(
    layer: int,
    style_name: str,
    t0: str,
    t1: str,
    align: str,
    motion: str,
    extra: str,
    text: str,
) -> str:
    return (
        f"Dialogue: {layer},{t0},{t1},{style_name},,0,0,0,,"
        rf"{{{align}{motion}{extra}}}{text}"
    )


def _badge_phase_events(
    t0: float,
    t1: float,
    effect: str,
    phase: str,
    x: float,
    y: float,
    width: float,
    height: float,
    platform: str,
    handle: str,
    scale: float = 1.0,
    shape: str = "pill",
    icon: str = "left",
    chip_hex: str | None = None,
    look: str = "social",
) -> list[str]:
    anim_ms = max(80, int(round((t1 - t0) * 1000)))
    org = (x + width / 2, y + height / 2)
    start, end = fmt_ass_time(t0), fmt_ass_time(t1)
    plate = _badge_plate(width, height, shape)
    chip = _badge_chip(height, height, shape, icon)
    plate_motion = _social_motion(effect, phase, x, y, anim_ms, org)
    chip_x = x + width - height if icon == "right" else x
    chip_motion = _social_motion(effect, phase, chip_x, y, anim_ms, org)
    name_pad = 16.0 * scale
    solid = platform == "custom" and look == "solid"
    if solid or icon == "right":
        name_x = x + name_pad
    else:
        name_x = x + height + name_pad
    name_y = y + height / 2
    name_motion = _social_motion(effect, phase, name_x, name_y, anim_ms, org)
    extra_draw = r"\p1\bord0\shad0\3a&HFF&"
    layer_hex, layers = icon_layers(platform)
    if chip_hex:
        layer_hex = chip_hex
        layers = []
    icon_px = ICON_PX * scale
    glyph = icon_drawing(platform, icon_px)
    icon_x = chip_x + (height - icon_px) / 2.0
    icon_y = y + (height - icon_px) / 2.0
    layer_scale = scale
    if solid:
        name_color = hex_to_ass(_contrast_hex(layer_hex))
        return [
            _social_line(
                10,
                "SocialDraw",
                start,
                end,
                r"\an7",
                plate_motion,
                extra_draw + rf"\1c{hex_to_ass(layer_hex)}&\1a&H00&",
                plate,
            ),
            _social_line(
                12,
                "SocialName",
                start,
                end,
                r"\an4",
                name_motion,
                rf"\bord0\shad0\fs{32.0 * scale:.1f}\1c{name_color}&",
                escape_ass(handle),
            ),
        ]
    events = [
        _social_line(
            10,
            "SocialDraw",
            start,
            end,
            r"\an7",
            plate_motion,
            extra_draw + rf"\1c{SOCIAL_PLATE}&\1a&H64&",
            plate,
        ),
        _social_line(
            11,
            "SocialDraw",
            start,
            end,
            r"\an7",
            chip_motion,
            extra_draw + rf"\1c{hex_to_ass(layer_hex)}&\1a&H00&",
            chip,
        ),
    ]
    if glyph:
        for color, dx, dy in layers:
            motion = _social_motion(
                effect, phase, icon_x + dx * layer_scale, icon_y + dy * layer_scale, anim_ms, org
            )
            events.append(
                _social_line(
                    12,
                    "SocialDraw",
                    start,
                    end,
                    r"\an7",
                    motion,
                    extra_draw + rf"\1c{hex_to_ass(color)}&\1a&H00&",
                    glyph,
                )
            )
    name_fs = 32.0 * scale
    events.append(
        _social_line(
            12,
            "SocialName",
            start,
            end,
            r"\an4",
            name_motion,
            rf"\bord0\shad0\fs{name_fs:.1f}\1c{SOCIAL_NAME}&",
            escape_ass(handle),
        )
    )
    return events


def _social_events(style: dict, duration: float) -> list[str]:
    socials = style.get("socials") or default_social_style()
    shared = str(socials.get("name") or "").strip()
    enabled: list[tuple[str, str, str | None, str]] = []
    for key, _color, _mark in SOCIAL_PLATFORMS:
        item = socials.get(key) or {}
        if not item.get("enabled"):
            continue
        handle = str(item.get("handle") or "").strip() or shared
        if not handle:
            continue
        enabled.append((handle, key, None, "social"))
    for badge in socials.get("custom") or []:
        if not isinstance(badge, dict) or not badge.get("enabled"):
            continue
        label = str(badge.get("label") or "").strip()
        if not label:
            continue
        look = "solid" if str(badge.get("look") or "").lower() == "solid" else "social"
        enabled.append((label, "custom", str(badge.get("color") or DEFAULT_CUSTOM_BADGE_COLOR), look))
    if not enabled or duration <= 0.4:
        return []
    show_for = float(socials.get("hold") or 2.6)
    anim = min(SOCIAL_ANIM, max(0.18, show_for / 4))
    hold_mid = max(0.35, show_for - anim * 2)
    start_at = max(0.0, float(socials.get("start") or 0))
    until_raw = float(socials.get("end") or 0)
    until = duration if until_raw <= 0 else min(duration, until_raw)
    loop = bool(socials.get("loop", True))
    corner = str(socials.get("corner") or "top-right")
    enter = str(socials.get("enter") or "slide-right")
    exit_fx = str(socials.get("exit") or "fade")
    scale = _social_scale(socials)
    shape = str(socials.get("shape") or "pill")
    if shape not in SOCIAL_SHAPES:
        shape = "pill"
    icon = str(socials.get("icon") or "left")
    if icon not in SOCIAL_ICON_SIDES:
        icon = "left"
    if start_at >= until:
        return []
    events: list[str] = []
    cursor = start_at
    safety = 0
    while cursor + show_for <= until + 0.01 and safety < 80:
        safety += 1
        for handle, platform, chip_hex, look in enabled:
            if cursor + show_for > until + 0.05:
                break
            width, height = _social_size(handle, scale)
            x, y = _social_rest(corner, width, height)
            enter_end = cursor + anim
            hold_end = enter_end + hold_mid
            exit_end = min(until, hold_end + anim)
            events.extend(
                _badge_phase_events(
                    cursor, enter_end, enter, "enter", x, y, width, height, platform, handle, scale, shape, icon, chip_hex, look
                )
            )
            events.extend(
                _badge_phase_events(
                    enter_end, hold_end, enter, "hold", x, y, width, height, platform, handle, scale, shape, icon, chip_hex, look
                )
            )
            events.extend(
                _badge_phase_events(
                    hold_end, exit_end, exit_fx, "exit", x, y, width, height, platform, handle, scale, shape, icon, chip_hex, look
                )
            )
            cursor = exit_end + SOCIAL_GAP
        if not loop:
            break
        if cursor <= start_at:
            break
    return events


def write_ass(cues: list[dict], path: Path, style: dict, duration: float | None = None) -> None:
    style = normalize_style(style)
    theme = style["theme"]
    position = style["position"]
    events: list[str] = []
    for cue in cues:
        if theme == "tactical":
            events.extend(_tactical_events(cue, style))
        else:
            voice = optional_speaker(cue.get("speaker")) or "Voice1"
            text = _event_text(cue, theme, style)
            events.append(
                f"Dialogue: 0,{fmt_ass_time(cue['start'])},{fmt_ass_time(cue['end'])},{voice},,0,0,0,,{text}"
            )
    window = duration
    if window is None:
        window = max((float(cue["end"]) for cue in cues), default=0.0)
    events.extend(_social_events(style, float(window or 0)))
    styles = [_style_line(name, name, theme, position, style) for name in VOICE_IDS]
    if theme == "tactical":
        styles.extend(_hud_styles(style))
    styles.extend(_social_styles())
    body = "\n".join(
        [
            "[Script Info]",
            "ScriptType: v4.00+",
            "PlayResX: 1080",
            "PlayResY: 1920",
            "WrapStyle: 0",
            "ScaledBorderAndShadow: yes",
            "",
            "[V4+ Styles]",
            "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
            *styles,
            "",
            "[Events]",
            "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
            *events,
            "",
        ]
    )
    path.write_text(body, encoding="utf-8")
