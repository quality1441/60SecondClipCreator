globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/oT16xEpI3dZjGRjrabJt6/_buildManifest.js",
    "static/oT16xEpI3dZjGRjrabJt6/_ssgManifest.js",
    "static/oT16xEpI3dZjGRjrabJt6/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3mc6dra1m0098.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/0c1xi1au-flja.js",
    "static/chunks/1v_eje5o0pqv0.js",
    "static/chunks/turbopack-0_sl9iqcb-ttv.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
