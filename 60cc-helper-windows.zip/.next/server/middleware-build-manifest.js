globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/lKDPf60uX8orq4T2XdG0K/_buildManifest.js",
    "static/lKDPf60uX8orq4T2XdG0K/_ssgManifest.js",
    "static/lKDPf60uX8orq4T2XdG0K/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3mc6dra1m0098.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/0c1xi1au-flja.js",
    "static/chunks/1v_eje5o0pqv0.js",
    "static/chunks/turbopack-0_sl9iqcb-ttv.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
