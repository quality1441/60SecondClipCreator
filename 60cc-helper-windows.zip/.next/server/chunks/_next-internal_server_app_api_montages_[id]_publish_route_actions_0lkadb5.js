module.exports=[56660,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_montages_%5Bid%5D_publish_route_actions_0lkadb5.js.map