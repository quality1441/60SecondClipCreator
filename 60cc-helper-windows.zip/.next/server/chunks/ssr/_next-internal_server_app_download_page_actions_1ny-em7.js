module.exports=[11783,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_download_page_actions_1ny-em7.js.map