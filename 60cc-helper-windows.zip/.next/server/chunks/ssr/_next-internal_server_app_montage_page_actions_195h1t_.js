module.exports=[87767,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_montage_page_actions_195h1t_.js.map