module.exports=[22341,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_montages_route_actions_090h67u.js.map