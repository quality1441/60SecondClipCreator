module.exports=[60607,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_jobs_%5Bid%5D_source_route_actions_0ftoemz.js.map