module.exports=[12864,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_montages_%5Bid%5D_encode_route_actions_0ymobd_.js.map