module.exports=[27968,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_browse_route_actions_1ilnb0a.js.map