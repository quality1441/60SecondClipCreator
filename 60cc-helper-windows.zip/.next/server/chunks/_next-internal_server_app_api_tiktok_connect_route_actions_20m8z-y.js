module.exports=[3860,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tiktok_connect_route_actions_20m8z-y.js.map