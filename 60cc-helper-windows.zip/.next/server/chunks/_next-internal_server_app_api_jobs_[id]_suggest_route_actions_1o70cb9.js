module.exports=[31156,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_jobs_%5Bid%5D_suggest_route_actions_1o70cb9.js.map