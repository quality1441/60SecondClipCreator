module.exports=[64895,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_instagram_connect_route_actions_1eeuwq4.js.map