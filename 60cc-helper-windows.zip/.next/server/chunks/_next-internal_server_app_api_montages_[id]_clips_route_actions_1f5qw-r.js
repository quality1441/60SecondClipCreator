module.exports=[66671,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_montages_%5Bid%5D_clips_route_actions_1f5qw-r.js.map