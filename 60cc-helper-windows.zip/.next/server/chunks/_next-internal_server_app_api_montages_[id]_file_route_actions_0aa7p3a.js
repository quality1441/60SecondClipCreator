module.exports=[57936,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_montages_%5Bid%5D_file_route_actions_0aa7p3a.js.map