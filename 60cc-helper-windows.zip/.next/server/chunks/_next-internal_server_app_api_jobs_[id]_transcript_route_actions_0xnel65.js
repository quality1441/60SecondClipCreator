module.exports=[59840,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_jobs_%5Bid%5D_transcript_route_actions_0xnel65.js.map