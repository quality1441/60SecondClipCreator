module.exports=[79766,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_montages_%5Bid%5D_route_actions_12pi144.js.map