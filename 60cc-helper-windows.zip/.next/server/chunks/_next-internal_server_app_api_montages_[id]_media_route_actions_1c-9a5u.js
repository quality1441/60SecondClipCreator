module.exports=[70005,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_montages_%5Bid%5D_media_route_actions_1c-9a5u.js.map