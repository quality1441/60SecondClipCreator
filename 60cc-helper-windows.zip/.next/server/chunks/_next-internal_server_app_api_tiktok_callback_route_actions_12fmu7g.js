module.exports=[74034,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tiktok_callback_route_actions_12fmu7g.js.map