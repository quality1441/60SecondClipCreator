module.exports=[90596,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_montages_%5Bid%5D_media_%5Bfile%5D_route_actions_0evjgm1.js.map