var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/pair/route.js")
R.c("server/chunks/[root-of-the-server]__0bc-yon._.js")
R.c("server/chunks/src_lib_license-jwt_ts_1r0at8h._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_pair_route_actions_1mrgyf8.js")
R.m(32354)
module.exports=R.m(32354).exports
