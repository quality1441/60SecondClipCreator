var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/google/callback/route.js")
R.c("server/chunks/[root-of-the-server]__1khqemy._.js")
R.c("server/chunks/src_lib_license-jwt_ts_1r0at8h._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_google_callback_route_actions_0x6kl3t.js")
R.m(70225)
module.exports=R.m(70225).exports
