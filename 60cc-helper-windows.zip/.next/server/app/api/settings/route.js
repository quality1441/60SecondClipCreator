var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/route.js")
R.c("server/chunks/[root-of-the-server]__0mj3qxs._.js")
R.c("server/chunks/_1pvqo-q._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/src_lib_14sf-rt._.js")
R.c("server/chunks/_next-internal_server_app_api_settings_route_actions_1bpm9ac.js")
R.m(61525)
module.exports=R.m(61525).exports
