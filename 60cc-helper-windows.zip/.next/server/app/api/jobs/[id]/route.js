var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/jobs/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0drw98j._.js")
R.c("server/chunks/src_lib_14sf-rt._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_jobs_[id]_route_actions_1sowbxn.js")
R.m(45590)
module.exports=R.m(45590).exports
