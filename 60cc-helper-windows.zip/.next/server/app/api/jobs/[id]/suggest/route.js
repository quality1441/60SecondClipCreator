var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/jobs/[id]/suggest/route.js")
R.c("server/chunks/[root-of-the-server]__0ungut6._.js")
R.c("server/chunks/src_lib_14sf-rt._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_jobs_[id]_suggest_route_actions_1o70cb9.js")
R.m(66874)
module.exports=R.m(66874).exports
