var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/jobs/[id]/clips/[name]/publish-ready/route.js")
R.c("server/chunks/[root-of-the-server]__1hlx74x._.js")
R.c("server/chunks/src_lib_14sf-rt._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/1oeh_server_app_api_jobs_[id]_clips_[name]_publish-ready_route_actions_1bxv_on.js")
R.m(78216)
module.exports=R.m(78216).exports
