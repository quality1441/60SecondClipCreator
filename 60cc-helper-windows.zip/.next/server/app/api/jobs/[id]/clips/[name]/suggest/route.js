var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/jobs/[id]/clips/[name]/suggest/route.js")
R.c("server/chunks/[root-of-the-server]__1o13puu._.js")
R.c("server/chunks/src_lib_14sf-rt._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/1oeh_server_app_api_jobs_[id]_clips_[name]_suggest_route_actions_07u-p_2.js")
R.m(57306)
module.exports=R.m(57306).exports
