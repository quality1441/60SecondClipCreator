var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/jobs/[id]/clips/[name]/window/route.js")
R.c("server/chunks/[root-of-the-server]__05wdlx4._.js")
R.c("server/chunks/src_lib_07mibkg._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/1oeh_server_app_api_jobs_[id]_clips_[name]_window_route_actions_1965pxo.js")
R.m(66227)
module.exports=R.m(66227).exports
