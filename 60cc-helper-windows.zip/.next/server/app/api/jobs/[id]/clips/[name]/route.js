var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/jobs/[id]/clips/[name]/route.js")
R.c("server/chunks/[root-of-the-server]__1vbtb1j._.js")
R.c("server/chunks/_1edtw92._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/src_lib_14sf-rt._.js")
R.c("server/chunks/_next-internal_server_app_api_jobs_[id]_clips_[name]_route_actions_1h7_csv.js")
R.m(91267)
module.exports=R.m(91267).exports
