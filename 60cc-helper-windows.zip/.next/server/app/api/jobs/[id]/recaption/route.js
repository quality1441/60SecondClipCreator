var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/jobs/[id]/recaption/route.js")
R.c("server/chunks/[root-of-the-server]__1hsfkrg._.js")
R.c("server/chunks/src_lib_14sf-rt._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_jobs_[id]_recaption_route_actions_00yw-e6.js")
R.m(88965)
module.exports=R.m(88965).exports
