var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/jobs/[id]/source/route.js")
R.c("server/chunks/[root-of-the-server]__1qowt15._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/src_lib_14sf-rt._.js")
R.c("server/chunks/_next-internal_server_app_api_jobs_[id]_source_route_actions_0ftoemz.js")
R.m(70177)
module.exports=R.m(70177).exports
