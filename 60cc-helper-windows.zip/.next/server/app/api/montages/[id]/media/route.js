var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/montages/[id]/media/route.js")
R.c("server/chunks/src_lib_montages_ts_0ra5m2v._.js")
R.c("server/chunks/[root-of-the-server]__0t7-lhm._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/src_lib_15h2wky._.js")
R.c("server/chunks/_next-internal_server_app_api_montages_[id]_media_route_actions_1c-9a5u.js")
R.m(84070)
module.exports=R.m(84070).exports
