var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/montages/[id]/media/[file]/route.js")
R.c("server/chunks/src_lib_montages_ts_0ra5m2v._.js")
R.c("server/chunks/[root-of-the-server]__0poq67s._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/src_lib_15h2wky._.js")
R.c("server/chunks/_next-internal_server_app_api_montages_[id]_media_[file]_route_actions_0evjgm1.js")
R.m(51678)
module.exports=R.m(51678).exports
