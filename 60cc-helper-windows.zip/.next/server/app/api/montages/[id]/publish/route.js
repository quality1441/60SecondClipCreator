var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/montages/[id]/publish/route.js")
R.c("server/chunks/src_lib_montages_ts_0ra5m2v._.js")
R.c("server/chunks/[root-of-the-server]__1a-ftap._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/src_lib_15h2wky._.js")
R.c("server/chunks/_next-internal_server_app_api_montages_[id]_publish_route_actions_0lkadb5.js")
R.m(12616)
module.exports=R.m(12616).exports
