var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/montages/[id]/route.js")
R.c("server/chunks/_0p1h1r3._.js")
R.c("server/chunks/[root-of-the-server]__1z8_fpt._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/src_lib_15h2wky._.js")
R.c("server/chunks/_next-internal_server_app_api_montages_[id]_route_actions_12pi144.js")
R.m(76185)
module.exports=R.m(76185).exports
