var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/montages/[id]/file/route.js")
R.c("server/chunks/_1y2qo3i._.js")
R.c("server/chunks/[root-of-the-server]__1-virxg._.js")
R.c("server/chunks/src_lib_15h2wky._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_montages_[id]_file_route_actions_0aa7p3a.js")
R.m(24088)
module.exports=R.m(24088).exports
