var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/montages/route.js")
R.c("server/chunks/src_lib_montages_ts_0ra5m2v._.js")
R.c("server/chunks/[root-of-the-server]__1o51eju._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/src_lib_15h2wky._.js")
R.c("server/chunks/_next-internal_server_app_api_montages_route_actions_090h67u.js")
R.m(48635)
module.exports=R.m(48635).exports
