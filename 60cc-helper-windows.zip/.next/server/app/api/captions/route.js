var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/captions/route.js")
R.c("server/chunks/[root-of-the-server]__1avexck._.js")
R.c("server/chunks/_07ypv9v._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/src_lib_14sf-rt._.js")
R.c("server/chunks/_next-internal_server_app_api_captions_route_actions_056uxdf.js")
R.m(89957)
module.exports=R.m(89957).exports
