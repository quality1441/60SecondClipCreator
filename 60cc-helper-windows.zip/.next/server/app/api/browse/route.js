var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/browse/route.js")
R.c("server/chunks/[root-of-the-server]__1gv90or._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_api_browse_route_actions_1ilnb0a.js")
R.m(6553)
module.exports=R.m(6553).exports
