var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/download/route.js")
R.c("server/chunks/[root-of-the-server]__1n5czyy._.js")
R.c("server/chunks/src_lib_license-jwt_ts_1r0at8h._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_api_download_route_actions_07yss3k.js")
R.m(28101)
module.exports=R.m(28101).exports
