var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/history/route.js")
R.c("server/chunks/[root-of-the-server]__13wlhm2._.js")
R.c("server/chunks/src_lib_14sf-rt._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_history_route_actions_1yzwagj.js")
R.m(73642)
module.exports=R.m(73642).exports
